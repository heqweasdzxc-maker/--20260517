import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { buildMetadataEvent } from '../src/ai-metadata.mjs';

describe('AI metadata raw alarm identity', () => {
  it('keeps alarms distinct when two channels report within the same millisecond', async () => {
    const originalNow = Date.now;
    Date.now = () => 1784361578558;
    try {
      const first = await buildMetadataEvent(store(), payload('EV-1'));
      const second = await buildMetadataEvent(store(), payload('EV-2'));
      assert.notEqual(first.alarm.id, second.alarm.id);
    } finally {
      Date.now = originalNow;
    }
  });
});

function store() {
  const camera = { id: 'CH01', name: '1号桥东' };
  return {
    async getCamera() { return camera; },
    async listCameras() { return [camera]; },
    async getRuntimeConfig() { return { CH01: 50 }; },
  };
}

function payload(eventId) {
  return {
    eventId,
    cameraId: 'CH01',
    boxes: [{ cls: '漂浮物', score: 0.9, x: 0.2, y: 0.2, w: 0.1, h: 0.1 }],
  };
}
