import { randomUUID } from 'node:crypto';
import { severityFromScore } from './rules.mjs';

const disabledAlarmTypes = new Set(
  String(process.env.AI_DISABLED_ALARM_TYPES || '水位异常,water_level,water level,level')
    .split(',')
    .map((item) => item.trim().toLowerCase())
    .filter(Boolean),
);

export async function buildMetadataEvent(store, body = {}) {
  const cameraId = String(body.cameraId || body.channelId || 'CH03').toUpperCase();
  const camera = (await store.getCamera(cameraId)) ?? (await store.listCameras())[0];
  const boxes = Array.isArray(body.boxes) ? body.boxes : [];
  const activeBoxes = boxes.filter((box) => !isDisabledAlarmType(box.cls || box.label || box.name));
  const confidenceThreshold = await confidenceThresholdForCamera(store, camera.id);
  const thresholdBoxes = activeBoxes.filter((box) => scorePercent(box.score ?? box.confidence ?? 0) >= confidenceThreshold);

  if (boxes.length > 0 && activeBoxes.length === 0) {
    return {
      eventId: String(body.eventId || body.requestId || `AI-${Date.now()}-${randomUUID().slice(0, 8)}`),
      payload: { ...body, boxes: activeBoxes },
      alarm: null,
      workOrder: null,
      ignored: true,
      reason: 'water-level-disabled',
    };
  }

  if (activeBoxes.length > 0 && thresholdBoxes.length === 0) {
    return {
      eventId: String(body.eventId || body.requestId || `AI-${Date.now()}-${randomUUID().slice(0, 8)}`),
      payload: { ...body, boxes: [] },
      alarm: null,
      workOrder: null,
      ignored: true,
      reason: 'below-confidence-threshold',
      threshold: confidenceThreshold,
    };
  }

  const receiveTime = new Date();
  const generatedAt = normalizeIsoTime(body.generatedAt);
  const firstBox = thresholdBoxes.length ? thresholdBoxes[0] : { cls: 'AI\u8bc6\u522b\u4e8b\u4ef6', score: 0.86 };
  const score = Number(firstBox.score ?? firstBox.confidence ?? 0.86);
  const severity = severityFromScore(score);
  const id = `A-${Date.now()}-${randomUUID().slice(0, 8)}`;
  const alarm = {
    id,
    cameraId: camera.id,
    cameraName: camera.name,
    type: firstBox.cls || firstBox.label || 'AI\u8bc6\u522b\u4e8b\u4ef6',
    severity,
    confidence: Number((score * 100).toFixed(1)),
    status: '\u5f85\u7814\u5224',
    time: receiveTime.toLocaleTimeString('zh-CN', { hour12: false, timeZone: process.env.TZ || 'Asia/Shanghai' }),
    pts: formatPts(Number(body.pts || 0)),
    owner: 'AI \u63a8\u7406\u670d\u52a1',
    dedupeCount: 1,
    snapshot: `\u5143\u6570\u636e\u56de\u4f20 / ${camera.id}`,
    createdAt: receiveTime.toISOString(),
    updatedAt: receiveTime.toISOString(),
    metadata: {
      streamRole: body.streamRole || 'inference',
      sourceStreamUrl: body.sourceStreamUrl || '',
      displayStreamUrl: body.displayStreamUrl || camera.displayStreamUrl || camera.streams?.display?.webrtc || '',
      coordinateSpace: body.coordinateSpace || 'normalized',
      model: body.model || '',
      generatedAt,
      receivedAt: receiveTime.toISOString(),
    },
  };

  return {
    eventId: String(body.eventId || body.requestId || `AI-${Date.now()}-${randomUUID().slice(0, 8)}`),
    payload: { ...body, boxes: thresholdBoxes },
    alarm,
    workOrder: null,
    ignored: false,
  };
}

async function confidenceThresholdForCamera(store, cameraId) {
  const value = typeof store?.getRuntimeConfig === 'function' ? await store.getRuntimeConfig('confidenceThresholds') : null;
  const thresholds = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  return normalizeConfidencePercent(thresholds[cameraId], 50);
}

function normalizeConfidencePercent(value, fallback = 50) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return fallback;
  return Math.max(0, Math.min(100, Math.round(numeric)));
}

function scorePercent(value) {
  const numeric = Number(value || 0);
  const percent = numeric <= 1 ? numeric * 100 : numeric;
  return Math.round(percent * 10) / 10;
}

function isDisabledAlarmType(value = '') {
  const normalized = String(value || '').trim().toLowerCase();
  if (!normalized) return false;
  return disabledAlarmTypes.has(normalized) || normalized.includes('水位') || normalized.includes('water level');
}

function normalizeIsoTime(value) {
  const parsed = Date.parse(String(value || ''));
  return Number.isFinite(parsed) ? new Date(parsed).toISOString() : new Date().toISOString();
}

export function formatPts(ms) {
  const safeMs = Math.max(0, ms);
  const seconds = Math.floor(safeMs / 1000);
  const hh = String(Math.floor(seconds / 3600)).padStart(2, '0');
  const mm = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
  const ss = String(seconds % 60).padStart(2, '0');
  const rest = String(safeMs % 1000).padStart(3, '0');
  return `${hh}:${mm}:${ss}.${rest}`;
}
