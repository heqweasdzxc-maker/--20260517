﻿import mysql from 'mysql2/promise';
import { randomUUID } from 'node:crypto';
import { createSeedState } from './seed.mjs';
import { clone } from './rules.mjs';
import { defaultNotifyRules } from './notify.mjs';
import {
  closeAggregateEvent,
  createAggregateEvent,
  mergeAggregateEvent,
  normalizeEventDedupeKey,
} from './event-groups.mjs';

const defaultTenantId = Number(process.env.TENANT_ID || 1);
const strictTruthy = new Set(['1', 'true', 'yes', 'on']);
const messageStorageDefaultQuotaBytes = 1024 ** 4;
const messageStorageManagedCollections = [
  { table: 'rw_ai_event', key: 'aiEvents', dateField: 'receivedAt', dateColumn: 'received_at' },
  { table: 'rw_alarm', key: 'alarms', dateField: 'createdAt', dateColumn: 'created_at' },
  { table: 'rw_notification', key: 'notifications', dateField: 'createdAt', dateColumn: 'created_at' },
  { table: 'rw_work_order', key: 'workOrders', dateField: 'createdAt', dateColumn: 'created_at' },
  { table: 'rw_evidence_bundle', key: 'evidenceBundles', dateField: 'sealedAt', dateColumn: 'COALESCE(sealed_at, created_at)' },
  { table: 'rw_playback_clip', key: 'playbackClips', dateField: 'createdAt', dateColumn: 'created_at' },
  { table: 'rw_import_job', key: 'importJobs', dateField: 'createdAt', dateColumn: 'created_at' },
  { table: 'rw_report_task', key: 'reportTasks', dateField: 'createdAt', dateColumn: 'created_at' },
  { table: 'rw_operation_task', key: 'operationTasks', dateField: 'createdAt', dateColumn: 'created_at' },
  { table: 'rw_audit_log', key: 'logs', dateField: 'time', dateColumn: 'created_at' },
];
const messageStorageManagedTables = messageStorageManagedCollections.map((item) => item.table);

function nowIso(date = new Date()) {
  const value = date instanceof Date ? date : new Date(date);
  if (Number.isNaN(value.getTime())) return nowIso(new Date());
  return new Date(value.getTime() + 8 * 60 * 60 * 1000).toISOString().replace('Z', '+08:00');
}

function beijingTimeText(date = new Date()) {
  const value = date instanceof Date ? date : new Date(date);
  const safe = Number.isNaN(value.getTime()) ? new Date() : value;
  return safe.toLocaleTimeString('zh-CN', { hour12: false, timeZone: 'Asia/Shanghai' });
}

export function isStrictProductionMode() {
  return strictTruthy.has(String(process.env.RIVER_WATCH_STRICT_PRODUCTION || process.env.STRICT_PRODUCTION_MODE || '').trim().toLowerCase());
}

export function isExternalDatabaseInitMode() {
  return strictTruthy.has(String(process.env.RIVER_WATCH_EXTERNAL_DB_INIT || '').trim().toLowerCase());
}

function cameraStatusTtlMs() {
  return Number(process.env.CAMERA_STATUS_TTL_MS || 120000);
}

function aiWorkerStatusTtlMs() {
  return Number(process.env.AI_WORKER_STATUS_TTL_MS || 120000);
}

function metadataOverlayTtlMs() {
  const configured = Number(process.env.AI_METADATA_OVERLAY_TTL_MS ?? 60000);
  const maxTtl = Number(process.env.AI_METADATA_OVERLAY_MAX_TTL_MS ?? 120000);
  const ttl = Number.isFinite(configured) && configured >= 0 ? configured : 60000;
  return Math.min(ttl, Number.isFinite(maxTtl) && maxTtl > 0 ? maxTtl : 120000);
}

export async function createStoreFromEnv() {
  const databaseUrl = process.env.DATABASE_URL;
  const mysqlHost = process.env.MYSQL_HOST;

  if (!databaseUrl && !mysqlHost) {
    return createMemoryStore();
  }

  const pool = mysql.createPool(databaseUrl || {
    host: mysqlHost,
    port: Number(process.env.MYSQL_PORT || 3306),
    user: process.env.MYSQL_USER || 'root',
    password: process.env.MYSQL_PASSWORD || '',
    database: process.env.MYSQL_DATABASE || 'river_watch',
    waitForConnections: true,
    connectionLimit: Number(process.env.MYSQL_CONNECTION_LIMIT || 10),
    namedPlaceholders: true,
  });

  await waitForDatabase(pool);
  await ensureRuntimeSchema(pool);
  if (!isExternalDatabaseInitMode()) {
    await seedRuntimeTables(pool, createSeedState(), { strictProduction: isStrictProductionMode() });
  }
  await backfillEventGroups(pool);

  return createMysqlStore(pool);
}

export function createMemoryStore(seed = createSeedState()) {
  const state = clone(seed);
  state.events ||= [];
  state.eventGroupAlarmLinks ||= [];
  backfillMemoryEventGroups(state);
  let messageStorageRuntime = { lastEnforcedAt: null, lastDeletedRecords: 0 };

  return {
    mode: 'memory',
    async snapshot() {
      const snapshot = withRuntimeConfig(normalizeDeviceNames({
        ...clone(state),
        events: listMemoryEventGroups(state),
      }), state.runtimeConfig || []);
      return isStrictProductionMode() ? applyStrictProductionSnapshot(snapshot, state.cameraStatuses || [], state.aiWorkerStatuses || []) : snapshot;
    },
    async listCameras(filters = {}) {
      const cameras = isStrictProductionMode()
        ? applyCameraHeartbeats(state.cameras, state.cameraStatuses || [], state.aiEvents || [], state.aiWorkerStatuses || [])
        : state.cameras;
      return sortCameras(filterRecords(cameras, filters, ['status', 'protocol', 'group', 'node']));
    },
    async getCamera(id) {
      const camera = state.cameras.find((item) => item.id === id);
      if (!camera || !isStrictProductionMode()) return clone(camera);
      return clone(applyCameraHeartbeats([camera], state.cameraStatuses || [], state.aiEvents || [], state.aiWorkerStatuses || [])[0]);
    },
    async createCamera(camera) {
      const exists = state.cameras.findIndex((item) => item.id === camera.id);
      if (exists >= 0) state.cameras[exists] = camera;
      else state.cameras.unshift(camera);
      state.logs.unshift(createAuditLog('监管运营员', '新增设备', camera.id, '成功'));
      return clone(camera);
    },
    async updateCamera(camera) {
      const index = state.cameras.findIndex((item) => item.id === camera.id);
      if (index < 0) throw new Error(`设备不存在：${camera.id}`);
      state.cameras.splice(index, 1, camera);
      state.logs.unshift(createAuditLog('监管运营员', '修改设备', camera.id, '成功'));
      return clone(camera);
    },
    async deleteCamera(id) {
      const index = state.cameras.findIndex((item) => item.id === id);
      if (index < 0) throw new Error(`设备不存在：${id}`);
      const [camera] = state.cameras.splice(index, 1);
      state.logs.unshift(createAuditLog('监管运营员', '删除设备', id, '成功'));
      return clone(camera);
    },
    async listUavAssets(filters = {}) {
      return filterRecords(state.uavAssets || [], filters, ['status', 'vendor', 'model', 'dockName']);
    },
    async getUavAsset(id) {
      return clone((state.uavAssets || []).find((item) => item.id === id));
    },
    async createUavAsset(asset) {
      state.uavAssets ||= [];
      const exists = state.uavAssets.findIndex((item) => item.id === asset.id);
      if (exists >= 0) state.uavAssets[exists] = asset;
      else state.uavAssets.unshift(asset);
      state.logs.unshift(createAuditLog('监管运营员', '新增无人机设备', asset.id, '成功'));
      return clone(asset);
    },
    async updateUavAsset(asset) {
      state.uavAssets ||= [];
      const index = state.uavAssets.findIndex((item) => item.id === asset.id);
      if (index < 0) throw new Error(`无人机资产不存在：${asset.id}`);
      state.uavAssets.splice(index, 1, asset);
      state.logs.unshift(createAuditLog('监管运营员', '修改无人机设备', asset.id, '成功'));
      return clone(asset);
    },
    async deleteUavAsset(id) {
      state.uavAssets ||= [];
      const index = state.uavAssets.findIndex((item) => item.id === id);
      if (index < 0) throw new Error(`无人机资产不存在：${id}`);
      const [asset] = state.uavAssets.splice(index, 1);
      state.logs.unshift(createAuditLog('监管运营员', '删除无人机设备', id, '成功'));
      return clone(asset);
    },
    async listAlarms(filters = {}) {
      return normalizeDeviceNames({
        cameras: state.cameras,
        alarms: filterRecords(state.alarms, filters, ['status', 'severity', 'type', 'cameraId']),
      }).alarms;
    },
    async listEventGroups(filters = {}) {
      return clone(listMemoryEventGroups(state, filters));
    },
    async getEventGroup(id) {
      return clone(state.events.find((event) => event.id === id) || null);
    },
    async createAlarm(alarm) {
      const existingIndex = state.alarms.findIndex((item) => item.id === alarm.id);
      if (existingIndex >= 0) state.alarms.splice(existingIndex, 1, alarm);
      else state.alarms.unshift(alarm);
      aggregateAlarmForMemoryState(state, alarm);
      messageStorageRuntime = enforceMessageStorageQuotaForState(state);
      state.logs.unshift(createAuditLog(alarm.owner || 'AI 推理服务', existingIndex >= 0 ? '更新告警' : '创建告警', alarm.id, '成功'));
      return clone(alarm);
    },
    async reviewAlarm(id, status, makeWorkOrder) {
      const alarm = state.alarms.find((item) => item.id === id);
      if (!alarm) throw new Error(`告警不存在：${id}`);
      const camera = state.cameras.find((item) => item.id === alarm.cameraId);
      if (camera?.name) alarm.cameraName = camera.name;

      applyAlarmReviewStatus(alarm, status);

      let workOrder = null;
      if (alarm.status === '已归档' && (alarm.reviewResult === '忽略' || alarm.reviewResult === '已处理')) {
        state.workOrders = state.workOrders.filter((order) => order.alarmId !== alarm.id);
        workOrder = createClosedWorkOrderFromAlarm(alarm, makeWorkOrder, 9200 + state.workOrders.length);
        state.workOrders.unshift(workOrder);
        closeEventForMemoryState(state, alarm.id, alarm.reviewResult, workOrder?.id);
      }

      state.logs.unshift(createAuditLog('监管运营员', '研判告警', alarm.id, '成功'));
      return { alarm: clone(alarm), workOrder: clone(workOrder) };
    },
    async listWorkOrders() {
      return normalizeDeviceNames({
        cameras: state.cameras,
        alarms: state.alarms,
        workOrders: state.workOrders,
      }).workOrders;
    },
    async getWorkOrder(id) {
      return normalizeDeviceNames({
        cameras: state.cameras,
        alarms: state.alarms,
        workOrders: state.workOrders.filter((item) => item.id === id),
      }).workOrders[0] || null;
    },
    async createWorkOrder(order) {
      state.workOrders.unshift(order);
      messageStorageRuntime = enforceMessageStorageQuotaForState(state);
      state.logs.unshift(createAuditLog('监管运营员', '新建工单', order.id, '成功'));
      return clone(order);
    },
    async updateWorkOrder(order, action = '更新工单') {
      const index = state.workOrders.findIndex((item) => item.id === order.id);
      if (index < 0) throw new Error(`工单不存在：${order.id}`);
      state.workOrders[index] = order;
      state.logs.unshift(createAuditLog('监管运营员', action, order.id, '成功'));
      return clone(order);
    },
    async ingestMetadata(event) {
      const existing = state.aiEvents.find((item) => item.id === event.eventId);
      if (existing?.result) return clone(existing.result);

      const alarm = event.alarm;
      const existingIndex = state.alarms.findIndex((item) => item.id === alarm.id);
      if (existingIndex >= 0) state.alarms.splice(existingIndex, 1, alarm);
      else state.alarms.unshift(alarm);
      aggregateAlarmForMemoryState(state, alarm);
      const result = { alarm, workOrder: event.workOrder };
      state.aiEvents.unshift({ id: event.eventId, receivedAt: nowIso(), payload: event.payload, alarmId: alarm.id, result, retryCount: 0 });
      if (event.workOrder) state.workOrders.unshift(event.workOrder);
      messageStorageRuntime = enforceMessageStorageQuotaForState(state);
      state.logs.unshift(createAuditLog('AI 推理服务', '元数据回传', event.alarm.id, '成功'));
      return clone(result);
    },
    async getAlarmEvidence(alarmId) {
      const record = (state.alarmEvidence || {})[alarmId];
      return record ? { ...record, data: Buffer.from(record.data) } : null;
    },
    async saveAlarmEvidence(record) {
      state.alarmEvidence ||= {};
      state.alarmEvidence[record.alarmId] = { ...record, byteSize: record.data.length, data: Buffer.from(record.data) };
      const maxRecords = Math.max(1, Number(process.env.ALARM_EVIDENCE_MAX_RECORDS || 5000));
      const records = Object.values(state.alarmEvidence).sort((a, b) => Date.parse(b.capturedAt || 0) - Date.parse(a.capturedAt || 0));
      for (const expired of records.slice(maxRecords)) delete state.alarmEvidence[expired.alarmId];
      return { ...state.alarmEvidence[record.alarmId], data: Buffer.from(record.data) };
    },
    async listAiEvents(limit = 100) {
      return normalizeDeviceNames({
        cameras: state.cameras,
        alarms: state.alarms,
        workOrders: state.workOrders,
        aiEvents: state.aiEvents.slice(0, limit),
      }).aiEvents;
    },
    async getAiEvent(id) {
      const event = state.aiEvents.find((item) => item.id === id);
      return event ? clone(event) : null;
    },
    async retryAiEvent(id) {
      const event = state.aiEvents.find((item) => item.id === id);
      if (!event) throw new Error(`AI 事件不存在：${id}`);
      event.retryCount = Number(event.retryCount || 0) + 1;
      event.retryStatus = 'queued';
      state.logs.unshift(createAuditLog('监管运营员', '重试 AI 事件', id, '成功'));
      return clone({ eventId: id, status: 'queued', retryCount: event.retryCount });
    },
    async createExportTask(task) {
      state.exportTasks.unshift(task);
      state.logs.unshift(createAuditLog('监管运营员', '创建导出任务', task.id, '成功'));
      return clone(task);
    },
    async createOperationTask(task) {
      state.operationTasks ||= [];
      state.operationTasks.unshift(task);
      messageStorageRuntime = enforceMessageStorageQuotaForState(state);
      state.logs.unshift(createAuditLog('监管运营员', `提交${task.moduleName}${task.actionName}`, task.id, '成功'));
      return clone(task);
    },
    async createAlgorithm(algorithm) {
      state.algorithms ||= [];
      const index = state.algorithms.findIndex((item) => item.id === algorithm.id);
      if (index >= 0) state.algorithms[index] = algorithm;
      else state.algorithms.unshift(algorithm);
      state.logs.unshift(createAuditLog('监管运营员', '导入算法模型', algorithm.id, '成功'));
      return clone(algorithm);
    },
    async updateAlgorithm(algorithm) {
      state.algorithms ||= [];
      const index = state.algorithms.findIndex((item) => item.id === algorithm.id);
      if (index < 0) throw new Error(`模型不存在：${algorithm.id}`);
      state.algorithms[index] = algorithm;
      state.logs.unshift(createAuditLog('监管运营员', '修改模型配置', algorithm.id, '成功'));
      return clone(algorithm);
    },
    async getTemplate(id) {
      state.templates ||= [];
      return clone(state.templates.find((item) => item.id === id));
    },
    async createTemplate(template) {
      state.templates ||= [];
      const index = state.templates.findIndex((item) => item.id === template.id);
      if (index >= 0) state.templates[index] = template;
      else state.templates.unshift(template);
      state.logs.unshift(createAuditLog('监管运营员', '新增通配模板', template.id, '成功'));
      return clone(template);
    },
    async updateTemplate(template) {
      state.templates ||= [];
      const index = state.templates.findIndex((item) => item.id === template.id);
      if (index < 0) throw new Error(`模板不存在：${template.id}`);
      state.templates[index] = template;
      state.logs.unshift(createAuditLog('监管运营员', '修改通配模板', template.id, '成功'));
      return clone(template);
    },
    async deleteTemplate(id) {
      state.templates ||= [];
      const index = state.templates.findIndex((item) => item.id === id);
      if (index < 0) throw new Error(`模板不存在：${id}`);
      const [template] = state.templates.splice(index, 1);
      state.logs.unshift(createAuditLog('监管运营员', '删除通配模板', id, '成功'));
      return clone(template);
    },
    async listOperationTasks(limit = 100) {
      state.operationTasks ||= [];
      return clone(state.operationTasks.slice(0, limit));
    },
    async createPlaybackClip(clip) {
      state.playbackClips ||= [];
      state.playbackClips.unshift(clip);
      messageStorageRuntime = enforceMessageStorageQuotaForState(state);
      state.logs.unshift(createAuditLog('监管运营员', '回放裁剪导出', clip.id, '成功'));
      return clone(clip);
    },
    async listPlaybackClips(limit = 100) {
      state.playbackClips ||= [];
      return clone(state.playbackClips.slice(0, limit));
    },
    async createUavTask(task) {
      state.uavTasks ||= [];
      state.uavTasks.unshift(task);
      state.logs.unshift(createAuditLog('监管运营员', '发起无人机复查', task.id, '成功'));
      return clone(task);
    },
    async listNotifications(limit = 100) {
      state.notifications ||= [];
      return clone(state.notifications.slice(0, limit));
    },
    async getNotification(id) {
      state.notifications ||= [];
      return clone(state.notifications.find((item) => item.id === id));
    },
    async createNotification(notification) {
      state.notifications ||= [];
      state.notifications.unshift(notification);
      messageStorageRuntime = enforceMessageStorageQuotaForState(state);
      state.logs.unshift(createAuditLog('消息通知服务', `发送${notification.channel}通知`, notification.id, notification.status === '发送失败' ? '失败' : '成功'));
      return clone(notification);
    },
    async updateNotification(notification, action = '更新通知') {
      state.notifications ||= [];
      const index = state.notifications.findIndex((item) => item.id === notification.id);
      if (index < 0) throw new Error(`通知不存在：${notification.id}`);
      state.notifications.splice(index, 1, notification);
      state.logs.unshift(createAuditLog('消息通知服务', action, notification.id, '成功'));
      return clone(notification);
    },
    async listNotifyRules() {
      state.notifyRules ||= defaultNotifyRules();
      return clone(state.notifyRules);
    },
    async saveNotifyRule(rule) {
      state.notifyRules ||= defaultNotifyRules();
      const index = state.notifyRules.findIndex((item) => item.id === rule.id);
      if (index < 0) state.notifyRules.push(rule);
      else state.notifyRules.splice(index, 1, rule);
      state.logs.unshift(createAuditLog('平台管理员', '更新通知规则', rule.id, '成功'));
      return clone(rule);
    },
    async getRuntimeConfig(key) {
      const value = runtimeConfigMap(state.runtimeConfig || [])[key];
      return value === undefined ? null : clone(value);
    },
    async saveRuntimeConfig(record) {
      if (!record?.key) throw new Error('runtime config key is required');
      state.runtimeConfig ||= [];
      const next = {
        key: record.key,
        group: record.group || 'runtime',
        value: clone(record.value ?? {}),
        updatedAt: record.updatedAt || nowIso(),
      };
      const index = state.runtimeConfig.findIndex((item) => item.key === next.key);
      if (index >= 0) state.runtimeConfig.splice(index, 1, next);
      else state.runtimeConfig.push(next);
      return clone(next.value);
    },
    async listDiagnosticSteps(status = '在线') {
      const profiles = runtimeConfigMap(state.runtimeConfig || []).diagnostics || {};
      return clone(isBadDeviceStatus(status) ? profiles.failed || [] : profiles.healthy || []);
    },
    async listAiWorkers() {
      const workers = clone(runtimeConfigMap(state.runtimeConfig || []).aiWorkers || []);
      return isStrictProductionMode() ? applyAiWorkerHeartbeats(workers, state.aiWorkerStatuses || []) : workers;
    },
    async recordCameraStatus(status) {
      state.cameraStatuses ||= [];
      const record = normalizeCameraStatus(status);
      const index = state.cameraStatuses.findIndex((item) => item.cameraId === record.cameraId);
      if (index >= 0 && shouldPreserveCameraStatus(state.cameraStatuses[index], record)) {
        return clone(state.cameraStatuses[index]);
      }
      if (index >= 0) state.cameraStatuses[index] = record;
      else state.cameraStatuses.unshift(record);
      return clone(record);
    },
    async listCameraStatuses() {
      return clone(state.cameraStatuses || []);
    },
    async recordAiWorkerStatus(status) {
      state.aiWorkerStatuses ||= [];
      const record = normalizeAiWorkerStatus(status);
      const index = state.aiWorkerStatuses.findIndex((item) => item.workerId === record.workerId);
      if (index >= 0) state.aiWorkerStatuses[index] = record;
      else state.aiWorkerStatuses.unshift(record);
      return clone(record);
    },
    async listAiWorkerStatuses() {
      return clone(state.aiWorkerStatuses || []);
    },
    async listOperationRoutes() {
      return clone(runtimeConfigMap(state.runtimeConfig || []).operationRoutes || []);
    },
    async listStoragePolicies() {
      state.storageTiers ||= [];
      return clone(state.storageTiers);
    },
    async messageStorageStatus() {
      return messageStorageStatusFromState(state, messageStorageRuntime);
    },
    async createStoragePolicy(policy) {
      state.storageTiers ||= [];
      const index = state.storageTiers.findIndex((item) => item.id === policy.id || item.name === policy.name);
      if (index >= 0) state.storageTiers[index] = policy;
      else state.storageTiers.unshift(policy);
      state.logs.unshift(createAuditLog('监管运营员', '保存存储策略', policy.id || policy.name, '成功'));
      return clone(policy);
    },
    async updateStoragePolicy(policy) {
      return this.createStoragePolicy(policy);
    },
    async listReportMetrics() {
      state.reportMetrics ||= [];
      return clone(state.reportMetrics);
    },
    async listReportTasks() {
      state.reportTasks ||= [];
      return clone(state.reportTasks);
    },
    async createReportTask(task) {
      state.reportTasks ||= [];
      state.reportTasks.unshift(task);
      messageStorageRuntime = enforceMessageStorageQuotaForState(state);
      state.logs.unshift(createAuditLog('监管运营员', '创建报表任务', task.id, '成功'));
      return clone(task);
    },
    async listUsers() {
      state.users ||= [];
      return clone(state.users);
    },
    async createUser(user) {
      state.users ||= [];
      const index = state.users.findIndex((item) => item.id === user.id);
      if (index >= 0) state.users[index] = user;
      else state.users.unshift(user);
      state.logs.unshift(createAuditLog('监管运营员', '新增用户账号', user.id, '成功'));
      return clone(user);
    },
    async updateUser(user, action = '更新用户账号') {
      state.users ||= [];
      const index = state.users.findIndex((item) => item.id === user.id);
      if (index < 0) throw new Error(`用户不存在：${user.id}`);
      state.users[index] = user;
      state.logs.unshift(createAuditLog('监管运营员', action, user.id, '成功'));
      return clone(user);
    },
    async deleteUser(id) {
      state.users ||= [];
      const index = state.users.findIndex((item) => item.id === id);
      if (index < 0) throw new Error(`用户不存在：${id}`);
      const [user] = state.users.splice(index, 1);
      state.logs.unshift(createAuditLog('监管运营员', '删除用户账号', id, '成功'));
      return clone(user);
    },
    async listRolePermissions() {
      state.rolePermissions ||= [];
      return clone(state.rolePermissions);
    },
    async saveRolePermissions(permission) {
      state.rolePermissions ||= [];
      const index = state.rolePermissions.findIndex((item) => item.roleId === permission.roleId);
      if (index >= 0) state.rolePermissions[index] = permission;
      else state.rolePermissions.unshift(permission);
      state.logs.unshift(createAuditLog('监管运营员', '保存 RBAC 权限', permission.roleId, '成功'));
      return clone(permission);
    },
    async listLogs(filters = {}) {
      state.logs ||= [];
      return filterLogs(state.logs, filters);
    },
    async createLogSearchJob(job) {
      state.logSearchJobs ||= [];
      state.logSearchJobs.unshift(job);
      state.logs.unshift(createAuditLog('监管运营员', '创建审计检索任务', job.id, '成功'));
      return clone(job);
    },
    async listLogSearchJobs() {
      state.logSearchJobs ||= [];
      return clone(state.logSearchJobs);
    },
    async listOpsRuns(limit = 50) {
      state.opsRuns ||= [];
      return clone(state.opsRuns.slice(0, limit));
    },
    async createOpsRun(run) {
      state.opsRuns ||= [];
      state.opsRuns.unshift(run);
      state.logs.unshift(createAuditLog('监管运营员', `运维验收：${run.name}`, run.id, '成功'));
      return clone(run);
    },
    async listEvidenceBundles() {
      state.evidenceBundles ||= [];
      return normalizeDeviceNames({
        cameras: state.cameras,
        alarms: state.alarms,
        workOrders: state.workOrders,
        evidenceBundles: state.evidenceBundles,
      }).evidenceBundles;
    },
    async listImportJobs() {
      state.importJobs ||= [];
      return clone(state.importJobs);
    },
    async getImportJob(id) {
      state.importJobs ||= [];
      return clone(state.importJobs.find((item) => item.id === id));
    },
    async createImportJob(job) {
      state.importJobs ||= [];
      const index = state.importJobs.findIndex((item) => item.id === job.id);
      if (index >= 0) state.importJobs[index] = job;
      else state.importJobs.unshift(job);
      messageStorageRuntime = enforceMessageStorageQuotaForState(state);
      state.logs.unshift(createAuditLog('监管运营员', '创建导入分析任务', job.id, '成功'));
      return clone(job);
    },
    async updateImportJob(job, action = '更新导入分析任务') {
      state.importJobs ||= [];
      const index = state.importJobs.findIndex((item) => item.id === job.id);
      if (index < 0) throw new Error(`导入任务不存在：${job.id}`);
      state.importJobs[index] = job;
      state.logs.unshift(createAuditLog('监管运营员', action, job.id, '成功'));
      return clone(job);
    },
    async deleteImportJob(id) {
      state.importJobs ||= [];
      const index = state.importJobs.findIndex((item) => item.id === id);
      if (index < 0) throw new Error(`导入任务不存在：${id}`);
      const [removed] = state.importJobs.splice(index, 1);
      state.logs.unshift(createAuditLog('监管运营员', '删除导入分析任务', id, '成功'));
      return clone(removed);
    },
    async getEvidenceBundle(id) {
      state.evidenceBundles ||= [];
      return normalizeDeviceNames({
        cameras: state.cameras,
        alarms: state.alarms,
        workOrders: state.workOrders,
        evidenceBundles: state.evidenceBundles.filter((item) => item.id === id),
      }).evidenceBundles[0] || null;
    },
    async createEvidenceBundle(bundle) {
      state.evidenceBundles ||= [];
      const index = state.evidenceBundles.findIndex((item) => item.id === bundle.id);
      if (index >= 0) state.evidenceBundles[index] = bundle;
      else state.evidenceBundles.unshift(bundle);
      messageStorageRuntime = enforceMessageStorageQuotaForState(state);
      state.logs.unshift(createAuditLog('监管运营员', '固化证据链', bundle.id, '成功'));
      return clone(bundle);
    },
    async updateEvidenceBundle(bundle, action = '校验证据链') {
      state.evidenceBundles ||= [];
      const index = state.evidenceBundles.findIndex((item) => item.id === bundle.id);
      if (index < 0) throw new Error(`证据包不存在：${bundle.id}`);
      state.evidenceBundles[index] = bundle;
      state.logs.unshift(createAuditLog('监管运营员', action, bundle.id, '成功'));
      return clone(bundle);
    },
  };
}

function backfillMemoryEventGroups(state) {
  const activeStatuses = new Set(['待研判', '已确认', '已派单']);
  const alarms = [...(state.alarms || [])]
    .filter((alarm) => activeStatuses.has(alarm.status))
    .sort((a, b) => normalizeTimestamp(eventTimestampFallback(a)) - normalizeTimestamp(eventTimestampFallback(b)));
  for (const alarm of alarms) aggregateAlarmForMemoryState(state, alarm);
}

function aggregateAlarmForMemoryState(state, alarm) {
  const existingLink = state.eventGroupAlarmLinks.find((link) => link.alarmId === alarm.id);
  if (existingLink) return state.events.find((event) => event.id === existingLink.eventId) || null;

  const dedupeKey = normalizeEventDedupeKey(alarm);
  const openIndex = state.events.findIndex((event) => event.dedupeKey === dedupeKey && event.status === '待研判');
  const occurredAt = eventTimestampFallback(alarm);
  let aggregate;

  if (openIndex >= 0) {
    aggregate = mergeAggregateEvent(state.events[openIndex], alarm, {
      occurredAt,
      occurrenceIncrement: Math.max(1, Number(alarm.dedupeCount || 1)),
    });
    state.events.splice(openIndex, 1, aggregate);
  } else {
    aggregate = createAggregateEvent(alarm, { id: `EVT-${randomUUID()}`, occurredAt });
    aggregate.occurrenceCount = Math.max(1, Number(alarm.dedupeCount || 1));
    state.events.push(aggregate);
  }

  state.eventGroupAlarmLinks.push({ eventId: aggregate.id, alarmId: alarm.id, occurredAt });
  return aggregate;
}

function closeEventForMemoryState(state, alarmId, action, workOrderId = '') {
  const link = state.eventGroupAlarmLinks.find((item) => item.alarmId === alarmId);
  if (!link) return null;
  const index = state.events.findIndex((event) => event.id === link.eventId);
  if (index < 0) return null;
  const current = state.events[index];
  if (current.status !== '待研判') return current;
  const closed = closeAggregateEvent(current, action, { closedAt: nowIso(), workOrderId });
  state.events.splice(index, 1, closed);
  return closed;
}

function listMemoryEventGroups(state, filters = {}) {
  const includeHistory = String(filters.history || '').toLowerCase() === 'true';
  return (state.events || [])
    .filter((event) => includeHistory || event.status === '待研判')
    .filter((event) => !filters.status || event.status === filters.status)
    .filter((event) => !filters.cameraId || event.cameraId === filters.cameraId)
    .filter((event) => !filters.type || event.type === filters.type)
    .sort((a, b) => Date.parse(b.latestOccurredAt) - Date.parse(a.latestOccurredAt));
}

function eventTimestampFallback(alarm = {}, databaseTimestamp = '') {
  for (const value of [alarm.createdAt, alarm.occurredAt, alarm.updatedAt, databaseTimestamp]) {
    if (normalizeTimestamp(value) > 0) return new Date(normalizeTimestamp(value)).toISOString();
  }
  const epoch = String(alarm.id || '').match(/(?:^|[-_])(\d{13})(?:[-_]|$)/)?.[1];
  if (epoch && normalizeTimestamp(Number(epoch)) > 0) return new Date(Number(epoch)).toISOString();
  return nowIso();
}

function createMysqlStore(pool) {
  return {
    mode: 'mysql',
    async snapshot() {
      const runtimeConfig = await readRuntimeConfig(pool);
      const snapshot = normalizeDeviceNames({
        ...withRuntimeConfig({}, runtimeConfig),
        cameras: sortCameras(await readPayloads(pool, 'rw_camera', 'id')),
        alarms: await readPayloads(pool, 'rw_alarm', 'created_at DESC, id DESC'),
        events: await readEventGroups(pool),
        workOrders: await readWorkOrders(pool, 'created_at DESC, id DESC'),
        templates: await readPayloads(pool, 'rw_template', 'id'),
        algorithms: await readPayloads(pool, 'rw_algorithm', 'id'),
        uavTasks: await readPayloads(pool, 'rw_uav_task', 'created_at DESC, id DESC'),
        uavAssets: await readPayloads(pool, 'rw_uav_asset', 'id'),
        users: await readPayloads(pool, 'rw_user', 'id'),
        evidenceBundles: await readPayloads(pool, 'rw_evidence_bundle', 'sealed_at DESC, created_at DESC, id DESC'),
        importJobs: await readPayloads(pool, 'rw_import_job', 'created_at DESC, id DESC'),
        storageTiers: await readPayloads(pool, 'rw_storage_policy', 'created_at DESC, id DESC'),
        reportMetrics: await readPayloads(pool, 'rw_report_metric', 'id'),
        reportTasks: await readPayloads(pool, 'rw_report_task', 'created_at DESC, id DESC', 100),
        rolePermissions: await readPayloads(pool, 'rw_role_permission', 'role_id'),
        exportTasks: await readPayloads(pool, 'rw_export_task', 'created_at DESC, id DESC', 100),
        logs: await readPayloads(pool, 'rw_audit_log', 'created_at DESC, id DESC', 100),
        logSearchJobs: await readPayloads(pool, 'rw_log_search_job', 'created_at DESC, id DESC', 100),
        opsRuns: await readPayloads(pool, 'rw_ops_run', 'created_at DESC, id DESC', 50),
        operationTasks: await readPayloads(pool, 'rw_operation_task', 'created_at DESC, id DESC', 100),
        notifications: await readPayloads(pool, 'rw_notification', 'created_at DESC, id DESC', 100),
        playbackClips: await readPayloads(pool, 'rw_playback_clip', 'created_at DESC, id DESC', 100),
        notifyRules: await this.listNotifyRules(),
        aiEvents: await readAiEvents(pool, 100),
        runtimeConfig: sanitizeRuntimeConfig(runtimeConfig),
      });
      return isStrictProductionMode()
        ? applyStrictProductionSnapshot(snapshot, await readCameraStatuses(pool), await readAiWorkerStatuses(pool))
        : snapshot;
    },
    async listCameras(filters = {}) {
      const records = await readPayloads(pool, 'rw_camera', 'id');
      const cameras = isStrictProductionMode()
        ? applyCameraHeartbeats(records, await readCameraStatuses(pool), await readAiEvents(pool, 100), await readAiWorkerStatuses(pool))
        : records;
      return sortCameras(filterRecords(cameras, filters, ['status', 'protocol', 'group', 'node']));
    },
    async getCamera(id) {
      const [rows] = await pool.execute('SELECT payload FROM rw_camera WHERE id = ? LIMIT 1', [id]);
      const camera = rows[0] ? parsePayload(rows[0].payload) : null;
      if (!camera || !isStrictProductionMode()) return camera;
      return applyCameraHeartbeats([camera], await readCameraStatuses(pool), await readAiEvents(pool, 100), await readAiWorkerStatuses(pool))[0] || null;
    },
    async createCamera(camera) {
      await upsertCamera(pool, camera);
      await insertAuditLog(pool, createAuditLog('监管运营员', '新增设备', camera.id, '成功'));
      return clone(camera);
    },
    async updateCamera(camera) {
      const existing = await this.getCamera(camera.id);
      if (!existing) throw new Error(`设备不存在：${camera.id}`);
      await upsertCamera(pool, camera);
      await insertAuditLog(pool, createAuditLog('监管运营员', '修改设备', camera.id, '成功'));
      return clone(camera);
    },
    async deleteCamera(id) {
      const existing = await this.getCamera(id);
      if (!existing) throw new Error(`设备不存在：${id}`);
      await pool.execute('DELETE FROM rw_camera WHERE id = ?', [id]);
      await insertAuditLog(pool, createAuditLog('监管运营员', '删除设备', id, '成功'));
      return clone(existing);
    },
    async listUavAssets(filters = {}) {
      return filterRecords(await readPayloads(pool, 'rw_uav_asset', 'id'), filters, ['status', 'vendor', 'model', 'dockName']);
    },
    async getUavAsset(id) {
      const [rows] = await pool.execute('SELECT payload FROM rw_uav_asset WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? parsePayload(rows[0].payload) : null;
    },
    async createUavAsset(asset) {
      await upsertUavAsset(pool, asset);
      await insertAuditLog(pool, createAuditLog('监管运营员', '新增无人机设备', asset.id, '成功'));
      return clone(asset);
    },
    async updateUavAsset(asset) {
      const existing = await this.getUavAsset(asset.id);
      if (!existing) throw new Error(`无人机资产不存在：${asset.id}`);
      await upsertUavAsset(pool, asset);
      await insertAuditLog(pool, createAuditLog('监管运营员', '修改无人机设备', asset.id, '成功'));
      return clone(asset);
    },
    async deleteUavAsset(id) {
      const existing = await this.getUavAsset(id);
      if (!existing) throw new Error(`无人机资产不存在：${id}`);
      await pool.execute('DELETE FROM rw_uav_asset WHERE id = ?', [id]);
      await insertAuditLog(pool, createAuditLog('监管运营员', '删除无人机设备', id, '成功'));
      return clone(existing);
    },
    async listAlarms(filters = {}) {
      const records = await readPayloads(pool, 'rw_alarm', 'created_at DESC, id DESC');
      const cameras = sortCameras(await readPayloads(pool, 'rw_camera', 'id'));
      return normalizeDeviceNames({
        cameras,
        alarms: filterRecords(records, filters, ['status', 'severity', 'type', 'cameraId']),
      }).alarms;
    },
    async listEventGroups(filters = {}) {
      const events = await readEventGroups(pool, filters);
      const cameras = sortCameras(await readPayloads(pool, 'rw_camera', 'id'));
      return normalizeEventDeviceNames(events, cameras);
    },
    async getEventGroup(id) {
      const event = await readEventGroupById(pool, id);
      if (!event) return null;
      const cameras = sortCameras(await readPayloads(pool, 'rw_camera', 'id'));
      return normalizeEventDeviceNames([event], cameras)[0];
    },
    async createAlarm(alarm) {
      const connection = await pool.getConnection();
      let existing = false;
      try {
        await connection.beginTransaction();
        const [rows] = await connection.execute('SELECT id FROM rw_alarm WHERE id = ? LIMIT 1 FOR UPDATE', [alarm.id]);
        existing = Boolean(rows[0]);
        await upsertAlarm(connection, alarm);
        await aggregateAlarmForPool(connection, alarm);
        await connection.commit();
      } catch (error) {
        await connection.rollback();
        throw error;
      } finally {
        connection.release();
      }
      await enforceMessageStorageQuotaForPool(pool);
      await insertAuditLog(pool, createAuditLog(alarm.owner || 'AI 推理服务', existing ? '更新告警' : '创建告警', alarm.id, '成功'));
      return clone(alarm);
    },
    async reviewAlarm(id, status, makeWorkOrder) {
      const connection = await pool.getConnection();
      let alarm;
      let workOrder = null;
      try {
        await connection.beginTransaction();
        const [rows] = await connection.execute('SELECT payload FROM rw_alarm WHERE id = ? LIMIT 1 FOR UPDATE', [id]);
        if (!rows[0]) throw new Error(`告警不存在：${id}`);

        alarm = parsePayload(rows[0].payload);
        const [cameraRows] = await connection.execute('SELECT name FROM rw_camera WHERE id = ? LIMIT 1', [alarm.cameraId]);
        if (cameraRows[0]?.name) alarm.cameraName = cameraRows[0].name;
        applyAlarmReviewStatus(alarm, status);

        if (alarm.status === '已归档' && (alarm.reviewResult === '忽略' || alarm.reviewResult === '已处理')) {
          await connection.execute('DELETE FROM rw_work_order WHERE alarm_id = ?', [alarm.id]);
          const [countRows] = await connection.execute('SELECT COUNT(*) AS count FROM rw_work_order');
          workOrder = createClosedWorkOrderFromAlarm(alarm, makeWorkOrder, 9200 + Number(countRows[0].count || 0));
          await upsertWorkOrder(connection, workOrder);
          await closeEventGroupForAlarmPool(connection, alarm.id, alarm.reviewResult, workOrder?.id);
        }

        await upsertAlarm(connection, alarm);
        await connection.commit();
      } catch (error) {
        await connection.rollback();
        throw error;
      } finally {
        connection.release();
      }
      await insertAuditLog(pool, createAuditLog('监管运营员', '研判告警', alarm.id, '成功'));

      return { alarm: clone(alarm), workOrder: clone(workOrder) };
    },
    async listWorkOrders() {
      return normalizeDeviceNames({
        cameras: sortCameras(await readPayloads(pool, 'rw_camera', 'id')),
        alarms: await readPayloads(pool, 'rw_alarm', 'created_at DESC, id DESC'),
        workOrders: await readWorkOrders(pool, 'created_at DESC, id DESC'),
      }).workOrders;
    },
    async getWorkOrder(id) {
      const [rows] = await pool.execute('SELECT payload FROM rw_work_order WHERE id = ? LIMIT 1', [id]);
      return rows[0]
        ? normalizeDeviceNames({
            cameras: sortCameras(await readPayloads(pool, 'rw_camera', 'id')),
            alarms: await readPayloads(pool, 'rw_alarm', 'created_at DESC, id DESC'),
            workOrders: [parsePayload(rows[0].payload)],
          }).workOrders[0]
        : null;
    },
    async createWorkOrder(order) {
      await upsertWorkOrder(pool, order);
      await enforceMessageStorageQuotaForPool(pool);
      await insertAuditLog(pool, createAuditLog('监管运营员', '新建工单', order.id, '成功'));
      return clone(order);
    },
    async updateWorkOrder(order, action = '更新工单') {
      await upsertWorkOrder(pool, order);
      await insertAuditLog(pool, createAuditLog('监管运营员', action, order.id, '成功'));
      return clone(order);
    },
    async ingestMetadata(event) {
      const existing = await getAiEvent(pool, event.eventId);
      if (existing?.result) return clone(existing.result);
      const alarm = event.alarm;
      const result = { alarm, workOrder: event.workOrder };
      const connection = await pool.getConnection();
      try {
        await connection.beginTransaction();
        await upsertAlarm(connection, alarm);
        await aggregateAlarmForPool(connection, alarm);
        await insertAiEvent(connection, {
          id: event.eventId,
          alarmId: alarm.id,
          cameraId: alarm.cameraId,
          payload: { request: event.payload, result, retryCount: 0 },
        });
        if (event.workOrder) await upsertWorkOrder(connection, event.workOrder);
        await connection.commit();
      } catch (error) {
        await connection.rollback();
        throw error;
      } finally {
        connection.release();
      }
      await enforceMessageStorageQuotaForPool(pool);
      await insertAuditLog(pool, createAuditLog('AI 推理服务', '元数据回传', event.alarm.id, '成功'));
      return clone(result);
    },
    async getAlarmEvidence(alarmId) {
      return getAlarmEvidence(pool, alarmId);
    },
    async saveAlarmEvidence(record) {
      await upsertAlarmEvidence(pool, record);
      const maxRecords = Math.max(1, Number(process.env.ALARM_EVIDENCE_MAX_RECORDS || 5000));
      const [rows] = await pool.query('SELECT COUNT(*) AS count FROM rw_alarm_evidence');
      const overflow = Math.max(0, Number(rows[0]?.count || 0) - maxRecords);
      if (overflow > 0) {
        await pool.query(`DELETE FROM rw_alarm_evidence ORDER BY captured_at ASC LIMIT ${Math.floor(overflow)}`);
      }
      return getAlarmEvidence(pool, record.alarmId);
    },
    async listAiEvents(limit = 100) {
      return normalizeDeviceNames({
        cameras: sortCameras(await readPayloads(pool, 'rw_camera', 'id')),
        alarms: await readPayloads(pool, 'rw_alarm', 'created_at DESC, id DESC'),
        workOrders: await readWorkOrders(pool, 'created_at DESC, id DESC'),
        aiEvents: await readAiEvents(pool, limit),
      }).aiEvents;
    },
    async getAiEvent(id) {
      return getAiEvent(pool, id);
    },
    async retryAiEvent(id) {
      const event = await getAiEvent(pool, id);
      if (!event) throw new Error(`AI 事件不存在：${id}`);
      event.retryCount = Number(event.retryCount || 0) + 1;
      event.retryStatus = 'queued';
      await pool.execute('UPDATE rw_ai_event SET payload = ? WHERE id = ?', [stringifyPayload(event), id]);
      await insertAuditLog(pool, createAuditLog('监管运营员', '重试 AI 事件', id, '成功'));
      return clone({ eventId: id, status: 'queued', retryCount: event.retryCount });
    },
    async createExportTask(task) {
      await upsertExportTask(pool, task);
      await insertAuditLog(pool, createAuditLog('监管运营员', '创建导出任务', task.id, '成功'));
      return clone(task);
    },
    async createOperationTask(task) {
      await upsertOperationTask(pool, task);
      await enforceMessageStorageQuotaForPool(pool);
      await insertAuditLog(pool, createAuditLog('监管运营员', `提交${task.moduleName}${task.actionName}`, task.id, '成功'));
      return clone(task);
    },
    async getAlgorithm(id) {
      const [rows] = await pool.execute('SELECT payload FROM rw_algorithm WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? parsePayload(rows[0].payload) : null;
    },
    async createAlgorithm(algorithm) {
      await upsertAlgorithm(pool, algorithm);
      await insertAuditLog(pool, createAuditLog('监管运营员', '导入算法模型', algorithm.id, '成功'));
      return clone(algorithm);
    },
    async updateAlgorithm(algorithm) {
      const existing = await this.getAlgorithm(algorithm.id);
      if (!existing) throw new Error(`模型不存在：${algorithm.id}`);
      await upsertAlgorithm(pool, algorithm);
      await insertAuditLog(pool, createAuditLog('监管运营员', '修改模型配置', algorithm.id, '成功'));
      return clone(algorithm);
    },
    async getTemplate(id) {
      const [rows] = await pool.execute('SELECT payload FROM rw_template WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? parsePayload(rows[0].payload) : null;
    },
    async createTemplate(template) {
      await upsertTemplate(pool, template);
      await insertAuditLog(pool, createAuditLog('监管运营员', '新增通配模板', template.id, '成功'));
      return clone(template);
    },
    async updateTemplate(template) {
      const existing = await this.getTemplate(template.id);
      if (!existing) throw new Error(`模板不存在：${template.id}`);
      await upsertTemplate(pool, template);
      await insertAuditLog(pool, createAuditLog('监管运营员', '修改通配模板', template.id, '成功'));
      return clone(template);
    },
    async deleteTemplate(id) {
      const existing = await this.getTemplate(id);
      if (!existing) throw new Error(`模板不存在：${id}`);
      await pool.execute('DELETE FROM rw_template WHERE id = ?', [id]);
      await insertAuditLog(pool, createAuditLog('监管运营员', '删除通配模板', id, '成功'));
      return clone(existing);
    },
    async listOperationTasks(limit = 100) {
      return readPayloads(pool, 'rw_operation_task', 'created_at DESC, id DESC', limit);
    },
    async createPlaybackClip(clip) {
      await upsertPlaybackClip(pool, clip);
      await enforceMessageStorageQuotaForPool(pool);
      await insertAuditLog(pool, createAuditLog('监管运营员', '回放裁剪导出', clip.id, '成功'));
      return clone(clip);
    },
    async listPlaybackClips(limit = 100) {
      return readPayloads(pool, 'rw_playback_clip', 'created_at DESC, id DESC', limit);
    },
    async createUavTask(task) {
      await upsertUavTask(pool, task);
      await insertAuditLog(pool, createAuditLog('监管运营员', '发起无人机复查', task.id, '成功'));
      return clone(task);
    },
    async listNotifications(limit = 100) {
      return readPayloads(pool, 'rw_notification', 'created_at DESC, id DESC', limit);
    },
    async getNotification(id) {
      const [rows] = await pool.execute('SELECT payload FROM rw_notification WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? parsePayload(rows[0].payload) : null;
    },
    async createNotification(notification) {
      await upsertNotification(pool, notification);
      await enforceMessageStorageQuotaForPool(pool);
      await insertAuditLog(pool, createAuditLog('消息通知服务', `发送${notification.channel}通知`, notification.id, notification.status === '发送失败' ? '失败' : '成功'));
      return clone(notification);
    },
    async updateNotification(notification, action = '更新通知') {
      const existing = await this.getNotification(notification.id);
      if (!existing) throw new Error(`通知不存在：${notification.id}`);
      await upsertNotification(pool, notification);
      await insertAuditLog(pool, createAuditLog('消息通知服务', action, notification.id, '成功'));
      return clone(notification);
    },
    async listNotifyRules() {
      const records = await readPayloads(pool, 'rw_notify_rule', 'id');
      return records.length ? records : defaultNotifyRules();
    },
    async saveNotifyRule(rule) {
      await upsertNotifyRule(pool, rule);
      await insertAuditLog(pool, createAuditLog('平台管理员', '更新通知规则', rule.id, '成功'));
      return clone(rule);
    },
    async getRuntimeConfig(key) {
      const [rows] = await pool.execute('SELECT payload FROM rw_runtime_config WHERE config_key = ? LIMIT 1', [key]);
      return rows[0] ? parsePayload(rows[0].payload) : null;
    },
    async saveRuntimeConfig(record) {
      if (!record?.key) throw new Error('runtime config key is required');
      const next = {
        key: record.key,
        group: record.group || 'runtime',
        value: clone(record.value ?? {}),
        updatedAt: record.updatedAt || nowIso(),
      };
      await upsertRuntimeConfig(pool, next);
      return clone(next.value);
    },
    async listDiagnosticSteps(status = '在线') {
      const profiles = (await this.getRuntimeConfig('diagnostics')) || {};
      return clone(isBadDeviceStatus(status) ? profiles.failed || [] : profiles.healthy || []);
    },
    async listAiWorkers() {
      const workers = clone((await this.getRuntimeConfig('aiWorkers')) || []);
      return isStrictProductionMode() ? applyAiWorkerHeartbeats(workers, await readAiWorkerStatuses(pool)) : workers;
    },
    async recordCameraStatus(status) {
      const record = normalizeCameraStatus(status);
      const existing = await readCameraStatusById(pool, record.cameraId);
      if (shouldPreserveCameraStatus(existing, record)) return clone(existing);
      await upsertCameraStatus(pool, record);
      return clone(record);
    },
    async listCameraStatuses() {
      return readCameraStatuses(pool);
    },
    async recordAiWorkerStatus(status) {
      const record = normalizeAiWorkerStatus(status);
      await upsertAiWorkerStatus(pool, record);
      return clone(record);
    },
    async listAiWorkerStatuses() {
      return readAiWorkerStatuses(pool);
    },
    async listOperationRoutes() {
      return clone((await this.getRuntimeConfig('operationRoutes')) || []);
    },
    async listStoragePolicies() {
      return readStoragePolicies(pool);
    },
    async messageStorageStatus() {
      return messageStorageStatusFromPool(pool);
    },
    async createStoragePolicy(policy) {
      const saved = await upsertStoragePolicy(pool, policy);
      await insertAuditLog(pool, createAuditLog('监管运营员', '保存存储策略', saved.id || saved.name, '成功'));
      return clone(saved);
    },
    async updateStoragePolicy(policy) {
      const saved = await upsertStoragePolicy(pool, policy);
      await insertAuditLog(pool, createAuditLog('监管运营员', '更新存储策略', saved.id || saved.name, '成功'));
      return clone(saved);
    },
    async listReportMetrics() {
      return readPayloads(pool, 'rw_report_metric', 'id');
    },
    async listReportTasks() {
      return readPayloads(pool, 'rw_report_task', 'created_at DESC, id DESC', 100);
    },
    async createReportTask(task) {
      await upsertReportTask(pool, task);
      await enforceMessageStorageQuotaForPool(pool);
      await insertAuditLog(pool, createAuditLog('监管运营员', '创建报表任务', task.id, '成功'));
      return clone(task);
    },
    async listUsers() {
      return readPayloads(pool, 'rw_user', 'id');
    },
    async createUser(user) {
      await upsertUser(pool, user);
      await insertAuditLog(pool, createAuditLog('监管运营员', '新增用户账号', user.id, '成功'));
      return clone(user);
    },
    async updateUser(user, action = '更新用户账号') {
      await upsertUser(pool, user);
      await insertAuditLog(pool, createAuditLog('监管运营员', action, user.id, '成功'));
      return clone(user);
    },
    async deleteUser(id) {
      const users = await this.listUsers();
      const user = users.find((item) => item.id === id);
      if (!user) throw new Error(`用户不存在：${id}`);
      await pool.execute('DELETE FROM rw_user WHERE id = ?', [id]);
      await insertAuditLog(pool, createAuditLog('监管运营员', '删除用户账号', id, '成功'));
      return clone(user);
    },
    async listRolePermissions() {
      return readPayloads(pool, 'rw_role_permission', 'role_id');
    },
    async saveRolePermissions(permission) {
      await upsertRolePermission(pool, permission);
      await insertAuditLog(pool, createAuditLog('监管运营员', '保存 RBAC 权限', permission.roleId, '成功'));
      return clone(permission);
    },
    async listLogs(filters = {}) {
      const records = await readPayloads(pool, 'rw_audit_log', 'created_at DESC, id DESC', Number(filters.limit || 200));
      return filterLogs(records, filters);
    },
    async createLogSearchJob(job) {
      await upsertLogSearchJob(pool, job);
      await insertAuditLog(pool, createAuditLog('监管运营员', '创建审计检索任务', job.id, '成功'));
      return clone(job);
    },
    async listLogSearchJobs() {
      return readPayloads(pool, 'rw_log_search_job', 'created_at DESC, id DESC', 100);
    },
    async listOpsRuns(limit = 50) {
      return readPayloads(pool, 'rw_ops_run', 'created_at DESC, id DESC', limit);
    },
    async createOpsRun(run) {
      await upsertOpsRun(pool, run);
      await insertAuditLog(pool, createAuditLog('监管运营员', `运维验收：${run.name}`, run.id, '成功'));
      return clone(run);
    },
    async listEvidenceBundles() {
      return normalizeDeviceNames({
        cameras: sortCameras(await readPayloads(pool, 'rw_camera', 'id')),
        alarms: await readPayloads(pool, 'rw_alarm', 'created_at DESC, id DESC'),
        workOrders: await readWorkOrders(pool, 'created_at DESC, id DESC'),
        evidenceBundles: await readPayloads(pool, 'rw_evidence_bundle', 'sealed_at DESC, created_at DESC, id DESC'),
      }).evidenceBundles;
    },
    async listImportJobs() {
      return readPayloads(pool, 'rw_import_job', 'created_at DESC, id DESC');
    },
    async getImportJob(id) {
      const [rows] = await pool.execute('SELECT payload FROM rw_import_job WHERE id = ? LIMIT 1', [id]);
      return rows[0] ? parsePayload(rows[0].payload) : null;
    },
    async createImportJob(job) {
      await upsertImportJob(pool, job);
      await enforceMessageStorageQuotaForPool(pool);
      await insertAuditLog(pool, createAuditLog('监管运营员', '创建导入分析任务', job.id, '成功'));
      return clone(job);
    },
    async updateImportJob(job, action = '更新导入分析任务') {
      await upsertImportJob(pool, job);
      await insertAuditLog(pool, createAuditLog('监管运营员', action, job.id, '成功'));
      return clone(job);
    },
    async deleteImportJob(id) {
      const existing = await this.getImportJob(id);
      if (!existing) throw new Error(`导入任务不存在：${id}`);
      await pool.execute('DELETE FROM rw_import_job WHERE id = ?', [id]);
      await insertAuditLog(pool, createAuditLog('监管运营员', '删除导入分析任务', id, '成功'));
      return clone(existing);
    },
    async getEvidenceBundle(id) {
      const [rows] = await pool.execute('SELECT payload FROM rw_evidence_bundle WHERE id = ? LIMIT 1', [id]);
      return rows[0]
        ? normalizeDeviceNames({
            cameras: sortCameras(await readPayloads(pool, 'rw_camera', 'id')),
            alarms: await readPayloads(pool, 'rw_alarm', 'created_at DESC, id DESC'),
            workOrders: await readWorkOrders(pool, 'created_at DESC, id DESC'),
            evidenceBundles: [parsePayload(rows[0].payload)],
          }).evidenceBundles[0]
        : null;
    },
    async createEvidenceBundle(bundle) {
      await upsertEvidenceBundle(pool, bundle);
      await enforceMessageStorageQuotaForPool(pool);
      await insertAuditLog(pool, createAuditLog('监管运营员', '固化证据链', bundle.id, '成功'));
      return clone(bundle);
    },
    async updateEvidenceBundle(bundle, action = '校验证据链') {
      await upsertEvidenceBundle(pool, bundle);
      await insertAuditLog(pool, createAuditLog('监管运营员', action, bundle.id, '成功'));
      return clone(bundle);
    },
  };
}

async function waitForDatabase(pool) {
  const retries = Number(process.env.DB_CONNECT_RETRIES || 60);
  const intervalMs = Number(process.env.DB_CONNECT_INTERVAL_MS || 2000);
  let lastError;

  for (let i = 0; i < retries; i += 1) {
    try {
      await pool.query('SELECT 1');
      return;
    } catch (error) {
      lastError = error;
      await new Promise((resolve) => setTimeout(resolve, intervalMs));
    }
  }

  throw lastError;
}

async function ensureRuntimeSchema(pool) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_camera (
      id VARCHAR(32) PRIMARY KEY,
      name VARCHAR(128) NOT NULL,
      status VARCHAR(32) NOT NULL,
      protocol VARCHAR(32) NOT NULL,
      group_tag VARCHAR(64),
      node VARCHAR(64),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_camera_status(status),
      KEY idx_rw_camera_node(node)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_alarm (
      id VARCHAR(40) PRIMARY KEY,
      camera_id VARCHAR(32) NOT NULL,
      type VARCHAR(80) NOT NULL,
      severity VARCHAR(32) NOT NULL,
      status VARCHAR(32) NOT NULL,
      confidence DECIMAL(6,2),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_alarm_status(status),
      KEY idx_rw_alarm_camera(camera_id),
      KEY idx_rw_alarm_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_event_group (
      id VARCHAR(64) PRIMARY KEY,
      dedupe_key VARCHAR(255) NOT NULL,
      open_dedupe_key VARCHAR(255) NULL,
      camera_id VARCHAR(32) NOT NULL,
      type VARCHAR(80) NOT NULL,
      severity VARCHAR(32) NOT NULL,
      status VARCHAR(32) NOT NULL,
      first_alarm_id VARCHAR(40) NOT NULL,
      latest_alarm_id VARCHAR(40) NOT NULL,
      first_occurred_at DATETIME(3) NOT NULL,
      latest_occurred_at DATETIME(3) NOT NULL,
      occurrence_count INT UNSIGNED NOT NULL DEFAULT 1,
      payload JSON NOT NULL,
      created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3),
      updated_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      UNIQUE KEY uq_rw_event_group_open(open_dedupe_key),
      KEY idx_rw_event_group_latest(status, latest_occurred_at),
      KEY idx_rw_event_group_camera(camera_id, type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_event_group_alarm (
      alarm_id VARCHAR(40) PRIMARY KEY,
      event_id VARCHAR(64) NOT NULL,
      occurred_at DATETIME(3) NOT NULL,
      created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3),
      KEY idx_rw_event_group_alarm_event(event_id, occurred_at),
      CONSTRAINT fk_rw_event_group_alarm_event FOREIGN KEY (event_id) REFERENCES rw_event_group(id) ON DELETE CASCADE,
      CONSTRAINT fk_rw_event_group_alarm_alarm FOREIGN KEY (alarm_id) REFERENCES rw_alarm(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_work_order (
      id VARCHAR(40) PRIMARY KEY,
      alarm_id VARCHAR(40),
      status VARCHAR(32) NOT NULL,
      priority VARCHAR(32),
      assignee VARCHAR(80),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_order_alarm(alarm_id),
      KEY idx_rw_order_status(status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_user (
      id VARCHAR(40) PRIMARY KEY,
      name VARCHAR(80) NOT NULL,
      role_name VARCHAR(80),
      org_name VARCHAR(120),
      status VARCHAR(32),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_user_status(status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_template (
      id VARCHAR(64) PRIMARY KEY,
      template_name VARCHAR(128),
      scene_name VARCHAR(80),
      version_text VARCHAR(40),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_template_scene(scene_name),
      KEY idx_rw_template_version(version_text)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_algorithm (
      id VARCHAR(64) PRIMARY KEY,
      model_name VARCHAR(128),
      family_name VARCHAR(80),
      node_name VARCHAR(80),
      format_name VARCHAR(40),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_algorithm_family(family_name, format_name),
      KEY idx_rw_algorithm_node(node_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_uav_task (
      id VARCHAR(64) PRIMARY KEY,
      task_name VARCHAR(160),
      status VARCHAR(40),
      dock_name VARCHAR(120),
      related_alarm_id VARCHAR(40),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_uav_status(status),
      KEY idx_rw_uav_alarm(related_alarm_id),
      KEY idx_rw_uav_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_uav_asset (
      id VARCHAR(64) PRIMARY KEY,
      asset_name VARCHAR(160),
      vendor_name VARCHAR(80),
      model_name VARCHAR(120),
      dock_name VARCHAR(120),
      status VARCHAR(40),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_uav_asset_status(status),
      KEY idx_rw_uav_asset_vendor(vendor_name, model_name),
      KEY idx_rw_uav_asset_dock(dock_name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_ai_event (
      id VARCHAR(64) PRIMARY KEY,
      alarm_id VARCHAR(40),
      camera_id VARCHAR(32),
      payload JSON NOT NULL,
      received_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      KEY idx_rw_ai_camera(camera_id, received_at),
      KEY idx_rw_ai_alarm(alarm_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_alarm_evidence (
      alarm_id VARCHAR(40) PRIMARY KEY,
      event_id VARCHAR(64),
      camera_id VARCHAR(32),
      mime_type VARCHAR(80) NOT NULL,
      byte_size INT UNSIGNED NOT NULL,
      media_data MEDIUMBLOB NOT NULL,
      annotation_data JSON NULL,
      captured_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      KEY idx_rw_alarm_evidence_camera(camera_id, captured_at),
      KEY idx_rw_alarm_evidence_captured(captured_at),
      CONSTRAINT fk_rw_alarm_evidence_alarm FOREIGN KEY (alarm_id) REFERENCES rw_alarm(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);
  await ensureColumn(pool, 'rw_alarm_evidence', 'annotation_data', 'JSON NULL AFTER media_data');

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_export_task (
      id VARCHAR(64) PRIMARY KEY,
      module_name VARCHAR(80),
      status VARCHAR(32),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_export_status(module_name, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_audit_log (
      id VARCHAR(64) PRIMARY KEY,
      time_text VARCHAR(32),
      operator_name VARCHAR(80),
      action VARCHAR(120),
      target VARCHAR(120),
      result VARCHAR(32),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      KEY idx_rw_audit_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_operation_task (
      id VARCHAR(64) PRIMARY KEY,
      module_name VARCHAR(80),
      action_name VARCHAR(80),
      status VARCHAR(32),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_operation_module(module_name, action_name, status),
      KEY idx_rw_operation_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_playback_clip (
      id VARCHAR(64) PRIMARY KEY,
      camera_id VARCHAR(32),
      alarm_id VARCHAR(40),
      evidence_bundle_id VARCHAR(64),
      status VARCHAR(32),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      KEY idx_rw_clip_camera(camera_id, created_at),
      KEY idx_rw_clip_alarm(alarm_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_notification (
      id VARCHAR(64) PRIMARY KEY,
      alarm_id VARCHAR(40),
      severity VARCHAR(16),
      channel VARCHAR(32),
      status VARCHAR(32),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_notification_alarm(alarm_id),
      KEY idx_rw_notification_status(channel, status),
      KEY idx_rw_notification_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_notify_rule (
      id VARCHAR(64) PRIMARY KEY,
      severity VARCHAR(16),
      enabled TINYINT(1) DEFAULT 1,
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_notify_rule_severity(severity, enabled)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_evidence_bundle (
      id VARCHAR(64) PRIMARY KEY,
      alarm_id VARCHAR(40),
      status VARCHAR(32),
      hash_value VARCHAR(128),
      sealed_at DATETIME,
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_evidence_alarm(alarm_id),
      KEY idx_rw_evidence_status(status),
      KEY idx_rw_evidence_sealed(sealed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_import_job (
      id VARCHAR(64) PRIMARY KEY,
      source_name VARCHAR(160),
      media_type VARCHAR(32),
      status VARCHAR(32),
      confidence DECIMAL(6,2),
      related_alarm_id VARCHAR(40),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_import_status(status),
      KEY idx_rw_import_alarm(related_alarm_id),
      KEY idx_rw_import_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_storage_policy (
      id VARCHAR(64) PRIMARY KEY,
      policy_name VARCHAR(120),
      tier_name VARCHAR(64),
      usage_percent DECIMAL(6,2),
      protected_evidence TINYINT(1),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_storage_tier(tier_name),
      KEY idx_rw_storage_protected(protected_evidence)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_report_metric (
      id VARCHAR(64) PRIMARY KEY,
      metric_name VARCHAR(120),
      metric_value VARCHAR(64),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_report_task (
      id VARCHAR(64) PRIMARY KEY,
      report_name VARCHAR(160),
      report_type VARCHAR(64),
      status VARCHAR(32),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_report_status(report_type, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_role_permission (
      role_id VARCHAR(80) PRIMARY KEY,
      role_name VARCHAR(120),
      data_scope VARCHAR(80),
      payload JSON NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_role_scope(data_scope)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_log_search_job (
      id VARCHAR(64) PRIMARY KEY,
      query_text VARCHAR(200),
      result_count INT,
      status VARCHAR(32),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_log_search_status(status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_runtime_config (
      config_key VARCHAR(80) PRIMARY KEY,
      config_group VARCHAR(40),
      payload JSON NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_runtime_config_group(config_group)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_camera_status (
      camera_id VARCHAR(40) PRIMARY KEY,
      status VARCHAR(32) NOT NULL,
      source VARCHAR(64),
      bitrate VARCHAR(32),
      latency INT,
      detail VARCHAR(255),
      payload JSON NOT NULL,
      heartbeat_at DATETIME NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_camera_status_heartbeat(heartbeat_at),
      KEY idx_rw_camera_status_source(source)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_ai_worker_status (
      worker_id VARCHAR(80) PRIMARY KEY,
      status VARCHAR(32) NOT NULL,
      source VARCHAR(64),
      fps DECIMAL(10,2),
      latency_ms INT,
      detail VARCHAR(255),
      payload JSON NOT NULL,
      heartbeat_at DATETIME NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_ai_worker_status_heartbeat(heartbeat_at),
      KEY idx_rw_ai_worker_status_source(source)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rw_ops_run (
      id VARCHAR(64) PRIMARY KEY,
      run_type VARCHAR(40),
      status VARCHAR(32),
      manifest_hash VARCHAR(128),
      payload JSON NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_rw_ops_type(run_type, status),
      KEY idx_rw_ops_created(created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
  `);
}

async function ensureColumn(pool, tableName, columnName, definition) {
  const [rows] = await pool.execute(
    'SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1',
    [tableName, columnName],
  );
  if (!rows.length) await pool.query(`ALTER TABLE \`${tableName}\` ADD COLUMN \`${columnName}\` ${definition}`);
}

async function seedRuntimeTables(pool, seed, options = {}) {
  if (options.strictProduction) {
    await seedProductionControlPlane(pool, seed);
    return;
  }

  if ((await tableCount(pool, 'rw_camera')) === 0) {
    for (const camera of seed.cameras) await upsertCamera(pool, camera);
  }
  await ensureRequiredCameraChannels(pool, seed);
  if ((await tableCount(pool, 'rw_alarm')) === 0) {
    for (const alarm of seed.alarms) await upsertAlarm(pool, alarm);
  }
  if ((await tableCount(pool, 'rw_work_order')) === 0) {
    for (const order of seed.workOrders) await upsertWorkOrder(pool, order);
  }
  if ((await tableCount(pool, 'rw_user')) === 0) {
    for (const user of seed.users) await upsertUser(pool, user);
  }
  await seedMissingRuntimeRecords(pool, 'rw_template', 'id', seed.templates || [], (item) => item.id, upsertTemplate);
  await seedMissingRuntimeRecords(pool, 'rw_algorithm', 'id', seed.algorithms || [], (item) => item.id, upsertAlgorithm);
  await seedMissingRuntimeRecords(pool, 'rw_uav_task', 'id', seed.uavTasks || [], (item) => item.id, upsertUavTask);
  await seedMissingRuntimeRecords(pool, 'rw_uav_asset', 'id', seed.uavAssets || [], (item) => item.id, upsertUavAsset);
  if ((await tableCount(pool, 'rw_evidence_bundle')) === 0) {
    for (const bundle of seed.evidenceBundles) await upsertEvidenceBundle(pool, bundle);
  }
  if ((await tableCount(pool, 'rw_import_job')) === 0) {
    for (const job of seed.importJobs) await upsertImportJob(pool, job);
  }
  if ((await tableCount(pool, 'rw_storage_policy')) === 0) {
    for (const policy of seed.storageTiers) await upsertStoragePolicy(pool, normalizeSeedStoragePolicy(policy));
  }
  if ((await tableCount(pool, 'rw_report_metric')) === 0) {
    for (const metric of seed.reportMetrics) await upsertReportMetric(pool, normalizeSeedReportMetric(metric));
  }
  if ((await tableCount(pool, 'rw_role_permission')) === 0) {
    for (const permission of seed.rolePermissions || defaultRolePermissions()) await upsertRolePermission(pool, permission);
  }
  if ((await tableCount(pool, 'rw_audit_log')) === 0) {
    for (const log of seed.logs) await insertAuditLog(pool, log);
  }
  if ((await tableCount(pool, 'rw_notify_rule')) === 0) {
    for (const rule of seed.notifyRules || defaultNotifyRules()) await upsertNotifyRule(pool, rule);
  }
  await seedRuntimeConfig(pool, seed.runtimeConfig || []);
}

async function seedProductionControlPlane(pool, seed) {
  if ((await tableCount(pool, 'rw_user')) === 0) {
    for (const user of seed.users || []) await upsertUser(pool, user);
  }
  await seedMissingRuntimeRecords(pool, 'rw_template', 'id', seed.templates || [], (item) => item.id, upsertTemplate);
  await seedMissingRuntimeRecords(pool, 'rw_uav_asset', 'id', seed.uavAssets || [], (item) => item.id, upsertUavAsset);
  if ((await tableCount(pool, 'rw_role_permission')) === 0) {
    for (const permission of seed.rolePermissions || defaultRolePermissions()) await upsertRolePermission(pool, permission);
  }
  if ((await tableCount(pool, 'rw_notify_rule')) === 0) {
    for (const rule of seed.notifyRules || defaultNotifyRules()) await upsertNotifyRule(pool, rule);
  }
  await seedRuntimeConfig(pool, productionRuntimeConfig(seed.runtimeConfig || []));
}

function productionRuntimeConfig(records) {
  return records.map((record) => {
    if (record.key === 'navItems' && Array.isArray(record.value)) {
      return { ...record, value: stripNavBadges(record.value) };
    }
    if (record.key === 'aiWorkers' && Array.isArray(record.value)) {
      return {
        ...record,
        value: record.value.map((worker) => ({
          ...worker,
          status: 'offline',
          fps: 0,
          latencyMs: 0,
          statusSource: 'worker-heartbeat',
          statusDetail: 'waiting for real worker heartbeat',
        })),
      };
    }
    return record;
  });
}

async function tableCount(pool, table) {
  const [rows] = await pool.query(`SELECT COUNT(*) AS count FROM ${table}`);
  return Number(rows[0].count || 0);
}

async function seedMissingRuntimeRecords(pool, table, keyColumn, records, keyOf, upsertRecord) {
  for (const record of records) {
    const key = keyOf(record);
    if (!key) continue;
    const [rows] = await pool.execute(`SELECT ${keyColumn} FROM ${table} WHERE ${keyColumn} = ? LIMIT 1`, [key]);
    if (rows.length === 0) await upsertRecord(pool, record);
  }
}

async function seedRuntimeConfig(pool, records) {
  for (const record of records) {
    if (!record?.key) continue;
    const [rows] = await pool.execute('SELECT payload FROM rw_runtime_config WHERE config_key = ? LIMIT 1', [record.key]);
    if (rows.length === 0) {
      await upsertRuntimeConfig(pool, record);
      continue;
    }

    const current = parsePayload(rows[0].payload);
    const merged = mergeRuntimeValue(record.key, current, record.value);
    if (JSON.stringify(merged) !== JSON.stringify(current)) {
      await upsertRuntimeConfig(pool, { ...record, value: merged });
    }
  }
}

function mergeRuntimeValue(key, current, seedValue) {
  if (Array.isArray(current) && Array.isArray(seedValue)) {
    const keyField = key === 'operationRoutes' ? 'path' : key === 'navItems' ? 'key' : 'id';
    const merged = mergeArrayByKey(current, seedValue, keyField);
    return key === 'navItems' ? stripNavBadges(merged) : merged;
  }

  if (isPlainObject(current) && isPlainObject(seedValue)) {
    return mergeMissingObject(current, seedValue);
  }

  return current ?? seedValue;
}

function mergeMissingObject(current, seedValue) {
  const merged = { ...current };

  for (const [key, value] of Object.entries(seedValue || {})) {
    if (merged[key] === undefined || merged[key] === null) {
      merged[key] = value;
    } else if (Array.isArray(merged[key]) && Array.isArray(value)) {
      merged[key] = mergeArrayByKey(merged[key], value, 'key');
    } else if (isPlainObject(merged[key]) && isPlainObject(value)) {
      merged[key] = mergeMissingObject(merged[key], value);
    }
  }

  return merged;
}

function mergeArrayByKey(current, seedValue, keyField) {
  const merged = [...current];
  const seen = new Set(merged.map((item) => (isPlainObject(item) ? item[keyField] : item)).filter(Boolean));

  for (const item of seedValue) {
    const key = isPlainObject(item) ? item[keyField] : item;
    if (key && seen.has(key)) continue;
    merged.push(item);
    if (key) seen.add(key);
  }

  return merged;
}

async function ensureRequiredCameraChannels(pool, seed) {
  const [rows] = await pool.execute('SELECT id FROM rw_camera WHERE id = ? LIMIT 1', ['CH06']);
  if (rows.length > 0) return;

  const camera = seed.cameras.find((item) => item.id === 'CH06');
  if (!camera) return;

  await upsertCamera(pool, camera);
  await insertAuditLog(pool, createAuditLog('系统', '补齐设备通道', camera.id, '成功'));
}

async function readPayloads(pool, table, orderBy, limit = 500) {
  const [rows] = await pool.query(`SELECT payload FROM ${table} ORDER BY ${orderBy} LIMIT ?`, [limit]);
  return rows.map((row) => parsePayload(row.payload));
}

async function readWorkOrders(pool, orderBy, limit = 500) {
  const [rows] = await pool.query(`SELECT payload, created_at, updated_at FROM rw_work_order ORDER BY ${orderBy} LIMIT ?`, [limit]);
  return rows.map((row) => {
    const payload = parsePayload(row.payload);
    const createdAt = payload.createdAt || fromMysqlDate(row.created_at);
    return {
      ...payload,
      createdAt,
      updatedAt: payload.updatedAt || fromMysqlDate(row.updated_at) || createdAt,
    };
  });
}

async function readStoragePolicies(pool) {
  const records = await readPayloads(pool, 'rw_storage_policy', 'updated_at DESC, created_at DESC, id DESC');
  return dedupeStoragePolicies(records);
}

function dedupeStoragePolicies(records = []) {
  const seen = new Set();
  return records.filter((record) => {
    const key = storagePolicyIdentity(record) || record.id;
    if (!key) return true;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function messageStorageQuotaBytes() {
  const configured = Number(process.env.MESSAGE_STORAGE_QUOTA_BYTES || process.env.RIVER_WATCH_MESSAGE_STORAGE_QUOTA_BYTES);
  return Number.isFinite(configured) && configured > 0 ? Math.floor(configured) : messageStorageDefaultQuotaBytes;
}

function messageStoragePolicyFields(quotaBytes = messageStorageQuotaBytes()) {
  return {
    recordingOwner: 'NVR/DVR',
    recordingPathPolicy: 'Raw recording is stored by the NVR/DVR path configuration; River-Watch stores abnormal judgments, AI metadata, alarms, notifications, work orders, evidence indexes and playback clip references only.',
    storageScope: 'abnormal-message-metadata-only',
    retentionMode: 'fifo',
    quotaBytes,
    quotaLabel: quotaBytes === messageStorageDefaultQuotaBytes ? '1TB' : formatBytes(quotaBytes),
    managedTables: [...messageStorageManagedTables],
    rawVideoStoredHere: false,
  };
}

function messageStorageStatusFromState(state, runtime = {}) {
  const tableUsage = messageStorageManagedCollections.map((config) => {
    const records = Array.isArray(state[config.key]) ? state[config.key] : [];
    const usedBytes = records.reduce((total, record) => total + messageRecordByteSize(record), 0);
    return {
      table: config.table,
      records: records.length,
      usedBytes,
      oldestRecordAt: oldestRecordAt(records, config),
    };
  });
  return buildMessageStorageStatus(tableUsage, runtime);
}

function enforceMessageStorageQuotaForState(state) {
  const quotaBytes = messageStorageQuotaBytes();
  let status = messageStorageStatusFromState(state);
  let deleted = 0;

  while (status.usedBytes > quotaBytes) {
    const victim = findOldestStateMessageRecord(state);
    if (!victim) break;
    victim.records.splice(victim.index, 1);
    deleted += 1;
    status = messageStorageStatusFromState(state);
  }

  return { lastEnforcedAt: nowIso(), lastDeletedRecords: deleted };
}

async function messageStorageStatusFromPool(pool, runtime = {}) {
  const tableUsage = [];

  for (const config of messageStorageManagedCollections) {
    const [rows] = await pool.query(
      `SELECT COUNT(*) AS records,
              COALESCE(SUM(OCTET_LENGTH(CAST(payload AS CHAR))), 0) AS usedBytes,
              MIN(${config.dateColumn}) AS oldestRecordAt
       FROM ${config.table}`,
    );
    tableUsage.push({
      table: config.table,
      records: Number(rows[0]?.records || 0),
      usedBytes: Number(rows[0]?.usedBytes || 0),
      oldestRecordAt: fromMysqlDate(rows[0]?.oldestRecordAt),
    });
  }

  return buildMessageStorageStatus(tableUsage, runtime);
}

async function enforceMessageStorageQuotaForPool(pool) {
  const quotaBytes = messageStorageQuotaBytes();
  let status = await messageStorageStatusFromPool(pool);
  let deleted = 0;

  while (status.usedBytes > quotaBytes) {
    const deletedOne = await deleteOldestPoolMessageRecord(pool);
    if (!deletedOne) break;
    deleted += 1;
    status = await messageStorageStatusFromPool(pool);
  }

  return { lastEnforcedAt: nowIso(), lastDeletedRecords: deleted };
}

function buildMessageStorageStatus(tableUsage, runtime = {}) {
  const quotaBytes = messageStorageQuotaBytes();
  const usedBytes = tableUsage.reduce((total, item) => total + Number(item.usedBytes || 0), 0);
  const recordCount = tableUsage.reduce((total, item) => total + Number(item.records || 0), 0);
  const oldestRecordAt = tableUsage
    .map((item) => item.oldestRecordAt)
    .filter(Boolean)
    .sort((a, b) => Date.parse(a) - Date.parse(b))[0] || null;

  return {
    ...messageStoragePolicyFields(quotaBytes),
    usedBytes,
    usagePercent: quotaBytes > 0 ? Number(((usedBytes / quotaBytes) * 100).toFixed(4)) : 0,
    recordCount,
    oldestRecordAt,
    lastEnforcedAt: runtime.lastEnforcedAt || null,
    lastDeletedRecords: Number(runtime.lastDeletedRecords || 0),
    tableUsage,
  };
}

function findOldestStateMessageRecord(state) {
  let victim = null;

  for (const config of messageStorageManagedCollections) {
    const records = Array.isArray(state[config.key]) ? state[config.key] : [];
    records.forEach((record, index) => {
      const createdAt = messageRecordTimestamp(record, config);
      if (!victim || createdAt < victim.createdAt) {
        victim = { records, index, createdAt };
      }
    });
  }

  return victim;
}

async function deleteOldestPoolMessageRecord(pool) {
  const candidates = [];

  for (const config of messageStorageManagedCollections) {
    const [rows] = await pool.query(`SELECT id, ${config.dateColumn} AS createdAt FROM ${config.table} ORDER BY ${config.dateColumn} ASC, id ASC LIMIT 1`);
    if (rows[0]?.id) {
      candidates.push({ table: config.table, id: rows[0].id, createdAt: rows[0].createdAt });
    }
  }

  const victim = candidates
    .sort((a, b) => normalizeTimestamp(a.createdAt) - normalizeTimestamp(b.createdAt))[0];

  if (!victim) return false;
  await pool.execute(`DELETE FROM ${victim.table} WHERE id = ?`, [victim.id]);
  return true;
}

function oldestRecordAt(records, config) {
  const oldest = records
    .map((record) => messageRecordTimestamp(record, config))
    .filter((timestamp) => Number.isFinite(timestamp) && timestamp > 0)
    .sort((a, b) => a - b)[0];
  return oldest ? new Date(oldest).toISOString() : null;
}

function messageRecordTimestamp(record, config) {
  return normalizeTimestamp(record?.[config.dateField] || record?.createdAt || record?.receivedAt || record?.updatedAt || record?.time || record?.sealedAt);
}

function normalizeTimestamp(value) {
  if (value instanceof Date) return value.getTime();
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  const parsed = Date.parse(String(value || ''));
  return Number.isFinite(parsed) ? parsed : 0;
}

function messageRecordByteSize(record) {
  return Buffer.byteLength(JSON.stringify(record || {}), 'utf8');
}

function formatBytes(bytes) {
  if (bytes >= 1024 ** 4) return `${Number((bytes / 1024 ** 4).toFixed(2))}TB`;
  if (bytes >= 1024 ** 3) return `${Number((bytes / 1024 ** 3).toFixed(2))}GB`;
  if (bytes >= 1024 ** 2) return `${Number((bytes / 1024 ** 2).toFixed(2))}MB`;
  return `${bytes}B`;
}

function upsertReviewQueueAlarm(records, alarm) {
  const duplicateIndex = records.findIndex((item) => isReviewQueueDuplicate(item, alarm));
  if (duplicateIndex >= 0) {
    const merged = mergeReviewQueueAlarm(records[duplicateIndex], alarm);
    records.splice(duplicateIndex, 1, merged);
    return { alarm: merged, merged: true };
  }

  const index = records.findIndex((item) => item.id === alarm.id);
  if (index >= 0) records.splice(index, 1, alarm);
  else records.unshift(alarm);
  return { alarm, merged: false };
}

function isReviewQueueDuplicate(existing, incoming, windowSeconds = Number(process.env.ALARM_DEDUPE_WINDOW_SECONDS || 180)) {
  if (!existing || !incoming) return false;
  if (existing.id === incoming.id) return true;
  const activeStatuses = new Set(['待研判', '已确认', '已派单']);
  if (!activeStatuses.has(existing.status) || !activeStatuses.has(incoming.status)) return false;
  if (existing.cameraId !== incoming.cameraId || existing.type !== incoming.type) return false;
  const existingTs = normalizeTimestamp(existing.updatedAt || existing.createdAt || existing.receivedAt);
  const incomingTs = normalizeTimestamp(incoming.updatedAt || incoming.createdAt || incoming.receivedAt);
  if (existingTs > 0 && incomingTs > 0) return Math.abs(existingTs - incomingTs) <= windowSeconds * 1000;
  if (existingTs > 0) return Date.now() - existingTs <= windowSeconds * 1000;
  return Math.abs(timeTextToSeconds(existing.time) - timeTextToSeconds(incoming.time)) <= windowSeconds;
}

function mergeReviewQueueAlarm(existing, incoming) {
  const updatedAt = nowIso();
  return {
    ...existing,
    cameraName: incoming.cameraName || existing.cameraName,
    severity: highestAlarmSeverity(existing.severity, incoming.severity),
    confidence: Math.max(Number(existing.confidence || 0), Number(incoming.confidence || 0)),
    dedupeCount: Number(existing.dedupeCount || 1) + Number(incoming.dedupeCount || 1),
    time: incoming.time || existing.time,
    pts: incoming.pts || existing.pts,
    snapshot: incoming.snapshot || existing.snapshot,
    dispatchId: incoming.dispatchId || existing.dispatchId,
    dispatchedAt: incoming.dispatchedAt || existing.dispatchedAt,
    lastDetectedAt: incoming.updatedAt || incoming.createdAt || updatedAt,
    updatedAt,
  };
}

function highestAlarmSeverity(a, b) {
  const rank = { 提示: 1, 一般: 2, 严重: 3, 紧急: 4 };
  return (rank[a] || 0) >= (rank[b] || 0) ? a : b;
}

function timeTextToSeconds(value = '') {
  const [hour = '0', minute = '0', second = '0'] = String(value).split(':');
  return Number(hour) * 3600 + Number(minute) * 60 + Number.parseFloat(second);
}

async function readAiEvents(pool, limit = 100) {
  const [rows] = await pool.query('SELECT id, alarm_id, camera_id, payload, received_at FROM rw_ai_event ORDER BY received_at DESC LIMIT ?', [limit]);
  return rows.map((row) => ({
    id: row.id,
    alarmId: row.alarm_id,
    cameraId: row.camera_id,
    receivedAt: row.received_at,
    ...parsePayload(row.payload),
  }));
}

async function readRuntimeConfig(pool) {
  const [rows] = await pool.query('SELECT config_key, config_group, payload, updated_at FROM rw_runtime_config ORDER BY config_group, config_key');
  return rows.map((row) => ({
    key: row.config_key,
    group: row.config_group,
    value: parsePayload(row.payload),
    updatedAt: row.updated_at,
  }));
}

async function getAiEvent(pool, id) {
  const [rows] = await pool.execute('SELECT id, alarm_id, camera_id, payload, received_at FROM rw_ai_event WHERE id = ? LIMIT 1', [id]);
  if (!rows[0]) return null;
  return {
    id: rows[0].id,
    alarmId: rows[0].alarm_id,
    cameraId: rows[0].camera_id,
    receivedAt: rows[0].received_at,
    ...parsePayload(rows[0].payload),
  };
}

async function readCameraStatuses(pool) {
  const [rows] = await pool.query('SELECT camera_id, status, source, bitrate, latency, detail, payload, heartbeat_at FROM rw_camera_status ORDER BY heartbeat_at DESC');
  return rows.map((row) => ({
    cameraId: row.camera_id,
    status: row.status,
    source: row.source,
    bitrate: row.bitrate,
    latency: row.latency,
    detail: row.detail,
    heartbeatAt: row.heartbeat_at,
    ...parsePayload(row.payload),
  }));
}

async function readCameraStatusById(pool, cameraId) {
  const [rows] = await pool.execute('SELECT camera_id, status, source, bitrate, latency, detail, payload, heartbeat_at FROM rw_camera_status WHERE camera_id = ? LIMIT 1', [cameraId]);
  const row = rows[0];
  if (!row) return null;
  return {
    cameraId: row.camera_id,
    status: row.status,
    source: row.source,
    bitrate: row.bitrate,
    latency: row.latency,
    detail: row.detail,
    heartbeatAt: row.heartbeat_at,
    ...parsePayload(row.payload),
  };
}

async function readAiWorkerStatuses(pool) {
  const [rows] = await pool.query('SELECT worker_id, status, source, fps, latency_ms, detail, payload, heartbeat_at FROM rw_ai_worker_status ORDER BY heartbeat_at DESC');
  return rows.map((row) => ({
    workerId: row.worker_id,
    status: row.status,
    source: row.source,
    fps: row.fps === null ? undefined : Number(row.fps),
    latencyMs: row.latency_ms,
    detail: row.detail,
    heartbeatAt: row.heartbeat_at,
    ...parsePayload(row.payload),
  }));
}

async function upsertCamera(pool, camera) {
  await pool.execute(
    `INSERT INTO rw_camera (id, name, status, protocol, group_tag, node, payload)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE name=VALUES(name), status=VALUES(status), protocol=VALUES(protocol), group_tag=VALUES(group_tag), node=VALUES(node), payload=VALUES(payload)`,
    [camera.id, camera.name, camera.status, camera.protocol, camera.group, camera.node, stringifyPayload(camera)],
  );
}

async function upsertCameraStatus(pool, record) {
  await pool.execute(
    `INSERT INTO rw_camera_status (camera_id, status, source, bitrate, latency, detail, payload, heartbeat_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE status=VALUES(status), source=VALUES(source), bitrate=VALUES(bitrate), latency=VALUES(latency), detail=VALUES(detail), payload=VALUES(payload), heartbeat_at=VALUES(heartbeat_at)`,
    [
      record.cameraId,
      record.status,
      record.source || null,
      record.bitrate || null,
      record.latency === undefined || record.latency === null ? null : Number(record.latency),
      record.detail || null,
      stringifyPayload(record),
      toMysqlDate(record.heartbeatAt || nowIso()),
    ],
  );
}

async function upsertAiWorkerStatus(pool, record) {
  await pool.execute(
    `INSERT INTO rw_ai_worker_status (worker_id, status, source, fps, latency_ms, detail, payload, heartbeat_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE status=VALUES(status), source=VALUES(source), fps=VALUES(fps), latency_ms=VALUES(latency_ms), detail=VALUES(detail), payload=VALUES(payload), heartbeat_at=VALUES(heartbeat_at)`,
    [
      record.workerId,
      record.status,
      record.source || null,
      record.fps === undefined || record.fps === null ? null : Number(record.fps),
      record.latencyMs === undefined || record.latencyMs === null ? null : Number(record.latencyMs),
      record.detail || null,
      stringifyPayload(record),
      toMysqlDate(record.heartbeatAt || nowIso()),
    ],
  );
}

async function upsertAlarm(pool, alarm) {
  await pool.execute(
    `INSERT INTO rw_alarm (id, camera_id, type, severity, status, confidence, payload)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE camera_id=VALUES(camera_id), type=VALUES(type), severity=VALUES(severity), status=VALUES(status), confidence=VALUES(confidence), payload=VALUES(payload)`,
    [alarm.id, alarm.cameraId, alarm.type, alarm.severity, alarm.status, Number(alarm.confidence || 0), stringifyPayload(alarm)],
  );
}

async function readEventGroups(executor, filters = {}) {
  const includeHistory = String(filters.history || '').toLowerCase() === 'true';
  const [rows] = await executor.query(
    `SELECT payload FROM rw_event_group
     ${includeHistory ? '' : "WHERE status = '待研判'"}
     ORDER BY latest_occurred_at DESC, id DESC`,
  );
  return rows
    .map((row) => parsePayload(row.payload))
    .filter((event) => !filters.status || event.status === filters.status)
    .filter((event) => !filters.cameraId || event.cameraId === filters.cameraId)
    .filter((event) => !filters.type || event.type === filters.type);
}

async function readEventGroupById(executor, id, lock = false) {
  const [rows] = await executor.execute(
    `SELECT payload FROM rw_event_group WHERE id = ? LIMIT 1${lock ? ' FOR UPDATE' : ''}`,
    [id],
  );
  return rows[0] ? parsePayload(rows[0].payload) : null;
}

async function upsertEventGroup(executor, event) {
  const openDedupeKey = event.status === '待研判' ? event.dedupeKey : null;
  await executor.execute(
    `INSERT INTO rw_event_group
       (id, dedupe_key, open_dedupe_key, camera_id, type, severity, status,
        first_alarm_id, latest_alarm_id, first_occurred_at, latest_occurred_at,
        occurrence_count, payload)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       dedupe_key=VALUES(dedupe_key), open_dedupe_key=VALUES(open_dedupe_key),
       camera_id=VALUES(camera_id), type=VALUES(type), severity=VALUES(severity),
       status=VALUES(status), first_alarm_id=VALUES(first_alarm_id),
       latest_alarm_id=VALUES(latest_alarm_id), first_occurred_at=VALUES(first_occurred_at),
       latest_occurred_at=VALUES(latest_occurred_at), occurrence_count=VALUES(occurrence_count),
       payload=VALUES(payload)`,
    [
      event.id,
      event.dedupeKey,
      openDedupeKey,
      event.cameraId,
      event.type,
      event.severity,
      event.status,
      event.firstAlarmId,
      event.latestAlarmId,
      toMysqlDate(event.firstOccurredAt),
      toMysqlDate(event.latestOccurredAt),
      Math.max(1, Number(event.occurrenceCount || 1)),
      stringifyPayload(event),
    ],
  );
}

async function insertEventGroup(executor, event) {
  await executor.execute(
    `INSERT INTO rw_event_group
       (id, dedupe_key, open_dedupe_key, camera_id, type, severity, status,
        first_alarm_id, latest_alarm_id, first_occurred_at, latest_occurred_at,
        occurrence_count, payload)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      event.id,
      event.dedupeKey,
      event.dedupeKey,
      event.cameraId,
      event.type,
      event.severity,
      event.status,
      event.firstAlarmId,
      event.latestAlarmId,
      toMysqlDate(event.firstOccurredAt),
      toMysqlDate(event.latestOccurredAt),
      Math.max(1, Number(event.occurrenceCount || 1)),
      stringifyPayload(event),
    ],
  );
}

async function aggregateAlarmForPool(executor, alarm, options = {}) {
  const [relationRows] = await executor.execute(
    'SELECT event_id FROM rw_event_group_alarm WHERE alarm_id = ? LIMIT 1',
    [alarm.id],
  );
  if (relationRows[0]) return readEventGroupById(executor, relationRows[0].event_id);

  const dedupeKey = normalizeEventDedupeKey(alarm);
  const occurredAt = eventTimestampFallback(alarm, options.databaseTimestamp);
  const [openRows] = await executor.execute(
    'SELECT payload FROM rw_event_group WHERE open_dedupe_key = ? LIMIT 1 FOR UPDATE',
    [dedupeKey],
  );
  let event = openRows[0] ? parsePayload(openRows[0].payload) : null;

  if (!event) {
    const created = createAggregateEvent(alarm, { id: `EVT-${randomUUID()}`, occurredAt });
    created.occurrenceCount = Math.max(1, Number(alarm.dedupeCount || 1));
    try {
      await insertEventGroup(executor, created);
      await executor.execute(
        'INSERT INTO rw_event_group_alarm (alarm_id, event_id, occurred_at) VALUES (?, ?, ?)',
        [alarm.id, created.id, toMysqlDate(occurredAt)],
      );
      return created;
    } catch (error) {
      if (error?.code !== 'ER_DUP_ENTRY') throw error;
      const [winnerRows] = await executor.execute(
        'SELECT payload FROM rw_event_group WHERE open_dedupe_key = ? LIMIT 1 FOR UPDATE',
        [dedupeKey],
      );
      event = winnerRows[0] ? parsePayload(winnerRows[0].payload) : null;
      if (!event) throw error;
    }
  }

  const [insertResult] = await executor.execute(
    'INSERT IGNORE INTO rw_event_group_alarm (alarm_id, event_id, occurred_at) VALUES (?, ?, ?)',
    [alarm.id, event.id, toMysqlDate(occurredAt)],
  );
  if (!insertResult.affectedRows) return event;

  const merged = mergeAggregateEvent(event, alarm, {
    occurredAt,
    occurrenceIncrement: Math.max(1, Number(alarm.dedupeCount || 1)),
  });
  await upsertEventGroup(executor, merged);
  return merged;
}

async function closeEventGroupForAlarmPool(executor, alarmId, action, workOrderId = '') {
  const [relationRows] = await executor.execute(
    'SELECT event_id FROM rw_event_group_alarm WHERE alarm_id = ? LIMIT 1',
    [alarmId],
  );
  if (!relationRows[0]) return null;
  const event = await readEventGroupById(executor, relationRows[0].event_id, true);
  if (!event || event.status !== '待研判') return event;
  const closed = closeAggregateEvent(event, action, { closedAt: nowIso(), workOrderId });
  await upsertEventGroup(executor, closed);
  return closed;
}

async function backfillEventGroups(pool) {
  const [rows] = await pool.query(
    `SELECT id, payload, created_at FROM rw_alarm
     WHERE status IN ('待研判', '已确认', '已派单')
     ORDER BY created_at ASC, id ASC`,
  );
  if (!rows.length) return;

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    for (const row of rows) {
      const alarm = parsePayload(row.payload);
      await aggregateAlarmForPool(connection, alarm, { databaseTimestamp: row.created_at });
    }
    await connection.commit();
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

function normalizeEventDeviceNames(events, cameras) {
  const names = new Map(cameras.map((camera) => [camera.id, camera.name]));
  return events.map((event) => ({
    ...event,
    cameraName: names.get(event.cameraId) || event.cameraName || event.cameraId,
  }));
}

async function upsertAlarmEvidence(pool, record) {
  const annotationData = stringifyPayload({
    coordinateSpace: record.coordinateSpace || 'normalized',
    boxes: Array.isArray(record.annotations) ? record.annotations : [],
  });
  await pool.execute(
    `INSERT INTO rw_alarm_evidence (alarm_id, event_id, camera_id, mime_type, byte_size, media_data, annotation_data, captured_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE event_id=VALUES(event_id), camera_id=VALUES(camera_id), mime_type=VALUES(mime_type), byte_size=VALUES(byte_size), media_data=VALUES(media_data), annotation_data=VALUES(annotation_data), captured_at=VALUES(captured_at)`,
    [
      record.alarmId,
      record.eventId || null,
      record.cameraId || null,
      record.mimeType || 'image/jpeg',
      record.data.length,
      record.data,
      annotationData,
      toMysqlDate(record.capturedAt || nowIso()),
    ],
  );
}

async function getAlarmEvidence(pool, alarmId) {
  const [rows] = await pool.execute(
    'SELECT alarm_id, event_id, camera_id, mime_type, byte_size, media_data, annotation_data, captured_at FROM rw_alarm_evidence WHERE alarm_id = ? LIMIT 1',
    [alarmId],
  );
  const row = rows[0];
  if (!row) return null;
  const annotationData = parsePayload(row.annotation_data) || {};
  return {
    alarmId: row.alarm_id,
    eventId: row.event_id || '',
    cameraId: row.camera_id || '',
    mimeType: row.mime_type,
    byteSize: Number(row.byte_size || 0),
    data: Buffer.from(row.media_data),
    capturedAt: row.captured_at instanceof Date ? row.captured_at.toISOString() : String(row.captured_at || ''),
    coordinateSpace: annotationData.coordinateSpace || 'normalized',
    annotations: Array.isArray(annotationData.boxes) ? annotationData.boxes : [],
  };
}

async function upsertWorkOrder(pool, order) {
  await pool.execute(
    `INSERT INTO rw_work_order (id, alarm_id, status, priority, assignee, payload)
     VALUES (?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE alarm_id=VALUES(alarm_id), status=VALUES(status), priority=VALUES(priority), assignee=VALUES(assignee), payload=VALUES(payload)`,
    [order.id, order.alarmId || null, order.status, order.priority, order.assignee, stringifyPayload(order)],
  );
}

async function upsertUser(pool, user) {
  await pool.execute(
    `INSERT INTO rw_user (id, name, role_name, org_name, status, payload)
     VALUES (?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE name=VALUES(name), role_name=VALUES(role_name), org_name=VALUES(org_name), status=VALUES(status), payload=VALUES(payload)`,
    [user.id, user.name, user.role, user.org, user.status, stringifyPayload(user)],
  );
}

async function upsertTemplate(pool, template) {
  await pool.execute(
    `INSERT INTO rw_template (id, template_name, scene_name, version_text, payload)
     VALUES (?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE template_name=VALUES(template_name), scene_name=VALUES(scene_name), version_text=VALUES(version_text), payload=VALUES(payload)`,
    [template.id, template.name, template.scene || null, template.version || null, stringifyPayload(template)],
  );
}

async function upsertAlgorithm(pool, algorithm) {
  await pool.execute(
    `INSERT INTO rw_algorithm (id, model_name, family_name, node_name, format_name, payload)
     VALUES (?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE model_name=VALUES(model_name), family_name=VALUES(family_name), node_name=VALUES(node_name), format_name=VALUES(format_name), payload=VALUES(payload)`,
    [algorithm.id, algorithm.name, algorithm.family || null, algorithm.node || null, algorithm.format || null, stringifyPayload(algorithm)],
  );
}

async function upsertUavTask(pool, task) {
  await pool.execute(
    `INSERT INTO rw_uav_task (id, task_name, status, dock_name, related_alarm_id, payload)
     VALUES (?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE task_name=VALUES(task_name), status=VALUES(status), dock_name=VALUES(dock_name), related_alarm_id=VALUES(related_alarm_id), payload=VALUES(payload)`,
    [task.id, task.name, task.status, task.dock || null, task.relatedAlarm || task.relatedAlarmId || null, stringifyPayload(task)],
  );
}

async function upsertUavAsset(pool, asset) {
  await pool.execute(
    `INSERT INTO rw_uav_asset (id, asset_name, vendor_name, model_name, dock_name, status, payload)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE asset_name=VALUES(asset_name), vendor_name=VALUES(vendor_name), model_name=VALUES(model_name), dock_name=VALUES(dock_name), status=VALUES(status), payload=VALUES(payload)`,
    [asset.id, asset.name, asset.vendor || null, asset.model || null, asset.dockName || null, asset.status || null, stringifyPayload(asset)],
  );
}

async function insertAiEvent(pool, event) {
  await pool.execute(
    'INSERT INTO rw_ai_event (id, alarm_id, camera_id, payload) VALUES (?, ?, ?, ?)',
    [event.id, event.alarmId, event.cameraId, stringifyPayload(event.payload)],
  );
}

async function upsertExportTask(pool, task) {
  await pool.execute(
    `INSERT INTO rw_export_task (id, module_name, status, payload)
     VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE module_name=VALUES(module_name), status=VALUES(status), payload=VALUES(payload)`,
    [task.id, task.module || task.moduleName || 'unknown', task.status, stringifyPayload(task)],
  );
}

async function upsertOperationTask(pool, task) {
  await pool.execute(
    `INSERT INTO rw_operation_task (id, module_name, action_name, status, payload)
     VALUES (?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE module_name=VALUES(module_name), action_name=VALUES(action_name), status=VALUES(status), payload=VALUES(payload)`,
    [task.id, task.moduleName, task.actionName, task.status, stringifyPayload(task)],
  );
}

async function upsertPlaybackClip(pool, clip) {
  await pool.execute(
    `INSERT INTO rw_playback_clip (id, camera_id, alarm_id, evidence_bundle_id, status, payload)
     VALUES (?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE camera_id=VALUES(camera_id), alarm_id=VALUES(alarm_id), evidence_bundle_id=VALUES(evidence_bundle_id), status=VALUES(status), payload=VALUES(payload)`,
    [clip.id, clip.cameraId || null, clip.alarmId || null, clip.evidenceBundleId || null, clip.status, stringifyPayload(clip)],
  );
}

async function upsertNotification(pool, notification) {
  await pool.execute(
    `INSERT INTO rw_notification (id, alarm_id, severity, channel, status, payload)
     VALUES (?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE alarm_id=VALUES(alarm_id), severity=VALUES(severity), channel=VALUES(channel), status=VALUES(status), payload=VALUES(payload)`,
    [notification.id, notification.alarmId || null, notification.severity, notification.channel, notification.status, stringifyPayload(notification)],
  );
}

async function upsertNotifyRule(pool, rule) {
  await pool.execute(
    `INSERT INTO rw_notify_rule (id, severity, enabled, payload)
     VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE severity=VALUES(severity), enabled=VALUES(enabled), payload=VALUES(payload)`,
    [rule.id, rule.severity, rule.enabled ? 1 : 0, stringifyPayload(rule)],
  );
}

async function upsertEvidenceBundle(pool, bundle) {
  await pool.execute(
    `INSERT INTO rw_evidence_bundle (id, alarm_id, status, hash_value, sealed_at, payload)
     VALUES (?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE alarm_id=VALUES(alarm_id), status=VALUES(status), hash_value=VALUES(hash_value), sealed_at=VALUES(sealed_at), payload=VALUES(payload)`,
    [
      bundle.id,
      bundle.alarmId || null,
      bundle.status,
      bundle.hash || bundle.manifestHash || null,
      toMysqlDate(bundle.sealedAt),
      stringifyPayload(bundle),
    ],
  );
}

async function upsertImportJob(pool, job) {
  await pool.execute(
    `INSERT INTO rw_import_job (id, source_name, media_type, status, confidence, related_alarm_id, payload)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE source_name=VALUES(source_name), media_type=VALUES(media_type), status=VALUES(status), confidence=VALUES(confidence), related_alarm_id=VALUES(related_alarm_id), payload=VALUES(payload)`,
    [
      job.id,
      job.source || job.fileName || null,
      job.type || null,
      job.status,
      Number(job.confidence || 0),
      job.relatedAlarmId || null,
      stringifyPayload(job),
    ],
  );
}

async function upsertStoragePolicy(pool, policy) {
  const saved = { ...policy, id: (await findExistingStoragePolicyId(pool, policy)) || policy.id };
  await pool.execute(
    `INSERT INTO rw_storage_policy (id, policy_name, tier_name, usage_percent, protected_evidence, payload)
     VALUES (?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE policy_name=VALUES(policy_name), tier_name=VALUES(tier_name), usage_percent=VALUES(usage_percent), protected_evidence=VALUES(protected_evidence), payload=VALUES(payload)`,
    [
      saved.id,
      saved.name,
      saved.tier || saved.name,
      Number(saved.usage || 0),
      saved.protectedEvidence ? 1 : 0,
      stringifyPayload(saved),
    ],
  );
  return saved;
}

async function findExistingStoragePolicyId(pool, policy) {
  const key = storagePolicyIdentity(policy);
  if (!key) return '';
  const [rows] = await pool.query('SELECT id, payload FROM rw_storage_policy ORDER BY updated_at DESC, created_at DESC, id DESC');
  const match = rows.find((row) => storagePolicyIdentity(parsePayload(row.payload)) === key);
  return match?.id || '';
}

function storagePolicyIdentity(policy = {}) {
  const tier = normalizeIdentityPart(policy.tier || String(policy.name || '').split('/')[0]);
  if (tier) return `tier:${tier}`;
  const name = normalizeIdentityPart(policy.name);
  return name ? `name:${name}` : '';
}

function normalizeIdentityPart(value) {
  return String(value || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

async function upsertReportMetric(pool, metric) {
  await pool.execute(
    `INSERT INTO rw_report_metric (id, metric_name, metric_value, payload)
     VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE metric_name=VALUES(metric_name), metric_value=VALUES(metric_value), payload=VALUES(payload)`,
    [metric.id, metric.name, metric.value, stringifyPayload(metric)],
  );
}

async function upsertReportTask(pool, task) {
  await pool.execute(
    `INSERT INTO rw_report_task (id, report_name, report_type, status, payload)
     VALUES (?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE report_name=VALUES(report_name), report_type=VALUES(report_type), status=VALUES(status), payload=VALUES(payload)`,
    [task.id, task.name, task.type, task.status, stringifyPayload(task)],
  );
}

async function upsertRolePermission(pool, permission) {
  await pool.execute(
    `INSERT INTO rw_role_permission (role_id, role_name, data_scope, payload)
     VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE role_name=VALUES(role_name), data_scope=VALUES(data_scope), payload=VALUES(payload)`,
    [permission.roleId, permission.roleName, permission.dataScope, stringifyPayload(permission)],
  );
}

async function upsertLogSearchJob(pool, job) {
  await pool.execute(
    `INSERT INTO rw_log_search_job (id, query_text, result_count, status, payload)
     VALUES (?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE query_text=VALUES(query_text), result_count=VALUES(result_count), status=VALUES(status), payload=VALUES(payload)`,
    [job.id, job.query || '', Number(job.resultCount || 0), job.status, stringifyPayload(job)],
  );
}

async function upsertOpsRun(pool, run) {
  await pool.execute(
    `INSERT INTO rw_ops_run (id, run_type, status, manifest_hash, payload)
     VALUES (?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE run_type=VALUES(run_type), status=VALUES(status), manifest_hash=VALUES(manifest_hash), payload=VALUES(payload)`,
    [run.id, run.type, run.status, run.manifestHash || null, stringifyPayload(run)],
  );
}

async function upsertRuntimeConfig(pool, config) {
  await pool.execute(
    `INSERT INTO rw_runtime_config (config_key, config_group, payload)
     VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE config_group=VALUES(config_group), payload=VALUES(payload)`,
    [config.key, config.group || 'runtime', stringifyPayload(config.value)],
  );
}

async function insertAuditLog(pool, log) {
  await pool.execute(
    'INSERT INTO rw_audit_log (id, time_text, operator_name, action, target, result, payload) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [log.id, log.time, log.operator, log.action, log.object, log.result, stringifyPayload(log)],
  );
}

function createAuditLog(operator, action, object, result) {
  return {
    id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    time: beijingTimeText(),
    operator,
    action,
    object,
    result,
  };
}

function filterRecords(items, filters, fields) {
  return clone(
    items.filter((item) =>
      fields.every((field) => {
        const expected = filters[field];
        if (!expected || expected === '全部') return true;
        return String(item[field] ?? '') === expected;
      }),
    ),
  );
}

function sortCameras(cameras) {
  return clone(cameras).sort((a, b) => channelNumber(a.id) - channelNumber(b.id) || String(a.id).localeCompare(String(b.id)));
}

function channelNumber(id) {
  const match = String(id || '').match(/^CH(\d+)$/i);
  return match ? Number(match[1]) : Number.MAX_SAFE_INTEGER;
}

function filterLogs(items, filters = {}) {
  const query = String(filters.query || '').toLowerCase();
  const result = filters.result;
  const operator = filters.operator;
  const action = filters.action;
  const limit = Number(filters.limit || 100);
  return clone(
    items
      .filter((item) => {
        if (result && String(item.result) !== String(result)) return false;
        if (operator && !String(item.operator || '').includes(String(operator))) return false;
        if (action && !String(item.action || '').includes(String(action))) return false;
        if (!query) return true;
        return ['id', 'time', 'operator', 'action', 'object', 'result'].some((field) => String(item[field] || '').toLowerCase().includes(query));
      })
      .slice(0, limit),
  );
}

function normalizeSeedStoragePolicy(policy) {
  const tier = policy.tier || policy.name.split('/')[0].trim();
  return {
    ...policy,
    id: policy.id || `STO-${tier.replace(/\s+/g, '-').toUpperCase()}`,
    tier,
    name: policy.name,
    usage: policy.usage,
    quota: policy.quota,
    policy: policy.policy,
    protectedEvidence: Boolean(policy.protectedEvidence),
    retentionDays: policy.retentionDays ?? (policy.protectedEvidence ? 3650 : 0),
    alertThreshold: policy.alertThreshold ?? 75,
    updatedAt: nowIso(),
  };
}

function applyAlarmReviewStatus(alarm, status) {
  const normalized = String(status || '').trim();
  if (normalized === '忽略' || normalized === '已处理' || normalized === '误报') {
    alarm.status = '已归档';
    alarm.reviewResult = normalized === '误报' ? '忽略' : normalized;
    alarm.archiveReason = normalized === '已处理' ? '视频复核已处理' : '人工忽略';
    alarm.archivedAt = nowIso();
    alarm.updatedAt = alarm.archivedAt;
    return alarm;
  }

  alarm.status = normalized === '已派单' || normalized === '已确认' ? '已派单' : normalized || '已派单';
  alarm.reviewResult = normalized || '已确认';
  alarm.dispatchId ||= `DP-${String(Date.now()).slice(-10)}`;
  alarm.dispatchedAt ||= nowIso();
  alarm.updatedAt = nowIso();
  return alarm;
}

function createClosedWorkOrderFromAlarm(alarm, makeWorkOrder, index) {
  const action = alarm.reviewResult === '已处理' ? '已处理' : '忽略';
  const now = nowIso();
  const order = makeWorkOrder(alarm, index);
  return {
    ...order,
    status: '派单',
    elapsedHours: 0,
    slaState: '正常',
    createdAt: order.createdAt || now,
    confirmedAt: now,
    acceptedAt: now,
    updatedAt: now,
    lastAction: `${action}待归档`,
    timeline: [
      {
        time: now,
        from: '派单',
        to: '派单',
        operator: alarm.owner || '监管运营员',
        note: action === '已处理' ? '视频复核已处理，进入工单闭环待归档' : '视频复核忽略，进入工单闭环待归档',
      },
    ],
  };
}

function normalizeSeedReportMetric(metric) {
  return {
    id: metric.id || `MET-${String(metric.name || '').replace(/\s+/g, '-')}`,
    ...metric,
    updatedAt: nowIso(),
  };
}

function defaultRolePermissions() {
  return [
    { roleId: 'admin', roleName: '平台管理员', dataScope: '全域', permissions: ['用户权限', '算法管理', '存储管理', '系统日志', '证据下载'], updatedAt: nowIso() },
    { roleId: 'operator', roleName: '监管运营员', dataScope: '所属片区', permissions: ['实时视频墙', '告警研判', '工单闭环', '报表查看', '证据下载'], updatedAt: nowIso() },
    { roleId: 'auditor', roleName: '审计访客', dataScope: '只读审计', permissions: ['系统日志', '报表查看', '证据下载'], updatedAt: nowIso() },
  ];
}

function applyStrictProductionSnapshot(snapshot, cameraStatuses = [], aiWorkerStatuses = []) {
  const stripped = stripSeedBusinessData(snapshot);
  const cameras = applyCameraHeartbeats(stripped.cameras || [], cameraStatuses, stripped.aiEvents || [], aiWorkerStatuses);
  const aiWorkers = applyAiWorkerHeartbeats(stripped.aiWorkers || [], aiWorkerStatuses);
  const strictSnapshot = {
    ...stripped,
    cameras,
    aiWorkers,
    runtimeConfig: sanitizeRuntimeConfig(stripped.runtimeConfig || [], aiWorkers),
  };

  return {
    ...strictSnapshot,
    reportMetrics: buildStrictReportMetrics(strictSnapshot),
  };
}

function buildStrictReportMetrics(snapshot = {}) {
  const cameras = Array.isArray(snapshot.cameras) ? snapshot.cameras : [];
  const workOrders = Array.isArray(snapshot.workOrders) ? snapshot.workOrders : [];
  const onlineCount = cameras.filter(isOnlineCamera).length;
  const closedCount = workOrders.filter(isClosedWorkOrder).length;
  const onlineRate = percentage(onlineCount, cameras.length);
  const closureRate = percentage(closedCount, workOrders.length);
  const updatedAt = nowIso();

  return [
    {
      id: 'MET-live-online',
      name: '在线率',
      value: formatPercentage(onlineRate),
      change: `${onlineCount}/${cameras.length}`,
      trend: flatTrend(onlineRate),
      updatedAt,
    },
    {
      id: 'MET-live-closure',
      name: '闭环率',
      value: formatPercentage(closureRate),
      change: `${closedCount}/${workOrders.length}`,
      trend: flatTrend(closureRate),
      updatedAt,
    },
  ];
}

function isOnlineCamera(camera = {}) {
  const status = String(camera.status || '').trim();
  return status === '在线' || status.toLowerCase() === 'online';
}

function isClosedWorkOrder(order = {}) {
  const values = [order.status, order.slaState, order.lastAction, order.result]
    .map((value) => String(value || '').trim())
    .filter(Boolean);

  return values.some((value) => {
    const normalized = value.toLowerCase();
    return (
      value.includes('归档') ||
      value.includes('闭环') ||
      ['closed', 'completed', 'archived', 'done'].includes(normalized)
    );
  });
}

function percentage(part, total) {
  if (!total) return 0;
  return roundMetric((part / total) * 100);
}

function formatPercentage(value) {
  return `${Number.isInteger(value) ? value : value.toFixed(1)}%`;
}

function flatTrend(value) {
  return Array.from({ length: 7 }, () => roundMetric(value));
}

function roundMetric(value) {
  return Math.round(Number(value || 0) * 10) / 10;
}

function stripSeedBusinessData(snapshot = {}) {
  const seedAlarmIds = new Set(['A-20652', 'A-20651', 'A-20650', 'A-20648']);
  const seedWorkOrderIds = new Set(['WO-9127', 'WO-9126']);
  const seedAlgorithmIds = new Set(['ALG-01', 'ALG-02', 'ALG-03', 'ALG-04']);
  const seedUavTaskIds = new Set(['UAV-031']);
  const seedEvidenceIds = new Set(['EV-20652']);
  const seedImportIds = new Set(['IMP-1001']);
  const seedMetricIds = new Set(['MET-online', 'MET-closure']);
  const seedReportTaskIds = new Set(['RPT-DAILY']);
  const seedLogIds = new Set(['LOG-001']);
  const demoAlarmIds = new Set(seedAlarmIds);

  const aiEvents = (snapshot.aiEvents || []).filter((event) => {
    if (!isSeedAiEvent(event)) return true;
    if (event.alarmId) demoAlarmIds.add(event.alarmId);
    if (event.result?.alarm?.id) demoAlarmIds.add(event.result.alarm.id);
    return false;
  });

  return {
    ...snapshot,
    aiEvents,
    alarms: (snapshot.alarms || []).filter((alarm) => !demoAlarmIds.has(alarm.id)),
    workOrders: (snapshot.workOrders || []).filter((order) => !seedWorkOrderIds.has(order.id) && !demoAlarmIds.has(order.alarmId)),
    algorithms: (snapshot.algorithms || []).filter((algorithm) => !seedAlgorithmIds.has(algorithm.id)),
    uavTasks: (snapshot.uavTasks || []).filter((task) => !seedUavTaskIds.has(task.id) && !demoAlarmIds.has(task.relatedAlarm || task.relatedAlarmId)),
    evidenceBundles: (snapshot.evidenceBundles || []).filter((bundle) => !seedEvidenceIds.has(bundle.id) && !demoAlarmIds.has(bundle.alarmId)),
    importJobs: (snapshot.importJobs || []).filter((job) => !seedImportIds.has(job.id) && !demoAlarmIds.has(job.relatedAlarmId || job.alarmId)),
    reportMetrics: (snapshot.reportMetrics || []).filter((metric) => !seedMetricIds.has(metric.id)),
    reportTasks: (snapshot.reportTasks || []).filter((task) => !seedReportTaskIds.has(task.id)),
    logs: (snapshot.logs || []).filter((log) => !seedLogIds.has(log.id) && !demoAlarmIds.has(log.object)),
    notifications: (snapshot.notifications || []).filter((item) => !demoAlarmIds.has(item.alarmId)),
  };
}

function isSeedAiEvent(event = {}) {
  const id = String(event.id || '');
  const request = event.request || event.payload || {};
  return id.startsWith('SMOKE-AI-') || request.source === 'smoke-field-delivery';
}

function stripNavBadges(items = []) {
  const retiredNavKeys = new Set(['uav', 'ops']);
  const retiredNavPaths = new Set(['/uav', '/ops']);
  const retiredNavLabels = new Set(['无人机复查', '监控运维']);

  return items
    .filter((item) => item && !retiredNavKeys.has(item.key) && !retiredNavPaths.has(item.path) && !retiredNavLabels.has(item.label))
    .map((item) => {
      const { badge, ...rest } = item;
      return rest;
    });
}

function sanitizeRuntimeConfig(configs = [], aiWorkers = null) {
  return configs.map((config) => {
    if (config.key === 'navItems' && Array.isArray(config.value)) {
      return {
        ...config,
        value: stripNavBadges(config.value),
      };
    }
    if (config.key === 'aiWorkers' && Array.isArray(aiWorkers)) return { ...config, value: clone(aiWorkers) };
    return config;
  });
}

function applyCameraHeartbeats(cameras = [], statuses = [], aiEvents = [], aiWorkerStatuses = []) {
  const includeAiWorkerCameraStatus = strictTruthy.has(
    String(process.env.CAMERA_STATUS_INCLUDE_AI_WORKERS || '').trim().toLowerCase(),
  );
  const statusByCamera = bestCameraStatusByKey([
    ...statuses.filter(isAuthoritativeCameraStatus),
    ...(includeAiWorkerCameraStatus ? cameraStatusesFromAiWorkers(aiWorkerStatuses) : []),
  ]);
  const detectionClearCameraIds = detectionClearCameraIdsFromAiWorkers(aiWorkerStatuses);
  const detectionsByCamera = detectionsFromAiEvents(aiEvents, detectionClearCameraIds);

  return cameras.map((camera) => {
    const heartbeat = statusByCamera.get(camera.id);
    const heartbeatFresh = isFreshHeartbeat(heartbeat?.heartbeatAt, cameraStatusTtlMs());
    const detections = detectionsByCamera.get(camera.id) || [];

    if (!heartbeatFresh) {
      const disconnectedCamera = stripGeneratedRtspPlaceholder(camera);
      return {
        ...disconnectedCamera,
        status: '未接入',
        bitrate: '0Mbps',
        latency: 0,
        detections,
        statusSource: 'stream-heartbeat',
        statusDetail: heartbeat ? 'stream heartbeat expired' : 'waiting for real stream heartbeat',
        lastHeartbeatAt: heartbeat?.heartbeatAt || '',
      };
    }

    const status = normalizeDeviceStatus(heartbeat.status);
    return {
      ...camera,
      status,
      bitrate: heartbeat.bitrate || (status === '在线' ? camera.bitrate : '0Mbps'),
      latency: Number(heartbeat.latency ?? (status === '在线' ? camera.latency : 0)),
      detections,
      statusSource: heartbeat.source || 'stream-heartbeat',
      statusDetail: heartbeat.detail || '',
      lastHeartbeatAt: heartbeat.heartbeatAt || '',
    };
  });
}

function isAuthoritativeCameraStatus(record = {}) {
  const source = String(record.source || record.statusSource || '').trim().toLowerCase();
  if (!source) return true;
  if (source === 'browser-playback') {
    const detail = String(record.detail || '').trim().toLowerCase();
    const transport = String(record.transport || '').trim().toLowerCase();
    const status = normalizeDeviceStatus(record.status);
    return status === '在线' && transport === 'hls' && (detail.includes('frame ready') || detail.includes('playback alive'));
  }
  return !['frontend-playback', 'ui-playback'].includes(source);
}

function cameraStatusesFromAiWorkers(statuses = []) {
  return statuses.flatMap((status) => {
    if (!isFreshHeartbeat(status.heartbeatAt, aiWorkerStatusTtlMs()) || normalizeWorkerStatus(status.status) !== 'online') return [];
    const ids = new Set();
    if (status.cameraId) ids.add(String(status.cameraId).toUpperCase());
    if (Array.isArray(status.channels)) {
      status.channels.forEach((channel) => ids.add(String(channel).toUpperCase()));
    }
    return [...ids].map((cameraId) => ({
      cameraId,
      status: 'online',
      source: status.source || 'river-ai-worker',
      detail: status.detail || 'ai worker heartbeat online',
      latency: status.latencyMs,
      heartbeatAt: status.heartbeatAt,
    }));
  });
}

function detectionClearCameraIdsFromAiWorkers(statuses = []) {
  const clear = new Map();
  for (const status of statuses) {
    if (!isFreshHeartbeat(status.heartbeatAt, aiWorkerStatusTtlMs()) || normalizeWorkerStatus(status.status) !== 'online') continue;
    if (!/^\s*0\s+boxes\b/i.test(String(status.detail || ''))) continue;
    for (const cameraId of cameraIdsFromAiWorkerStatus(status)) {
      const current = clear.get(cameraId);
      if (!current || heartbeatTime(status.heartbeatAt) > heartbeatTime(current)) clear.set(cameraId, status.heartbeatAt);
    }
  }
  return clear;
}

function cameraIdsFromAiWorkerStatus(status = {}) {
  const ids = new Set();
  const addIfCameraId = (value) => {
    const id = String(value || '').trim().toUpperCase();
    if (/^CH\d{2}$/.test(id)) ids.add(id);
  };
  addIfCameraId(status.cameraId);
  addIfCameraId(status.workerId);
  if (Array.isArray(status.channels)) status.channels.forEach(addIfCameraId);
  return ids;
}

function bestCameraStatusByKey(records = []) {
  const map = new Map();
  for (const record of records) {
    const id = record?.cameraId;
    if (!id) continue;
    const current = map.get(id);
    if (!current || cameraStatusRank(record) > cameraStatusRank(current)) map.set(id, record);
  }
  return map;
}

function cameraStatusRank(record = {}) {
  const source = String(record.source || record.statusSource || '').trim().toLowerCase();
  const status = normalizeDeviceStatus(record.status);
  const fresh = isFreshHeartbeat(record.heartbeatAt, cameraStatusTtlMs());
  const online = status === '在线';
  const sourcePriority = {
    'browser-playback': 80,
    'river-ai-worker': 70,
    'river-worker': 70,
    'stream-relay': 65,
    'stream-probe': 50,
    'stream-heartbeat': 45,
  }[source] ?? 40;
  const healthPriority = fresh ? (online ? 1000 : 100) : 0;
  return healthPriority + sourcePriority + heartbeatTime(record.heartbeatAt) / 1e13;
}

function shouldPreserveCameraStatus(existing = null, incoming = {}) {
  if (!existing) return false;
  if (normalizeDeviceStatus(existing.status) !== '在线') return false;
  if (normalizeDeviceStatus(incoming.status) === '在线') return false;
  if (!isFreshHeartbeat(existing.heartbeatAt, cameraStatusTtlMs())) return false;

  const incomingSource = String(incoming.source || incoming.statusSource || '').trim().toLowerCase();
  const existingSource = String(existing.source || existing.statusSource || '').trim().toLowerCase();
  const trustedOnlineSources = new Set(['browser-playback', 'river-worker', 'river-ai-worker', 'stream-relay', 'stream-probe']);
  if (incomingSource === 'stream-probe' && trustedOnlineSources.has(existingSource)) return true;
  return cameraStatusRank(existing) > cameraStatusRank(incoming);
}

function stripGeneratedRtspPlaceholder(camera = {}) {
  const ip = String(camera.ip || '').trim();
  const streamUrl = String(camera.streamUrl || '').trim();
  if (ip && streamUrl === `rtsp://${ip}/stream1`) return { ...camera, streamUrl: '' };
  return camera;
}

function applyAiWorkerHeartbeats(workers = [], statuses = []) {
  const statusByWorker = latestStatusByKey(statuses, 'workerId');
  const configured = workers.length
    ? workers
    : statuses.map((status) => ({
        id: status.workerId,
        name: status.workerId,
        model: status.model || '',
        runtime: status.runtime || '',
        channels: status.channels || [],
      }));

  return configured.map((worker) => {
    const heartbeat = statusByWorker.get(worker.id);
    const heartbeatFresh = isFreshHeartbeat(heartbeat?.heartbeatAt, aiWorkerStatusTtlMs());
    if (heartbeatFresh) return workerFromHeartbeat(worker, heartbeat);

    const aggregate = aggregateChannelWorkerHeartbeats(worker, statuses);
    if (aggregate) return aggregate;

    return {
      ...worker,
      status: 'offline',
      fps: 0,
      latencyMs: 0,
      statusSource: 'worker-heartbeat',
      statusDetail: heartbeat ? 'worker heartbeat expired' : 'waiting for real worker heartbeat',
      lastHeartbeatAt: heartbeat?.heartbeatAt || '',
    };
  });
}

function workerFromHeartbeat(worker = {}, heartbeat = {}) {
  return {
    ...worker,
    ...heartbeat,
    id: worker.id,
    status: normalizeWorkerStatus(heartbeat.status),
    fps: Number(heartbeat.fps ?? worker.fps ?? 0),
    latencyMs: Number(heartbeat.latencyMs ?? worker.latencyMs ?? 0),
    statusSource: heartbeat.source || 'worker-heartbeat',
    statusDetail: heartbeat.detail || '',
    lastHeartbeatAt: heartbeat.heartbeatAt || '',
  };
}

function aggregateChannelWorkerHeartbeats(worker = {}, statuses = []) {
  const channels = new Set((worker.channels || []).map((channel) => String(channel).toUpperCase()));
  if (!channels.size) return null;

  const related = statuses.filter((status) => {
    const workerId = String(status.workerId || '').toUpperCase();
    const cameraId = String(status.cameraId || '').toUpperCase();
    const statusChannels = Array.isArray(status.channels) ? status.channels.map((channel) => String(channel).toUpperCase()) : [];
    return channels.has(workerId) || channels.has(cameraId) || statusChannels.some((channel) => channels.has(channel));
  });
  if (!related.length) return null;

  const fresh = related.filter((status) => isFreshHeartbeat(status.heartbeatAt, aiWorkerStatusTtlMs()));
  const latest = related.reduce((current, status) => (heartbeatTime(status.heartbeatAt) > heartbeatTime(current?.heartbeatAt) ? status : current), null);
  if (!fresh.length) {
    return {
      ...worker,
      status: 'offline',
      fps: 0,
      latencyMs: 0,
      statusSource: latest?.source || 'worker-heartbeat',
      statusDetail: latest ? 'worker heartbeat expired' : 'waiting for real worker heartbeat',
      lastHeartbeatAt: latest?.heartbeatAt || '',
    };
  }

  const online = fresh.filter((status) => normalizeWorkerStatus(status.status) === 'online');
  const latencyValues = online.map((status) => Number(status.latencyMs)).filter(Number.isFinite);
  const onlineIds = online.map((status) => String(status.cameraId || status.workerId || '').toUpperCase()).filter(Boolean);
  return {
    ...worker,
    status: online.length ? 'online' : 'offline',
    fps: online.reduce((sum, status) => sum + Number(status.fps || 0), 0),
    latencyMs: latencyValues.length ? Math.round(latencyValues.reduce((sum, value) => sum + value, 0) / latencyValues.length) : 0,
    statusSource: latest?.source || 'worker-heartbeat',
    statusDetail: online.length
      ? `${online.length}/${channels.size} channels online${onlineIds.length ? `: ${onlineIds.join(',')}` : ''}`
      : fresh.map((status) => status.detail).filter(Boolean).join('; ') || 'waiting for online channel heartbeat',
    lastHeartbeatAt: latest?.heartbeatAt || '',
  };
}

function detectionsFromAiEvents(events = [], clearCameraIds = new Map()) {
  const byCamera = new Map();
  const ttlMs = metadataOverlayTtlMs();

  for (const event of events) {
    const cameraId = String(event.cameraId || event.request?.cameraId || event.payload?.cameraId || event.result?.alarm?.cameraId || '').toUpperCase();
    if (!cameraId || byCamera.has(cameraId) || !isFreshHeartbeat(event.receivedAt, ttlMs)) continue;
    const clearAt = clearCameraIds.get?.(cameraId);
    if (clearAt && heartbeatTime(clearAt) >= heartbeatTime(event.receivedAt)) {
      byCamera.set(cameraId, []);
      continue;
    }
    const request = event.request || event.payload?.request || event.payload || event;
    const boxes = Array.isArray(request.boxes) ? request.boxes : Array.isArray(request.detections) ? request.detections : [];
    const result = event.result || event.payload?.result || {};
    const fallbackSeverity = result?.alarm?.severity;
    byCamera.set(cameraId, boxes.map((box, index) => detectionFromBox(box, index, fallbackSeverity)));
  }

  return byCamera;
}

function detectionFromBox(box = {}, index = 0, fallbackSeverity = '') {
  const score = Number(box.score ?? box.confidence ?? 0);
  const confidence = score > 1 ? score / 100 : score;
  return {
    id: String(box.id || `AI-${index}`),
    label: String(box.cls || box.label || box.name || 'AI识别事件'),
    confidence,
    severity: fallbackSeverity || severityFromConfidence(confidence),
    x: normalizeBoxPercent(box.x),
    y: normalizeBoxPercent(box.y),
    w: normalizeBoxPercent(box.w ?? box.width),
    h: normalizeBoxPercent(box.h ?? box.height),
  };
}

function normalizeBoxPercent(value) {
  const number = Number(value || 0);
  if (!Number.isFinite(number)) return 0;
  return number <= 1 ? number * 100 : number;
}

function severityFromConfidence(confidence) {
  if (confidence >= 0.9) return '紧急';
  if (confidence >= 0.8) return '严重';
  if (confidence >= 0.6) return '一般';
  return '提示';
}

function latestStatusByKey(records = [], key) {
  const map = new Map();
  for (const record of records) {
    const id = record?.[key];
    if (!id) continue;
    const current = map.get(id);
    if (!current || heartbeatTime(record.heartbeatAt) > heartbeatTime(current.heartbeatAt)) map.set(id, record);
  }
  return map;
}

function isFreshHeartbeat(value, ttlMs) {
  const time = heartbeatTime(value);
  return time > 0 && Date.now() - time <= ttlMs;
}

function heartbeatTime(value) {
  if (!value) return 0;
  const date = value instanceof Date ? value : new Date(value);
  const time = date.getTime();
  return Number.isFinite(time) ? time : 0;
}

function normalizeCameraStatus(input = {}) {
  const cameraId = String(input.cameraId || input.id || '').trim().toUpperCase();
  if (!cameraId) throw new Error('missing cameraId');
  return {
    ...input,
    cameraId,
    status: normalizeDeviceStatus(input.status),
    heartbeatAt: input.heartbeatAt || input.timestamp || nowIso(),
  };
}

function normalizeAiWorkerStatus(input = {}) {
  const workerId = String(input.workerId || input.id || '').trim();
  if (!workerId) throw new Error('missing workerId');
  return {
    ...input,
    workerId,
    status: normalizeWorkerStatus(input.status),
    heartbeatAt: input.heartbeatAt || input.timestamp || nowIso(),
  };
}

function normalizeDeviceStatus(value) {
  const text = String(value || '').trim().toLowerCase();
  if (['online', 'up', 'ok', 'ready', 'true', '1'].includes(text) || value === '在线') return '在线';
  if (['maintenance', 'maintaining'].includes(text) || value === '维护中') return '维护中';
  if (['offline', 'down', 'false', '0'].includes(text) || value === '离线') return '离线';
  if (['error', 'failed', 'fault', 'degraded'].includes(text) || value === '链路异常') return '链路异常';
  return value || '未接入';
}

function normalizeWorkerStatus(value) {
  const text = String(value || '').trim().toLowerCase();
  if (['online', 'up', 'ok', 'ready', 'running', 'true', '1'].includes(text)) return 'online';
  if (['degraded', 'warning'].includes(text)) return 'degraded';
  return 'offline';
}

function normalizeDeviceNames(snapshot = {}) {
  const normalized = {
    ...snapshot,
    cameras: clone(snapshot.cameras || []),
    alarms: clone(snapshot.alarms || []),
    workOrders: clone(snapshot.workOrders || []),
    evidenceBundles: clone(snapshot.evidenceBundles || []),
    uavTasks: clone(snapshot.uavTasks || []),
    uavAssets: clone(snapshot.uavAssets || []),
    importJobs: clone(snapshot.importJobs || []),
    aiEvents: clone(snapshot.aiEvents || []),
  };
  const cameraById = new Map(normalized.cameras.map((camera) => [camera.id, camera]));
  const originalAlarmNameById = new Map();

  normalized.alarms = normalized.alarms.map((alarm) => {
    const camera = cameraById.get(alarm.cameraId);
    originalAlarmNameById.set(alarm.id, alarm.cameraName);
    if (!camera?.name) return alarm;

    return {
      ...alarm,
      cameraName: camera.name,
      snapshot: replaceDeviceName(alarm.snapshot, [alarm.cameraName], camera.name),
    };
  });

  const alarmById = new Map(normalized.alarms.map((alarm) => [alarm.id, alarm]));

  normalized.workOrders = normalized.workOrders.map((order) => normalizeLinkedWorkOrder(order, alarmById, cameraById, originalAlarmNameById));
  normalized.evidenceBundles = normalized.evidenceBundles.map((bundle) => normalizeLinkedEvidenceBundle(bundle, alarmById, cameraById, originalAlarmNameById));
  normalized.uavTasks = normalized.uavTasks.map((task) => normalizeLinkedUavTask(task, alarmById, cameraById, originalAlarmNameById));
  normalized.aiEvents = normalized.aiEvents.map((event) => normalizeLinkedAiEvent(event, alarmById, cameraById, originalAlarmNameById));

  return normalized;
}

function normalizeLinkedWorkOrder(order, alarmById, cameraById, originalAlarmNameById) {
  const alarm = alarmById.get(order.alarmId);
  const camera = alarm ? cameraById.get(alarm.cameraId) : null;
  const normalizedOrder = normalizeWorkOrderTimestamps(order, alarm);
  if (!alarm || !camera?.name) return normalizedOrder;

  const oldNames = [originalAlarmNameById.get(alarm.id), alarm.cameraName].filter(Boolean);
  const title = cleanWorkOrderTitle(replaceDeviceName(normalizedOrder.title, oldNames, camera.name));

  return {
    ...normalizedOrder,
    title: title && title !== normalizedOrder.title ? title : `${camera.name} ${alarm.type || '异常'}`,
  };
}

function normalizeWorkOrderTimestamps(order = {}, alarm = null) {
  const timeline = Array.isArray(order.timeline) ? order.timeline : [];
  const firstTimelineTime = timeline.find((entry) => entry?.time)?.time;
  const confirmTimelineTime = timeline.find((entry) =>
    String(entry?.note || '').includes('确认') || entry?.to === '派单'
  )?.time;
  const reminderTimelineTime = [...timeline].reverse().find((entry) =>
    String(entry?.note || '').includes('催办') || String(entry?.note || '').includes('提醒')
  )?.time;
  const startedTimelineTime = timeline.find((entry) =>
    entry?.to === '处置' || String(entry?.note || '').includes('开始处置')
  )?.time;
  const reviewTimelineTime = timeline.find((entry) =>
    entry?.to === '复核' || String(entry?.note || '').includes('提交复核')
  )?.time;
  const archiveTimelineTime = timeline.find((entry) =>
    entry?.to === '归档' || String(entry?.note || '').includes('复核归档')
  )?.time;
  const createdAt = order.createdAt || firstTimelineTime || alarm?.createdAt || alarm?.time || order.updatedAt || order.completedAt || '';

  return {
    ...order,
    title: cleanWorkOrderTitle(order.title),
    createdAt,
    confirmedAt: order.confirmedAt || order.acceptedAt || confirmTimelineTime || createdAt,
    lastReminderAt: order.lastReminderAt || reminderTimelineTime,
    startedAt: order.startedAt || startedTimelineTime,
    reviewSubmittedAt: order.reviewSubmittedAt || reviewTimelineTime,
    archivedAt: order.archivedAt || archiveTimelineTime || order.completedAt,
    updatedAt: order.updatedAt || createdAt,
  };
}

function cleanWorkOrderTitle(title = '') {
  return String(title || '').replace(/\s*处置闭环\s*$/u, '').trim();
}

function normalizeLinkedEvidenceBundle(bundle, alarmById, cameraById, originalAlarmNameById) {
  const alarm = alarmById.get(bundle.alarmId);
  const camera = alarm ? cameraById.get(alarm.cameraId) : null;
  if (!alarm || !camera?.name) return bundle;
  if (bundle.manifestHash || String(bundle.hash || '').startsWith('sha256:') || bundle.status === '已固化') return bundle;

  const oldNames = [originalAlarmNameById.get(alarm.id), alarm.cameraName].filter(Boolean);
  const name = replaceDeviceName(bundle.name, oldNames, camera.name);
  const normalized = {
    ...bundle,
    name: name && name !== bundle.name ? name : `${camera.name} ${alarm.type || '异常'}证据包`,
  };

  if (Array.isArray(normalized.materialsList)) {
    normalized.materialsList = normalized.materialsList.map((material) => ({
      ...material,
      name: replaceDeviceName(material.name, oldNames, camera.name),
      content: isPlainObject(material.content)
        ? {
            ...material.content,
            cameraName: camera.name,
            note: replaceDeviceName(material.content.note, oldNames, camera.name),
          }
        : material.content,
    }));
  }

  if (isPlainObject(normalized.manifest)) {
    normalized.manifest = {
      ...normalized.manifest,
      name: normalized.name,
      materials: Array.isArray(normalized.manifest.materials)
        ? normalized.manifest.materials.map((material) => ({
            ...material,
            name: replaceDeviceName(material.name, oldNames, camera.name),
          }))
        : normalized.manifest.materials,
    };
  }

  return normalized;
}

function normalizeLinkedUavTask(task, alarmById, cameraById, originalAlarmNameById) {
  const relatedAlarmId = task.relatedAlarm || task.relatedAlarmId;
  const alarm = alarmById.get(relatedAlarmId);
  const camera = alarm ? cameraById.get(alarm.cameraId) : null;
  if (!alarm || !camera?.name) return task;

  const oldNames = [originalAlarmNameById.get(alarm.id), alarm.cameraName].filter(Boolean);
  const name = replaceDeviceName(task.name, oldNames, camera.name);

  return {
    ...task,
    name: name && name !== task.name ? name : `${camera.name} ${alarm.type || '异常'}复查`,
  };
}

function normalizeLinkedAiEvent(event, alarmById, cameraById, originalAlarmNameById) {
  const result = isPlainObject(event.result) ? { ...event.result } : null;
  if (!result) return event;

  let alarm = result.alarm || alarmById.get(event.alarmId);
  const camera = alarm ? cameraById.get(alarm.cameraId) : null;
  if (!alarm || !camera?.name) return event;

  const oldNames = [originalAlarmNameById.get(alarm.id), alarm.cameraName].filter(Boolean);
  alarm = {
    ...alarm,
    cameraName: camera.name,
    snapshot: replaceDeviceName(alarm.snapshot, oldNames, camera.name),
  };

  return {
    ...event,
    result: {
      ...result,
      alarm,
      workOrder: result.workOrder ? normalizeLinkedWorkOrder(result.workOrder, new Map([[alarm.id, alarm]]), cameraById, originalAlarmNameById) : result.workOrder,
    },
  };
}

function replaceDeviceName(value, oldNames, newName) {
  if (!value || !newName) return value;
  return unique([...(oldNames || [])])
    .filter((name) => name && name !== newName)
    .reduce((text, name) => String(text).split(String(name)).join(newName), String(value));
}

function unique(values) {
  return Array.from(new Set(values));
}

function withRuntimeConfig(snapshot, configs = []) {
  const sanitizedConfigs = sanitizeRuntimeConfig(configs);
  const config = runtimeConfigMap(sanitizedConfigs);
  return {
    ...snapshot,
    navItems: config.navItems || [],
    diagnostics: config.diagnostics || { healthy: [], failed: [] },
    aiWorkers: config.aiWorkers || [],
    operationRoutes: config.operationRoutes || [],
    operationProfiles: config.operationProfiles || {},
    operationSpecialSpecs: config.operationSpecialSpecs || {},
    runtimeConfig: sanitizedConfigs,
  };
}

function runtimeConfigMap(configs = []) {
  return configs.reduce((acc, item) => {
    if (!item?.key) return acc;
    acc[item.key] = item.value;
    return acc;
  }, {});
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function isBadDeviceStatus(status) {
  return ['链路异常', '离线', '未接入'].includes(String(status || ''));
}

function parsePayload(payload) {
  if (payload == null) return null;
  return typeof payload === 'string' ? JSON.parse(payload) : clone(payload);
}

function stringifyPayload(payload) {
  return JSON.stringify(payload);
}

function toMysqlDate(value) {
  if (!value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return null;
  return date.toISOString().slice(0, 19).replace('T', ' ');
}

function fromMysqlDate(value) {
  if (!value) return '';
  if (value instanceof Date && !Number.isNaN(value.getTime())) return value.toISOString();
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toISOString();
}
