#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/home/ai-river/river-watch}"
BACKUP_DIR="${1:-$(find "$APP_DIR/backups" -maxdepth 1 -mindepth 1 -type d -name 'event-situation-persistent-aggregation-20260718-v2-*' -printf '%T@ %p\n' | sort -rn | head -1 | cut -d' ' -f2-)}"
[ -n "$BACKUP_DIR" ] && [ -d "$BACKUP_DIR" ] || { echo "ERROR: rollback backup not found" >&2; exit 1; }
SUDO=""
[ "$(id -u)" -ne 0 ] && SUDO="sudo"
run_docker() { $SUDO docker "$@"; }
backend_ctn="$(run_docker ps -a --format '{{.Names}}' | grep -E 'backend' | head -1)"
frontend_ctn="$(run_docker ps -a --format '{{.Names}}' | grep -E 'frontend|nginx|web' | head -1)"

echo "Restoring from $BACKUP_DIR"
for file in server.mjs store.mjs event-groups.mjs ai-metadata.mjs; do
  if [ -f "$BACKUP_DIR/backend/host/$file" ]; then
    $SUDO cp -a "$BACKUP_DIR/backend/host/$file" "$APP_DIR/backend/src/$file"
  else
    $SUDO rm -f "$APP_DIR/backend/src/$file"
  fi
  if [ -f "$BACKUP_DIR/backend/container/$file" ]; then
    run_docker cp "$BACKUP_DIR/backend/container/$file" "$backend_ctn:/app/src/$file"
  else
    run_docker exec "$backend_ctn" rm -f "/app/src/$file" || true
  fi
done

while IFS= read -r saved; do
  rel="${saved#"$BACKUP_DIR/"}"
  case "$rel" in
    backend/*|frontend/dist/*) continue ;;
  esac
  $SUDO install -D -m 0644 "$saved" "$APP_DIR/$rel"
done < <(find "$BACKUP_DIR/frontend/src" "$BACKUP_DIR/api" -type f 2>/dev/null || true)

$SUDO rm -f "$APP_DIR/frontend/src/services/eventGroups.ts" "$APP_DIR/frontend/src/__tests__/eventSituationQueue.test.ts"
$SUDO rm -rf "$APP_DIR/frontend/dist/assets"
$SUDO cp -a "$BACKUP_DIR/frontend/dist/assets" "$APP_DIR/frontend/dist/assets"
$SUDO cp -a "$BACKUP_DIR/frontend/dist/index.html" "$APP_DIR/frontend/dist/index.html"
run_docker exec "$frontend_ctn" sh -lc 'rm -rf /usr/share/nginx/html/assets'
run_docker cp "$BACKUP_DIR/frontend/dist/assets" "$frontend_ctn:/usr/share/nginx/html/assets"
run_docker cp "$BACKUP_DIR/frontend/dist/index.html" "$frontend_ctn:/usr/share/nginx/html/index.html"
run_docker restart "$backend_ctn" >/dev/null
run_docker restart "$frontend_ctn" >/dev/null
echo "ROLLBACK DONE"
