#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/home/ai-river/river-watch}"
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TS="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$APP_DIR/backups/event-situation-persistent-aggregation-20260718-v2-$TS"
PREFLIGHT_DIR="/app/.event-situation-preflight-$TS"
SUDO=""
[ "$(id -u)" -ne 0 ] && SUDO="sudo"
BACKEND_CHANGED=0
FRONTEND_CHANGED=0
EVENT_GROUP_TABLE_EXISTED=0
EVENT_LINK_TABLE_EXISTED=0

BACKEND_FILES=(server.mjs store.mjs event-groups.mjs ai-metadata.mjs)
FRONTEND_FILES=(
  frontend/src/types.ts
  frontend/src/api/platformApi.ts
  frontend/src/components/WorkspaceDialogs.vue
  frontend/src/composables/useWorkspace.ts
  frontend/src/services/eventGroups.ts
  frontend/src/stores/platform.ts
  frontend/src/views/pages/EventsPage.vue
  frontend/src/styles.css
  frontend/src/__tests__/eventSituationQueue.test.ts
  frontend/src/__tests__/alarmReviewDialog.test.ts
  api/openapi.yaml
)

run_docker() { $SUDO docker "$@"; }
fail() { echo "ERROR: $*" >&2; return 1; }

wait_for_http() {
  local label="$1" url="$2" attempts="${3:-60}"
  for attempt in $(seq 1 "$attempts"); do
    if curl -fsS -m 5 "$url" >/dev/null 2>&1; then
      echo "$label ready after attempt $attempt/$attempts"
      return 0
    fi
    sleep 2
  done
  fail "$label did not become ready: $url"
}

container_hash() {
  run_docker exec "$backend_ctn" sha256sum "/app/src/$1" | awk '{print $1}'
}

host_hash() { sha256sum "$APP_DIR/$1" | awk '{print $1}'; }

require_hash() {
  local label="$1" actual="$2" expected="$3"
  [ "$actual" = "$expected" ] || fail "$label baseline drift: actual=$actual expected=$expected"
  echo "OK $label $actual"
}

mysql_scalar() {
  local sql="$1"
  run_docker exec "$mysql_ctn" sh -lc \
    'mysql -N -B -uroot -p"$MYSQL_ROOT_PASSWORD" "$MYSQL_DATABASE" -e "$1"' sh "$sql"
}

restore_frontend_file() {
  local rel="$1"
  if [ -f "$BACKUP_DIR/$rel" ]; then
    $SUDO install -D -m 0644 "$BACKUP_DIR/$rel" "$APP_DIR/$rel"
  else
    $SUDO rm -f "$APP_DIR/$rel"
  fi
}

rollback() {
  local code=$?
  trap - ERR
  echo "== Automatic rollback after deployment failure ==" >&2
  run_docker exec "$backend_ctn" rm -rf "$PREFLIGHT_DIR" >/dev/null 2>&1 || true

  if [ "$FRONTEND_CHANGED" -eq 1 ]; then
    for rel in "${FRONTEND_FILES[@]}"; do restore_frontend_file "$rel"; done
    $SUDO rm -rf "$APP_DIR/frontend/dist/assets"
    $SUDO cp -a "$BACKUP_DIR/frontend/dist/assets" "$APP_DIR/frontend/dist/assets"
    $SUDO cp -a "$BACKUP_DIR/frontend/dist/index.html" "$APP_DIR/frontend/dist/index.html"
    run_docker exec "$frontend_ctn" sh -lc 'rm -rf /usr/share/nginx/html/assets' || true
    run_docker cp "$BACKUP_DIR/frontend/dist/assets" "$frontend_ctn:/usr/share/nginx/html/assets" || true
    run_docker cp "$BACKUP_DIR/frontend/dist/index.html" "$frontend_ctn:/usr/share/nginx/html/index.html" || true
    run_docker restart "$frontend_ctn" >/dev/null 2>&1 || true
  fi

  if [ "$BACKEND_CHANGED" -eq 1 ]; then
    for file in "${BACKEND_FILES[@]}"; do
      if [ -f "$BACKUP_DIR/backend/host/$file" ]; then
        $SUDO cp -a "$BACKUP_DIR/backend/host/$file" "$APP_DIR/backend/src/$file"
      else
        $SUDO rm -f "$APP_DIR/backend/src/$file"
      fi
      if [ -f "$BACKUP_DIR/backend/container/$file" ]; then
        run_docker cp "$BACKUP_DIR/backend/container/$file" "$backend_ctn:/app/src/$file" || true
      else
        run_docker exec "$backend_ctn" rm -f "/app/src/$file" || true
      fi
    done
    run_docker restart "$backend_ctn" >/dev/null 2>&1 || true
  fi

  if [ "$EVENT_LINK_TABLE_EXISTED" -eq 0 ]; then
    mysql_scalar 'DROP TABLE IF EXISTS rw_event_group_alarm' >/dev/null 2>&1 || true
  fi
  if [ "$EVENT_GROUP_TABLE_EXISTED" -eq 0 ]; then
    mysql_scalar 'DROP TABLE IF EXISTS rw_event_group' >/dev/null 2>&1 || true
  fi
  echo "Rollback backup: $BACKUP_DIR" >&2
  exit "$code"
}

trap rollback ERR

echo "== River Watch persistent event aggregation increment v2 =="
echo "APP_DIR=$APP_DIR"
echo "PKG_DIR=$PKG_DIR"

[ -d "$APP_DIR/backend/src" ] || fail "backend source directory not found"
[ -d "$APP_DIR/frontend/src" ] || fail "frontend source directory not found"
run_docker info >/dev/null 2>&1 || fail "Docker is unavailable"
backend_ctn="$(run_docker ps --format '{{.Names}}' | grep -E 'backend' | head -1 || true)"
frontend_ctn="$(run_docker ps --format '{{.Names}}' | grep -E 'frontend|nginx|web' | head -1 || true)"
mysql_ctn="$(run_docker ps --format '{{.Names}} {{.Image}}' | awk 'BEGIN{IGNORECASE=1} /mysql|mariadb/{print $1; exit}')"
[ -n "$backend_ctn" ] || fail "backend container not found"
[ -n "$frontend_ctn" ] || fail "frontend container not found"
[ -n "$mysql_ctn" ] || fail "MySQL container not found"

echo "== 1. Verify package and deployed baseline =="
(cd "$PKG_DIR" && sha256sum -c SHA256SUMS)
require_hash "backend server.mjs" "$(container_hash server.mjs)" "3229ccaa2994238a1698a23b8e52b098c03314bb8412c48c4b4cef0fb6560806"
require_hash "backend store.mjs" "$(container_hash store.mjs)" "87c414688b21a53dd14b9195a54e858ec391eca538c233660670a59bfbdfc941"
require_hash "backend ai-metadata.mjs" "$(container_hash ai-metadata.mjs)" "c9ca42adeed9fa0363219ac4fad51b6eacc084e90f5e0e999a340175c958dac0"
require_hash "frontend WorkspaceDialogs.vue" "$(host_hash frontend/src/components/WorkspaceDialogs.vue)" "487d47d6795b3be17f138ecd344abfa9de78b22ec478343dd76ed90a50446305"
require_hash "frontend useWorkspace.ts" "$(host_hash frontend/src/composables/useWorkspace.ts)" "f5f2e5c59650151a0eafa6aa8700c1e894fb6dbfbe9b1e617697f0ff762091c2"
require_hash "frontend styles.css" "$(host_hash frontend/src/styles.css)" "8362d0e5f3ee1e2e8b5614b13ab3c11ce7e61d47985fd7b0aeedbc78d0f56865"
grep -q 'platform.dedupedAlarms' "$APP_DIR/frontend/src/views/pages/EventsPage.vue" || fail "unexpected EventsPage baseline"

EVENT_GROUP_TABLE_EXISTED="$(mysql_scalar "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='rw_event_group'")"
EVENT_LINK_TABLE_EXISTED="$(mysql_scalar "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='rw_event_group_alarm'")"

echo "== 2. Backup only changed files and runtime assets =="
$SUDO mkdir -p "$BACKUP_DIR/backend/host" "$BACKUP_DIR/backend/container" "$BACKUP_DIR/frontend/dist"
for file in "${BACKEND_FILES[@]}"; do
  [ -f "$APP_DIR/backend/src/$file" ] && $SUDO cp -a "$APP_DIR/backend/src/$file" "$BACKUP_DIR/backend/host/$file"
  if run_docker exec "$backend_ctn" test -f "/app/src/$file"; then
    run_docker cp "$backend_ctn:/app/src/$file" "$BACKUP_DIR/backend/container/$file"
  fi
done
for rel in "${FRONTEND_FILES[@]}"; do
  [ -f "$APP_DIR/$rel" ] && $SUDO install -D -m 0644 "$APP_DIR/$rel" "$BACKUP_DIR/$rel"
done
$SUDO cp -a "$APP_DIR/frontend/dist/index.html" "$BACKUP_DIR/frontend/dist/index.html"
$SUDO cp -a "$APP_DIR/frontend/dist/assets" "$BACKUP_DIR/frontend/dist/assets"
echo "Rollback backup: $BACKUP_DIR"

echo "== 3. Preflight complete backend module loading inside container =="
run_docker exec "$backend_ctn" sh -lc "rm -rf '$PREFLIGHT_DIR' && cp -a /app/src '$PREFLIGHT_DIR'"
for file in "${BACKEND_FILES[@]}"; do
  run_docker cp "$PKG_DIR/backend/src/$file" "$backend_ctn:$PREFLIGHT_DIR/$file"
done
run_docker exec "$backend_ctn" sh -lc \
  "node --check '$PREFLIGHT_DIR/server.mjs' && node --check '$PREFLIGHT_DIR/store.mjs' && node --check '$PREFLIGHT_DIR/event-groups.mjs'"
run_docker exec "$backend_ctn" node --input-type=module -e \
  "await import('file://$PREFLIGHT_DIR/server.mjs'); console.log('container module import OK')"
run_docker exec "$backend_ctn" rm -rf "$PREFLIGHT_DIR"

echo "== 4. Apply backend and initialize persistent aggregation =="
BACKEND_CHANGED=1
for file in "${BACKEND_FILES[@]}"; do
  $SUDO cp -a "$PKG_DIR/backend/src/$file" "$APP_DIR/backend/src/$file"
  run_docker cp "$PKG_DIR/backend/src/$file" "$backend_ctn:/app/src/$file"
done
run_docker exec "$backend_ctn" sh -lc 'node --check /app/src/server.mjs && node --check /app/src/store.mjs && node --check /app/src/event-groups.mjs && node --check /app/src/ai-metadata.mjs'
run_docker exec "$backend_ctn" node --input-type=module -e \
  "await import('file:///app/src/server.mjs'); console.log('live module import OK')"
run_docker restart "$backend_ctn" >/dev/null
wait_for_http backend http://127.0.0.1:8080/api/health

echo "== 5. Apply frontend source and prebuilt assets =="
FRONTEND_CHANGED=1
for rel in "${FRONTEND_FILES[@]}"; do
  $SUDO install -D -m 0644 "$PKG_DIR/$rel" "$APP_DIR/$rel"
done
$SUDO rm -rf "$APP_DIR/frontend/dist/assets"
$SUDO cp -a "$PKG_DIR/frontend/dist/assets" "$APP_DIR/frontend/dist/assets"
$SUDO cp -a "$PKG_DIR/frontend/dist/index.html" "$APP_DIR/frontend/dist/index.html"
run_docker exec "$frontend_ctn" sh -lc 'rm -rf /usr/share/nginx/html/assets'
run_docker cp "$PKG_DIR/frontend/dist/assets" "$frontend_ctn:/usr/share/nginx/html/assets"
run_docker cp "$PKG_DIR/frontend/dist/index.html" "$frontend_ctn:/usr/share/nginx/html/index.html"
run_docker restart "$frontend_ctn" >/dev/null
wait_for_http frontend http://127.0.0.1:8081/

echo "== 6. Verify database, API, source and web assets =="
[ "$(mysql_scalar "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME IN ('rw_event_group','rw_event_group_alarm')")" = "2" ]
open_events="$(mysql_scalar "SELECT COUNT(*) FROM rw_event_group WHERE status='待研判'")"
linked_alarms="$(mysql_scalar 'SELECT COUNT(*) FROM rw_event_group_alarm')"
run_docker exec "$backend_ctn" grep -q 'listEventGroups' /app/src/server.mjs
run_docker exec "$backend_ctn" grep -q 'open_dedupe_key' /app/src/store.mjs
grep -q 'eventQueueRows' "$APP_DIR/frontend/src/views/pages/EventsPage.vue"
grep -q 'selectedAggregateEvent' "$APP_DIR/frontend/src/components/WorkspaceDialogs.vue"
grep -Rqs 'firstOccurredAt' "$PKG_DIR/frontend/dist/assets"
grep -Rqs '归集统计' "$PKG_DIR/frontend/dist/assets"
curl -fsS http://127.0.0.1:8080/api/health
curl -fsS http://127.0.0.1:8081/ >/dev/null

echo "== 7. Keep only latest two v2 rollback backups =="
mapfile -t old_backups < <(find "$APP_DIR/backups" -maxdepth 1 -mindepth 1 -type d -name 'event-situation-persistent-aggregation-20260718-v2-*' -printf '%T@ %p\n' | sort -rn | awk 'NR>2 {$1=""; sub(/^ /, ""); print}')
for old_backup in "${old_backups[@]:-}"; do
  [ -n "$old_backup" ] && $SUDO rm -rf -- "$old_backup"
done

trap - ERR
echo "VERIFY OK"
echo "DONE"
echo "open_events=$open_events linked_alarms=$linked_alarms"
echo "Rollback backup: $BACKUP_DIR"
