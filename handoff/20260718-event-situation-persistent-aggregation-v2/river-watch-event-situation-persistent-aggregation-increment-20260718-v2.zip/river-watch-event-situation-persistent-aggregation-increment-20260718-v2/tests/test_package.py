from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def test_required_payload_exists():
    required = [
        "backend/src/event-groups.mjs",
        "backend/src/ai-metadata.mjs",
        "backend/src/server.mjs",
        "backend/src/store.mjs",
        "frontend/src/services/eventGroups.ts",
        "frontend/src/views/pages/EventsPage.vue",
        "frontend/src/components/WorkspaceDialogs.vue",
        "frontend/src/composables/useWorkspace.ts",
        "frontend/src/styles.css",
        "frontend/dist/index.html",
        "api/openapi.yaml",
    ]
    assert all((ROOT / item).is_file() for item in required)


def test_backend_uses_persistent_event_lifecycle():
    server = read("backend/src/server.mjs")
    store = read("backend/src/store.mjs")
    lifecycle = read("backend/src/event-groups.mjs")
    assert "/api/v1/events" in server and "listEventGroups" in server
    assert "CREATE TABLE IF NOT EXISTS rw_event_group" in store
    assert "CREATE TABLE IF NOT EXISTS rw_event_group_alarm" in store
    assert "UNIQUE KEY uq_rw_event_group_open(open_dedupe_key)" in store
    assert "INSERT IGNORE INTO rw_event_group_alarm" in store
    assert "closeEventGroupForAlarmPool" in store
    assert "closeAggregateEvent" in lifecycle
    assert "randomUUID().slice(0, 8)" in read("backend/src/ai-metadata.mjs")


def test_backend_is_rebased_on_the_exact_production_module_graph():
    server = read("backend/src/server.mjs")
    store = read("backend/src/store.mjs")
    assert "./integrations/" not in server
    assert "./integrations/" not in store
    assert "configureIntegrationsFromEnv" not in server
    assert "emitAudit" not in store and "emitMetric" not in store


def test_frontend_has_complete_dates_and_stable_single_line_table():
    page = read("frontend/src/views/pages/EventsPage.vue")
    service = read("frontend/src/services/eventGroups.ts")
    styles = read("frontend/src/styles.css")
    dialog = read("frontend/src/components/WorkspaceDialogs.vue")
    assert page.count("<th>") == 10
    assert "firstOccurredText" in page and "latestOccurredText" in page
    assert "YYYY" not in service
    assert "timeZone: 'Asia/Shanghai'" in service
    assert re.search(r"\.event-table\s+table\s*\{[^}]*min-width:\s*1500px", styles, re.S)
    assert "white-space: nowrap" in styles
    assert "selectedAggregateEvent" in dialog
    assert all(label in dialog for label in ("首次发生", "最近报警", "归集统计"))


def test_package_avoids_duplicate_static_assets():
    dist_files = [path for path in (ROOT / "frontend/dist").rglob("*") if path.is_file()]
    dist_bytes = sum(path.stat().st_size for path in dist_files)
    assert len(dist_files) < 80
    assert dist_bytes < 8 * 1024 * 1024
    assert not list((ROOT / "frontend/dist").rglob("*.mbtiles"))
    assert not list((ROOT / "frontend/dist").rglob("*.jpg"))


def test_deployment_is_guarded_and_reversible():
    apply = read("scripts/apply-event-situation-persistent-aggregation-20260718-v2.sh")
    verify = read("scripts/verify-event-situation-persistent-aggregation-20260718-v2.sh")
    rollback = read("scripts/rollback-event-situation-persistent-aggregation-20260718-v2.sh")
    assert "baseline drift" in apply
    assert "trap rollback ERR" in apply
    assert "BACKUP_DIR" in apply
    assert "EVENT_GROUP_TABLE_EXISTED" in apply
    assert "PREFLIGHT_DIR" in apply
    assert "cp -a /app/src" in apply
    assert "node --input-type=module" in apply
    assert "await import('file://$PREFLIGHT_DIR/server.mjs')" in apply
    assert "await import('file:///app/src/server.mjs')" in apply
    assert "node --input-type=module" in verify
    assert "VERIFY OK" in apply and "DONE" in apply
    assert "ROLLBACK DONE" in rollback


if __name__ == "__main__":
    tests = [value for name, value in globals().items() if name.startswith("test_") and callable(value)]
    for test in tests:
        test()
        print(f"PASS {test.__name__}")
    print(f"PASS {len(tests)} package tests")
