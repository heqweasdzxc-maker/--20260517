# River Watch training capture FFmpeg compatibility hotfix v3

Production evidence showed that CH01-CH09 failed before connecting because the
installed FFmpeg rejects `-rw_timeout` with `Option rw_timeout not found`.

This minimal increment changes one runtime Python file. It removes that
build-specific option while preserving:

- RTSP over TCP;
- Python's 25-second subprocess timeout;
- main-stream-first fallback behavior;
- credential-redacted diagnostics;
- the existing timer, run directory and captured files;
- all River Watch, group inference, database and model services.

CH10 remains an expected failure while `192.168.2.21` is unreachable.

