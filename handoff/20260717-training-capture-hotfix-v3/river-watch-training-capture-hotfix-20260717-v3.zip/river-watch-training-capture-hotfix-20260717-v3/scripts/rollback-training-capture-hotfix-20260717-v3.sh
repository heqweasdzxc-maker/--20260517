#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/home/ai-river/river-watch}"
INSTALL_DIR="${INSTALL_DIR:-/opt/river-watch/training-capture}"
BACKUP_DIR="${BACKUP_DIR:-}"

[[ "$(id -u)" -eq 0 ]] || { echo "ERROR: run with sudo" >&2; exit 1; }
if [[ -z "$BACKUP_DIR" ]]; then
  BACKUP_DIR="$(find "$APP_DIR/backups" -mindepth 1 -maxdepth 1 -type d -name 'training-capture-hotfix-20260717-v3-*' -printf '%T@ %p\n' | sort -nr | awk 'NR == 1 {sub(/^[^ ]+ /, ""); print}')"
fi
[[ -n "$BACKUP_DIR" && -f "$BACKUP_DIR/install/training_capture.py" ]] || {
  echo "ERROR: v3 rollback backup not found" >&2
  exit 1
}

systemctl stop river-training-capture.service || true
install -m 0755 "$BACKUP_DIR/install/training_capture.py" "$INSTALL_DIR/training_capture.py"
PYTHONDONTWRITEBYTECODE=1 python3 -m py_compile "$INSTALL_DIR/training_capture.py"
systemctl enable --now river-training-capture.timer
echo "ROLLBACK DONE"

