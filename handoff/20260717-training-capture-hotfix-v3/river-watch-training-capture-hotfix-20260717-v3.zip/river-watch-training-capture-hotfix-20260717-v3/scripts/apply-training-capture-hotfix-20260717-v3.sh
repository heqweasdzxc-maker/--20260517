#!/usr/bin/env bash
set -Eeuo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_DIR="${APP_DIR:-/home/ai-river/river-watch}"
INSTALL_DIR="${INSTALL_DIR:-/opt/river-watch/training-capture}"
CONFIG_FILE="${CONFIG_FILE:-/etc/river-watch/training-capture.conf}"
EXPECTED_V2_SHA="b290a1dbfdda8051949a261081713577f69b2e72a6d117691b0225aa7aa42aa2"
TS="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$APP_DIR/backups/training-capture-hotfix-20260717-v3-$TS"

[[ "$(id -u)" -eq 0 ]] || { echo "ERROR: run with sudo" >&2; exit 1; }
[[ -f "$CONFIG_FILE" ]] || { echo "ERROR: missing $CONFIG_FILE" >&2; exit 1; }
[[ -f "$INSTALL_DIR/training_capture.py" ]] || { echo "ERROR: capture tool is not installed" >&2; exit 1; }

echo "== 1. Verify minimal v3 package =="
(cd "$PACKAGE_DIR" && sha256sum -c SHA256SUMS)

echo "== 2. Verify installed v2 baseline =="
actual_sha="$(sha256sum "$INSTALL_DIR/training_capture.py" | awk '{print $1}')"
[[ "$actual_sha" == "$EXPECTED_V2_SHA" ]] || {
  echo "ERROR: unexpected installed capture baseline: $actual_sha" >&2
  exit 1
}

echo "== 3. Backup and install one Python file =="
install -d -m 0755 "$BACKUP_DIR/install"
cp -a "$INSTALL_DIR/training_capture.py" "$BACKUP_DIR/install/training_capture.py"
systemctl stop river-training-capture.service || true
install -m 0755 "$PACKAGE_DIR/training_capture/training_capture.py" "$INSTALL_DIR/training_capture.py"
PYTHONDONTWRITEBYTECODE=1 python3 -m py_compile "$INSTALL_DIR/training_capture.py"

run_dir="$(awk -F= '$1 == "RUN_DIR" {sub(/^[^=]*=/, ""); print; exit}' "$CONFIG_FILE")"
[[ -n "$run_dir" && "$run_dir" == /home/ai-river/training-captures/* ]] || {
  echo "ERROR: unsafe or missing RUN_DIR" >&2
  exit 1
}

echo "== 4. Queue immediate retry when the current slot has no image =="
last_slot_file="$run_dir/.last-slot"
manifest="$run_dir/manifest.tsv"
retry=0
if [[ -f "$last_slot_file" ]]; then
  last_slot="$(tr -dc '0-9' < "$last_slot_file")"
  usable="$(awk -F '\t' -v slot="$last_slot" 'NR > 1 && $1 == slot && ($4 == "SUCCESS" || $4 == "LOW_RESOLUTION") {n++} END {print n+0}' "$manifest" 2>/dev/null || echo 0)"
  if [[ -n "$last_slot" && "$usable" -eq 0 ]]; then
    cp -a "$last_slot_file" "$BACKUP_DIR/last-slot"
    rm -f -- "$last_slot_file"
    retry=1
  fi
fi

systemctl enable --now river-training-capture.timer
if [[ "$retry" -eq 1 ]]; then
  systemctl start --no-block river-training-capture.service
  echo "current failed slot queued for immediate retry"
else
  echo "no retry needed; timer schedule retained"
fi

echo "DONE"
echo "backup=$BACKUP_DIR"
echo "run_dir=$run_dir"

