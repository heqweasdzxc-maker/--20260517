#!/usr/bin/env bash
set -Eeuo pipefail

CONFIG_FILE="${CONFIG_FILE:-/etc/river-watch/training-capture.conf}"
run_dir="$(awk -F= '$1 == "RUN_DIR" {sub(/^[^=]*=/, ""); print; exit}' "$CONFIG_FILE")"

echo "== timer =="
systemctl is-active river-training-capture.timer
systemctl is-enabled river-training-capture.timer

echo "== latest capture rows =="
tail -20 "$run_dir/manifest.tsv"

echo "== JPEG count and files =="
find "$run_dir" -maxdepth 2 -type f -name '*.jpg' -printf '%P\t%s bytes\n' | sort
count="$(find "$run_dir" -maxdepth 2 -type f -name '*.jpg' | wc -l)"
echo "jpeg_count=$count"

if [[ "$count" -eq 0 ]]; then
  echo "ERROR: no JPEG captured yet" >&2
  exit 1
fi

echo "VERIFY OK"

