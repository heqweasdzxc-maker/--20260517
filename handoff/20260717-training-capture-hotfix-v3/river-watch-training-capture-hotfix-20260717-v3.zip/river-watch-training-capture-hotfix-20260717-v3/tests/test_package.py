import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = tuple((ROOT / "scripts").glob("*.sh"))


class PackageTests(unittest.TestCase):
    def test_required_minimal_files_exist(self):
        required = [
            ROOT / "training_capture" / "training_capture.py",
            ROOT / "scripts" / "apply-training-capture-hotfix-20260717-v3.sh",
            ROOT / "scripts" / "verify-training-capture-hotfix-20260717-v3.sh",
            ROOT / "scripts" / "rollback-training-capture-hotfix-20260717-v3.sh",
            ROOT / "README.md",
        ]
        self.assertEqual([str(path) for path in required if not path.is_file()], [])

    def test_scripts_are_strict_and_do_not_control_river_services(self):
        forbidden = re.compile(r"river-ai-|deploy-(?:backend|frontend|mysql|zlmediakit)")
        for script in SCRIPTS:
            text = script.read_text(encoding="utf-8")
            self.assertTrue(text.startswith("#!/usr/bin/env bash\n"))
            self.assertIn("set -Eeuo pipefail", text)
            self.assertIsNone(forbidden.search(text), script.name)

    def test_runtime_has_no_build_specific_rw_timeout(self):
        text = (ROOT / "training_capture" / "training_capture.py").read_text(encoding="utf-8")
        self.assertNotIn('"-rw_timeout"', text)
        self.assertIn('"-rtsp_transport", "tcp"', text)
        self.assertIn("timeout=max(1, int(timeout_sec))", text)

    def test_no_embedded_rtsp_credentials(self):
        credential_url = re.compile(r"rtsp://[^\s/'\"]+@", re.IGNORECASE)
        for path in [ROOT / "training_capture" / "training_capture.py", *SCRIPTS]:
            self.assertIsNone(credential_url.search(path.read_text(encoding="utf-8")), str(path))


if __name__ == "__main__":
    unittest.main()

