#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/home/ai-river/river-watch}"
SUDO=""
[ "$(id -u)" -ne 0 ] && SUDO="sudo"
run_docker() { $SUDO docker "$@"; }

backend_ctn="$(run_docker ps --format '{{.Names}}' | grep -E 'backend' | head -1)"
frontend_ctn="$(run_docker ps --format '{{.Names}}' | grep -E 'frontend|nginx|web' | head -1)"
mysql_ctn="$(run_docker ps --format '{{.Names}} {{.Image}}' | awk 'BEGIN{IGNORECASE=1} /mysql|mariadb/{print $1; exit}')"

echo "== services =="
run_docker ps --format 'table {{.Names}}\t{{.Status}}' | grep -E 'backend|frontend|mysql'
curl -fsS http://127.0.0.1:8080/api/health
curl -fsS http://127.0.0.1:8081/ >/dev/null

echo "== database =="
run_docker exec "$mysql_ctn" sh -lc 'mysql --default-character-set=utf8mb4 -uroot -p"$MYSQL_ROOT_PASSWORD" "$MYSQL_DATABASE" -e "
SELECT status, COUNT(*) AS event_count, SUM(occurrence_count) AS alarm_occurrences
FROM rw_event_group GROUP BY status ORDER BY status;
SELECT COUNT(*) AS linked_raw_alarms FROM rw_event_group_alarm;
SELECT id,camera_id,type,first_occurred_at,latest_occurred_at,occurrence_count,status
FROM rw_event_group ORDER BY latest_occurred_at DESC LIMIT 10;
"'

echo "== deployed markers =="
run_docker exec "$backend_ctn" grep -n 'listEventGroups' /app/src/server.mjs | head
run_docker exec "$backend_ctn" grep -n 'open_dedupe_key' /app/src/store.mjs | head
grep -n 'eventQueueRows' "$APP_DIR/frontend/src/views/pages/EventsPage.vue" | head
grep -n 'selectedAggregateEvent' "$APP_DIR/frontend/src/components/WorkspaceDialogs.vue" | head
run_docker exec "$frontend_ctn" sh -lc 'grep -Rqs firstOccurredAt /usr/share/nginx/html/assets && grep -Rqs 归集统计 /usr/share/nginx/html/assets'

echo "VERIFY OK"
