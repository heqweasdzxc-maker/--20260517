import http from 'node:http';
import net from 'node:net';
import os from 'node:os';
import { execFile, spawn } from 'node:child_process';
import { createHash, createHmac, randomUUID } from 'node:crypto';
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { apiError, apiOk, clone, createWorkOrderFromAlarm, severityFromScore } from './rules.mjs';
import { createMemoryStore, createStoreFromEnv, isStrictProductionMode } from './store.mjs';
import { buildNotification, channelStatus, deliver, dispatchAlarmNotifications } from './notify.mjs';
import { createAiIngestService } from './ai-ingest.mjs';
import { configureIntegrationsFromEnv } from './integrations/index.mjs';
import { createWvpSyncFromEnv } from './integrations/wvp-sync.mjs';
import { applySecurityHeaders, bootSecurityCheck, createRateLimiter } from './integrations/security-hardening.mjs';

const defaultPort = Number(process.env.PORT || 8080);
const DEFAULT_CAMERA_PROBE_INTERVAL_MS = 30000;
const DEFAULT_CAMERA_PROBE_TIMEOUT_MS = 1800;

function nowIso(date = new Date()) {
  const value = date instanceof Date ? date : new Date(date);
  if (Number.isNaN(value.getTime())) return nowIso(new Date());
  return new Date(value.getTime() + 8 * 60 * 60 * 1000).toISOString().replace('Z', '+08:00');
}

function beijingTimeText(date = new Date()) {
  const value = date instanceof Date ? date : new Date(date);
  const safe = Number.isNaN(value.getTime()) ? new Date() : value;
  return safe.toLocaleTimeString('zh-CN', { hour12: false, timeZone: 'Asia/Shanghai' });
}

export function createApp(options = {}) {
  const store = options.store ?? createMemoryStore(options.state);
  const authRequired = options.authRequired ?? process.env.AUTH_REQUIRED === 'true';
  const aiIngest = options.aiIngest ?? createAiIngestService(store, { dispatchNotifications: dispatchAlarmNotifications });
  const streamRelay = options.streamRelay ?? null;

  const loginAttempts = new Map();
  const loginWindowMs = Number(process.env.AUTH_LOGIN_WINDOW_MS || 60000);
  const loginMaxAttempts = Number(process.env.AUTH_LOGIN_MAX_ATTEMPTS || 20);
  const guardLogin = (ip) => {
    const now = Date.now();
    const rec = loginAttempts.get(ip);
    if (!rec || now - rec.start > loginWindowMs) {
      loginAttempts.set(ip, { start: now, count: 1 });
      return;
    }
    rec.count += 1;
    if (rec.count > loginMaxAttempts) throw httpError(429, '登录尝试过于频繁，请稍后再试');
  };

  return http.createServer(async (req, res) => {
    try {
      setCors(res);

      if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
      }

      const url = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`);
      const pathName = normalizePath(url.pathname);
      let authContext = null;

      if (authRequired && !isPublicRoute(req.method, pathName)) {
        authContext = verifyToken(req.headers.authorization || '') || verifyIngestToken(req.headers.authorization || '');
        if (!authContext) {
          send(res, 401, apiError('未认证或登录已过期', 401));
          return;
        }
        if (authContext.serviceToken && !isAiIngestRoute(req.method, pathName)) {
          send(res, 403, apiError('权限不足：服务令牌仅允许 AI 写入接口', 403));
          return;
        }
      }

      const denyPermission = (permission) => {
        if (authRequired && !hasPermission(authContext, permission)) {
          send(res, 403, apiError(`权限不足：需要 ${permission}`, 403));
          return true;
        }
        return false;
      };

      if (req.method === 'GET' && (pathName === '/health' || pathName === '/api/health')) {
        send(res, 200, { status: 'UP', service: 'river-watch-backend', store: store.mode, timestamp: nowIso() });
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/auth/login' || pathName === '/api/v1/auth/login')) {
        if (authRequired) guardLogin(clientIp(req));
        const body = await readJson(req);
        const username = String(body.username || '').trim() || 'admin';
        if (authRequired) {
          const password = String(body.password || '');
          const expected = process.env.AUTH_DEFAULT_PASSWORD || '123456';
          if (!password || password !== expected) throw httpError(401, '账号或密码错误');
        }
        const user = await authUserProfile(store, username);
        send(res, 200, apiOk({ token: signToken(user), user }));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/auth/me' || pathName === '/api/v1/auth/me')) {
        send(res, 200, apiOk(await authUserProfile(store, authContext?.sub || 'admin', authContext?.roleId)));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/platform/snapshot' || pathName === '/api/v1/platform/snapshot')) {
        send(res, 200, apiOk(await store.snapshot()));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/templates' || pathName === '/api/template/profiles' || pathName === '/api/v1/templates' || pathName === '/api/v1/template/profiles')) {
        const snapshot = await store.snapshot();
        send(res, 200, apiOk(clone(snapshot.templates || [])));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/templates' || pathName === '/api/template/profiles' || pathName === '/api/v1/templates' || pathName === '/api/v1/template/profiles')) {
        if (denyPermission('template:write')) return;
        const body = await readJson(req);
        const snapshot = await store.snapshot();
        const template = buildTemplateProfile(body, snapshot.templates || []);
        send(res, 200, apiOk(await store.createTemplate(template)));
        return;
      }

      const templateProfileRoute =
        match(pathName, /^\/api\/templates\/([^/]+)$/) ||
        match(pathName, /^\/api\/template\/profiles\/([^/]+)$/) ||
        match(pathName, /^\/api\/v1\/templates\/([^/]+)$/) ||
        match(pathName, /^\/api\/v1\/template\/profiles\/([^/]+)$/);
      if (req.method === 'DELETE' && templateProfileRoute) {
        if (denyPermission('template:write')) return;
        const id = decodeURIComponent(templateProfileRoute[1]);
        send(res, 200, apiOk(await store.deleteTemplate(id)));
        return;
      }
      if (req.method === 'PUT' && templateProfileRoute) {
        if (denyPermission('template:write')) return;
        const id = decodeURIComponent(templateProfileRoute[1]);
        const snapshot = await store.snapshot();
        const existing = (snapshot.templates || []).find((item) => item.id === id);
        if (!existing) throw httpError(404, `模板不存在：${id}`);
        const template = buildTemplateProfile({ ...existing, ...(await readJson(req)), id }, snapshot.templates || []);
        send(res, 200, apiOk(await store.updateTemplate(template)));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/algorithm/models' || pathName === '/api/algorithms' || pathName === '/api/v1/algorithm/models')) {
        send(res, 200, apiOk(await algorithmModelsWithRuntimeStatus(store)));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/algorithm/models' || pathName === '/api/v1/algorithm/models')) {
        if (denyPermission('algorithm:write')) return;
        const body = await readJson(req);
        const snapshot = await store.snapshot();
        const model = buildAlgorithmModel(body, snapshot.algorithms || []);
        send(res, 200, apiOk(await store.createAlgorithm(model)));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/algorithm/models/sync' || pathName === '/api/v1/algorithm/models/sync')) {
        if (denyPermission('algorithm:write')) return;
        send(res, 200, apiOk(await syncAlgorithmModelsFromFiles(store)));
        return;
      }

      const algorithmModelRoute = match(pathName, /^\/api\/algorithm\/models\/([^/]+)$/) || match(pathName, /^\/api\/v1\/algorithm\/models\/([^/]+)$/);
      if (req.method === 'PUT' && algorithmModelRoute) {
        if (denyPermission('algorithm:write')) return;
        const id = decodeURIComponent(algorithmModelRoute[1]);
        const snapshot = await store.snapshot();
        const existing = (snapshot.algorithms || []).find((item) => item.id === id);
        if (!existing) throw httpError(404, `模型不存在：${id}`);
        const model = buildAlgorithmModel({ ...existing, ...(await readJson(req)), id }, snapshot.algorithms || []);
        send(res, 200, apiOk(await store.updateAlgorithm(model)));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/device/devices' || pathName === '/api/v1/devices')) {
        const devices = await store.listCameras(queryFilters(url.searchParams));
        send(res, 200, pathName === '/api/v1/devices' ? apiOk(page(devices)) : apiOk(devices));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/device/devices' || pathName === '/api/v1/devices')) {
        const body = await readJson(req);
        const camera = await store.createCamera(buildCamera(body, await store.listCameras()));
        await syncStreamRelayCamera(streamRelay, camera);
        send(res, 200, apiOk(camera));
        return;
      }

      const deviceRecord = match(pathName, /^\/api\/device\/devices\/([^/]+)$/) || match(pathName, /^\/api\/v1\/devices\/([^/]+)$/);
      if (req.method === 'PUT' && deviceRecord) {
        const id = decodeURIComponent(deviceRecord[1]).toUpperCase();
        const body = await readJson(req);
        const existing = await store.getCamera(id);
        if (!existing) {
          send(res, 404, apiError(`设备不存在：${id}`, 404));
          return;
        }
        const camera = await store.updateCamera(buildCamera({ ...body, id }, await store.listCameras()));
        await syncStreamRelayCamera(streamRelay, camera);
        send(res, 200, apiOk(camera));
        return;
      }

      if (req.method === 'DELETE' && deviceRecord) {
        const id = decodeURIComponent(deviceRecord[1]).toUpperCase();
        const deleted = await store.deleteCamera(id);
        await removeStreamRelayCamera(streamRelay, id);
        send(res, 200, apiOk(deleted));
        return;
      }

      const deviceDiag = match(pathName, /^\/api\/device\/devices\/([^/]+)\/diagnostics$/);
      const v1DeviceDiag = match(pathName, /^\/api\/v1\/devices\/([^/]+)\/diagnose$/);
      if ((req.method === 'GET' && deviceDiag) || (req.method === 'POST' && v1DeviceDiag)) {
        const requestedId = decodeURIComponent((deviceDiag || v1DeviceDiag)[1]).trim().toUpperCase();
        const id = requestedId.startsWith('CH') ? requestedId : `CH${String(requestedId).padStart(2, '0')}`;
        const snapshot = typeof store.snapshot === 'function' ? await store.snapshot() : { cameras: await store.listCameras() };
        const camera = (snapshot.cameras || []).find((item) => item.id === id);
        const steps = buildDeviceDiagnosticSteps(camera, id);
        send(res, 200, v1DeviceDiag ? apiOk({ deviceId: requestedId, healthy: steps.every((item) => item.state === 'ok'), stages: steps }) : apiOk(steps));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/device/status' || pathName === '/api/v1/device/status')) {
        send(res, 200, apiOk(typeof store.listCameraStatuses === 'function' ? await store.listCameraStatuses() : []));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/device/status' || pathName === '/api/v1/device/status')) {
        if (denyPermission('ai:ingest')) return;
        const body = await readJson(req);
        const record = await store.recordCameraStatus(body);
        send(res, 200, apiOk(record));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/uav/assets' || pathName === '/api/v1/uav/assets')) {
        const assets = await store.listUavAssets(queryFilters(url.searchParams));
        send(res, 200, pathName === '/api/v1/uav/assets' ? apiOk(page(assets)) : apiOk(assets));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/uav/assets' || pathName === '/api/v1/uav/assets')) {
        const body = await readJson(req);
        send(res, 200, apiOk(await store.createUavAsset(buildUavAsset(body, await store.listUavAssets()))));
        return;
      }

      const uavAssetRoute = match(pathName, /^\/api\/uav\/assets\/([^/]+)$/) || match(pathName, /^\/api\/v1\/uav\/assets\/([^/]+)$/);
      if (req.method === 'PUT' && uavAssetRoute) {
        const id = decodeURIComponent(uavAssetRoute[1]).toUpperCase();
        const body = await readJson(req);
        const existing = await store.getUavAsset(id);
        if (!existing) {
          send(res, 404, apiError(`无人机资产不存在：${id}`, 404));
          return;
        }
        send(res, 200, apiOk(await store.updateUavAsset(buildUavAsset({ ...existing, ...body, id }, await store.listUavAssets()))));
        return;
      }

      if (req.method === 'DELETE' && uavAssetRoute) {
        const id = decodeURIComponent(uavAssetRoute[1]).toUpperCase();
        send(res, 200, apiOk(await store.deleteUavAsset(id)));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/events' || pathName === '/api/v1/events')) {
        const events = await store.listEventGroups(queryFilters(url.searchParams));
        send(res, 200, pathName === '/api/v1/events' ? apiOk(page(events)) : apiOk(events));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/alarm/alarms' || pathName === '/api/v1/alarms')) {
        const alarms = await store.listAlarms(queryFilters(url.searchParams));
        send(res, 200, pathName === '/api/v1/alarms' ? apiOk(page(alarms)) : apiOk(alarms));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/alarm/alarms' || pathName === '/api/v1/alarms')) {
        const body = await readJson(req);
        const alarm = await buildAlarmRecord(store, body);
        send(res, 200, apiOk(await store.createAlarm(alarm)));
        return;
      }

      const alarmDetail = match(pathName, /^\/api\/alarm\/alarms\/([^/]+)$/) || match(pathName, /^\/api\/v1\/alarms\/([^/]+)$/);
      if (req.method === 'GET' && alarmDetail) {
        const id = decodeURIComponent(alarmDetail[1]);
        const alarms = await store.listAlarms();
        const alarm = alarms.find((item) => item.id === id);
        if (!alarm) throw httpError(404, `告警不存在：${id}`);
        send(res, 200, apiOk(alarm));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/uav/recheck' || pathName === '/api/v1/uav/recheck')) {
        const body = await readJson(req);
        const alarmId = String(body.alarmId || '').trim();
        if (!alarmId) throw httpError(400, '缺少 alarmId');
        const alarms = await store.listAlarms();
        const alarm = alarms.find((item) => item.id === alarmId);
        if (!alarm) throw httpError(404, `告警不存在：${alarmId}`);
        const task = {
          id: `UAV-${Date.now().toString().slice(-6)}`,
          name: `${alarm.cameraName || alarm.cameraId} ${alarm.type} 异常复查`,
          type: '异常复查',
          status: '待起飞',
          dock: body.dock || '就近机巢',
          eta: body.eta || '10 分钟',
          relatedAlarm: alarmId,
          createdAt: nowIso(),
        };
        send(res, 200, apiOk(await store.createUavTask(task)));
        return;
      }

      const alarmReview = match(pathName, /^\/api\/alarm\/alarms\/([^/]+)\/review$/);
      if (req.method === 'POST' && alarmReview) {
        const body = await readJson(req);
        const status = body.action === 'ignore' ? '忽略' : body.status || '已确认';
        const { alarm } = await store.reviewAlarm(decodeURIComponent(alarmReview[1]), status, createWorkOrderFromAlarm);
        send(res, 200, apiOk(alarm));
        return;
      }

      const v1AlarmConfirm = match(pathName, /^\/api\/v1\/alarms\/([^/]+)\/confirm$/);
      if (req.method === 'PUT' && v1AlarmConfirm) {
        const body = await readJson(req);
        const status = body.result === 'false_alarm' || body.action === 'ignore' ? '忽略' : '已确认';
        const { alarm } = await store.reviewAlarm(decodeURIComponent(v1AlarmConfirm[1]), status, createWorkOrderFromAlarm);
        send(res, 200, apiOk(alarm));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/workorder/workorders' || pathName === '/api/v1/orders')) {
        const workOrders = await store.listWorkOrders();
        send(res, 200, pathName === '/api/v1/orders' ? apiOk(page(workOrders)) : apiOk(workOrders));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/workorder/stats' || pathName === '/api/v1/orders/stats')) {
        send(res, 200, apiOk(buildWorkOrderStats(await store.listWorkOrders())));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/workorder/workorders' || pathName === '/api/v1/orders')) {
        const body = await readJson(req);
        const existing = await store.listWorkOrders();
        const now = nowIso();
        const order = {
          id: `WO-${9200 + existing.length}`,
          alarmId: body.alarmId || '',
          title: cleanWorkOrderTitle(body.title || '手工创建工单'),
          assignee: body.assignee || '河道巡检组',
          status: '派单',
          slaHours: Number(body.slaHours || 12),
          elapsedHours: 0,
          priority: body.priority || '一般',
          slaState: '正常',
          createdAt: now,
          confirmedAt: body.confirmedAt || now,
          updatedAt: now,
          lastAction: '手工创建',
          timeline: [
            {
              time: now,
              from: '派单',
              to: '派单',
              operator: body.operator || '监管运营员',
              note: '手工创建工单',
            },
          ],
        };
        send(res, 200, apiOk(await store.createWorkOrder(order)));
        return;
      }

      const workOrderTransition =
        match(pathName, /^\/api\/workorder\/workorders\/([^/]+)\/transition$/) ||
        match(pathName, /^\/api\/v1\/orders\/([^/]+)\/status$/);
      if ((req.method === 'POST' || req.method === 'PUT') && workOrderTransition) {
        const id = decodeURIComponent(workOrderTransition[1]);
        const order = await store.getWorkOrder(id);
        if (!order) throw httpError(404, `工单不存在：${id}`);
        const body = await readJson(req);
        const updated = buildWorkOrderTransition(order, body);
        send(res, 200, apiOk(await store.updateWorkOrder(updated, `工单流转至${updated.status}`)));
        return;
      }

      const workOrderReminder =
        match(pathName, /^\/api\/workorder\/workorders\/([^/]+)\/remind$/) ||
        match(pathName, /^\/api\/v1\/orders\/([^/]+)\/remind$/);
      if (req.method === 'POST' && workOrderReminder) {
        const id = decodeURIComponent(workOrderReminder[1]);
        const order = await store.getWorkOrder(id);
        if (!order) throw httpError(404, `工单不存在：${id}`);
        const body = await readJson(req);
        const updated = buildWorkOrderReminder(order, body);
        send(res, 200, apiOk(await store.updateWorkOrder(updated, updated.escalated ? '工单超时升级' : '工单催办')));
        return;
      }

      const streamMatch = match(pathName, /^\/api\/(?:v1\/channels|channels|streams)\/([^/]+)(?:\/stream)?$/);
      if (req.method === 'GET' && streamMatch) {
        const cameraId = decodeURIComponent(streamMatch[1]);
        const camera = await store.getCamera(cameraId.toUpperCase());
        send(res, 200, apiOk(streamInfo(cameraId, camera)));
        return;
      }

      const streamMetadataMatch = match(pathName, /^\/api\/(?:v1\/)?streams\/([^/]+)\/metadata$/);
      if (req.method === 'GET' && streamMetadataMatch) {
        const cameraId = decodeURIComponent(streamMetadataMatch[1]).toUpperCase();
        const camera = await store.getCamera(cameraId);
        const metadata = camera?.streams?.metadata || {};
        const detections = Array.isArray(camera?.detections) ? camera.detections : [];
        send(res, 200, apiOk({
          cameraId,
          timestamp: nowIso(),
          coordinateSpace: metadata.coordinateSpace || 'normalized',
          detections,
          boxes: detections,
        }));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/video/config' || pathName === '/api/v1/video/config')) {
        send(res, 200, apiOk(videoGatewayConfig()));
        return;
      }

      const alarmEvidenceMatch = match(pathName, /^\/api\/(?:v1\/)?alarm\/alarms\/([^/]+)\/evidence$/);
      if (req.method === 'GET' && alarmEvidenceMatch) {
        const evidence = await store.getAlarmEvidence?.(alarmEvidenceMatch[1]);
        if (!evidence?.data) throw httpError(404, '该告警未保存历史截图或片段');
        sendBinary(res, evidence.mimeType || 'image/jpeg', evidence.data, {
          'Cache-Control': 'private, max-age=300',
          'X-Alarm-Evidence-Captured-At': evidence.capturedAt || '',
        });
        return;
      }

      const alarmEvidenceMetadataMatch = match(pathName, /^\/api\/(?:v1\/)?alarm\/alarms\/([^/]+)\/evidence\/metadata$/);
      if (req.method === 'GET' && alarmEvidenceMetadataMatch) {
        const alarmId = decodeURIComponent(alarmEvidenceMetadataMatch[1]);
        const evidence = await store.getAlarmEvidence?.(alarmId);
        if (!evidence) throw httpError(404, '该告警未保存历史证据');

        const linkedEvent = evidence.eventId && typeof store.getAiEvent === 'function'
          ? await store.getAiEvent(evidence.eventId)
          : null;
        const request = linkedEvent?.request || linkedEvent?.payload?.request || linkedEvent?.payload || {};
        const linkedBoxes = Array.isArray(request.boxes) ? request.boxes : Array.isArray(request.detections) ? request.detections : [];
        const boxes = Array.isArray(evidence.annotations) && evidence.annotations.length ? evidence.annotations : linkedBoxes;
        send(res, 200, apiOk({
          alarmId,
          eventId: evidence.eventId || linkedEvent?.id || '',
          cameraId: evidence.cameraId || linkedEvent?.cameraId || '',
          capturedAt: evidence.capturedAt || linkedEvent?.receivedAt || '',
          coordinateSpace: evidence.coordinateSpace || request.coordinateSpace || 'normalized',
          detections: boxes,
          boxes,
        }));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/ai/metadata' || pathName === '/api/v1/alarms/metadata')) {
        const body = await readJson(req);
        send(res, 200, apiOk(await aiIngest.ingest(body)));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/playback/clips' || pathName === '/api/v1/playback/clips')) {
        send(res, 200, apiOk(await store.listPlaybackClips(Number(url.searchParams.get('limit') || 100))));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/playback/clips' || pathName === '/api/v1/playback/clips')) {
        if (denyPermission('evidence:write')) return;
        const body = await readJson(req);
        const cameraId = String(body.cameraId || '').trim().toUpperCase();
        if (!cameraId) throw httpError(400, '缺少 cameraId');
        const camera = await store.getCamera(cameraId);
        if (!camera) throw httpError(404, `设备不存在：${cameraId}`);
        const from = String(body.from || '').trim();
        const to = String(body.to || '').trim();
        if (!from || !to) throw httpError(400, '缺少裁剪时间区间 from/to');

        const clipId = `CLIP-${Date.now()}`;
        const clipManifest = canonicalJson({ clipId, cameraId, from, to, alarmId: body.alarmId || null });
        const clip = {
          id: clipId,
          cameraId,
          cameraName: camera.name,
          alarmId: body.alarmId || null,
          from,
          to,
          note: body.note || '',
          status: '已导出',
          fileHash: `sha256:${sha256Text(clipManifest)}`,
          createdAt: nowIso(),
        };

        // 裁剪片段自动入证据链：复用统一组卷与固化逻辑
        const bundle = await buildEvidenceBundle(store, {
          alarmId: body.alarmId,
          materials: [`回放裁剪片段 ${cameraId} ${from}~${to}`, 'PTS 元数据', '裁剪操作记录'],
          operator: body.operator || '监管运营员',
        });
        const savedBundle = await store.createEvidenceBundle(bundle);
        clip.evidenceBundleId = savedBundle.id;
        const savedClip = await store.createPlaybackClip(clip);
        send(res, 200, apiOk({ clip: savedClip, evidenceBundle: savedBundle }));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/notify/notifications' || pathName === '/api/v1/notify/notifications')) {
        send(res, 200, apiOk(await store.listNotifications(Number(url.searchParams.get('limit') || 100))));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/notify/notifications' || pathName === '/api/v1/notify/notifications')) {
        if (denyPermission('notify:write')) return;
        const body = await readJson(req);
        const channels = Array.isArray(body.channels) && body.channels.length ? body.channels : ['站内'];
        const created = [];
        for (const channel of channels) {
          const notification = buildNotification({ ...body, channel });
          await deliver(notification);
          created.push(await store.createNotification(notification));
        }
        send(res, 200, apiOk(created));
        return;
      }

      const notifyResend = match(pathName, /^\/api\/(?:v1\/)?notify\/notifications\/([^/]+)\/resend$/);
      if (req.method === 'POST' && notifyResend) {
        if (denyPermission('notify:write')) return;
        const id = decodeURIComponent(notifyResend[1]);
        const notification = await store.getNotification(id);
        if (!notification) throw httpError(404, `通知不存在：${id}`);
        await deliver(notification);
        send(res, 200, apiOk(await store.updateNotification(notification, '重发通知')));
        return;
      }

      const notifyAck = match(pathName, /^\/api\/(?:v1\/)?notify\/notifications\/([^/]+)\/ack$/);
      if (req.method === 'POST' && notifyAck) {
        const id = decodeURIComponent(notifyAck[1]);
        const notification = await store.getNotification(id);
        if (!notification) throw httpError(404, `通知不存在：${id}`);
        notification.receipt = { state: '已确认', at: nowIso() };
        send(res, 200, apiOk(await store.updateNotification(notification, '确认通知回执')));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/notify/rules' || pathName === '/api/v1/notify/rules')) {
        send(res, 200, apiOk(await store.listNotifyRules()));
        return;
      }

      const notifyRuleUpdate = match(pathName, /^\/api\/(?:v1\/)?notify\/rules\/([^/]+)$/);
      if (req.method === 'PUT' && notifyRuleUpdate) {
        if (denyPermission('notify:write')) return;
        const id = decodeURIComponent(notifyRuleUpdate[1]);
        const rules = await store.listNotifyRules();
        const current = rules.find((item) => item.id === id);
        if (!current) throw httpError(404, `通知规则不存在：${id}`);
        const body = await readJson(req);
        const updated = {
          ...current,
          ...body,
          id,
          channels: Array.isArray(body.channels) ? body.channels : current.channels,
          enabled: typeof body.enabled === 'boolean' ? body.enabled : current.enabled,
          updatedAt: nowIso(),
        };
        send(res, 200, apiOk(await store.saveNotifyRule(updated)));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/notify/channels' || pathName === '/api/v1/notify/channels')) {
        send(res, 200, apiOk(channelStatus()));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/ai/health' || pathName === '/api/v1/ai/health')) {
        const recentEvents = await store.listAiEvents(20);
        send(res, 200, apiOk(aiPipelineHealth(recentEvents, await store.listAiWorkers(), aiIngest.stats())));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/ai/workers' || pathName === '/api/v1/ai/workers')) {
        send(res, 200, apiOk(await store.listAiWorkers()));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/ai/worker-status' || pathName === '/api/v1/ai/worker-status')) {
        send(res, 200, apiOk(typeof store.listAiWorkerStatuses === 'function' ? await store.listAiWorkerStatuses() : []));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/ai/worker-status' || pathName === '/api/v1/ai/worker-status')) {
        if (denyPermission('ai:ingest')) return;
        const body = await readJson(req);
        const record = await store.recordAiWorkerStatus(body);
        send(res, 200, apiOk(record));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/ai/events' || pathName === '/api/v1/ai/events')) {
        send(res, 200, apiOk(await store.listAiEvents(Number(url.searchParams.get('limit') || 100))));
        return;
      }

      const aiRetry = match(pathName, /^\/api\/ai\/events\/([^/]+)\/retry$/) || match(pathName, /^\/api\/v1\/ai\/events\/([^/]+)\/retry$/);
      if (req.method === 'POST' && aiRetry) {
        send(res, 200, apiOk(await store.retryAiEvent(decodeURIComponent(aiRetry[1]))));
        return;
      }

      if (req.method === 'POST' && pathName === '/api/export/tasks') {
        const body = await readJson(req);
        const task = { id: `EXP-${Date.now()}`, status: '排队中', ...body };
        send(res, 200, apiOk(await store.createExportTask(task)));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/operation/tasks' || pathName === '/api/v1/operation/tasks')) {
        send(res, 200, apiOk(await store.listOperationTasks(Number(url.searchParams.get('limit') || 100))));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/storage/policies' || pathName === '/api/v1/storage/policies')) {
        send(res, 200, apiOk(await store.listStoragePolicies()));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/storage/status' || pathName === '/api/v1/storage/status')) {
        send(res, 200, apiOk(await store.messageStorageStatus()));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/runtime/hardware' || pathName === '/api/v1/runtime/hardware')) {
        send(res, 200, apiOk(await collectHardwareMetrics()));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/runtime/sentinel' || pathName === '/api/v1/runtime/sentinel')) {
        send(res, 200, apiOk(await runtimeSentinelMode(store)));
        return;
      }

      if ((req.method === 'POST' || req.method === 'PUT') && (pathName === '/api/runtime/sentinel' || pathName === '/api/v1/runtime/sentinel')) {
        const body = await readJson(req);
        send(res, 200, apiOk(await saveRuntimeSentinelMode(store, body, authContext)));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/runtime/confidence-thresholds' || pathName === '/api/v1/runtime/confidence-thresholds')) {
        send(res, 200, apiOk(await runtimeConfidenceThresholds(store)));
        return;
      }

      if ((req.method === 'POST' || req.method === 'PUT') && (pathName === '/api/runtime/confidence-thresholds' || pathName === '/api/v1/runtime/confidence-thresholds')) {
        const body = await readJson(req);
        send(res, 200, apiOk(await saveRuntimeConfidenceThresholds(store, body)));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/storage/policies' || pathName === '/api/v1/storage/policies')) {
        if (denyPermission('storage:write')) return;
        const body = await readJson(req);
        send(res, 200, apiOk(await store.createStoragePolicy(buildStoragePolicy(body, await store.listStoragePolicies()))));
        return;
      }

      const storagePolicyUpdate = match(pathName, /^\/api\/storage\/policies\/([^/]+)$/) || match(pathName, /^\/api\/v1\/storage\/policies\/([^/]+)$/);
      if (req.method === 'PUT' && storagePolicyUpdate) {
        if (denyPermission('storage:write')) return;
        const body = await readJson(req);
        const policies = await store.listStoragePolicies();
        const id = decodeURIComponent(storagePolicyUpdate[1]);
        const current = policies.find((item) => item.id === id || item.name === id);
        if (!current) throw httpError(404, `存储策略不存在：${id}`);
        send(res, 200, apiOk(await store.updateStoragePolicy(buildStoragePolicy({ ...current, ...body, id: current.id }, policies))));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/reports' || pathName === '/api/v1/reports')) {
        send(res, 200, apiOk(await store.listReportMetrics()));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/report/tasks' || pathName === '/api/v1/report/tasks')) {
        send(res, 200, apiOk(await store.listReportTasks()));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/report/tasks' || pathName === '/api/v1/report/tasks')) {
        if (denyPermission('report:write')) return;
        const body = await readJson(req);
        send(res, 200, apiOk(await store.createReportTask(buildReportTask(body, await store.listReportTasks(), await store.snapshot()))));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/reports/export' || pathName === '/api/v1/reports/export')) {
        if (denyPermission('report:export')) return;
        const snapshotForReport = await store.snapshot();
        const csv = buildReportCsv(snapshotForReport, url.searchParams.get('type') || '闭环周报');
        sendCsv(res, `river-watch-report-${Date.now()}.csv`, csv);
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/auth/users' || pathName === '/api/v1/auth/users')) {
        send(res, 200, apiOk(await store.listUsers()));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/auth/users' || pathName === '/api/v1/auth/users')) {
        if (denyPermission('rbac:write')) return;
        const body = await readJson(req);
        send(res, 200, apiOk(await store.createUser(buildUserAccount(body, await store.listUsers()))));
        return;
      }

      const userStatus = match(pathName, /^\/api\/auth\/users\/([^/]+)\/status$/) || match(pathName, /^\/api\/v1\/auth\/users\/([^/]+)\/status$/);
      if (req.method === 'PUT' && userStatus) {
        if (denyPermission('rbac:write')) return;
        const id = decodeURIComponent(userStatus[1]);
        const user = (await store.listUsers()).find((item) => item.id === id);
        if (!user) throw httpError(404, `用户不存在：${id}`);
        const body = await readJson(req);
        const status = body.status || (user.status === '启用' ? '停用' : '启用');
        send(res, 200, apiOk(await store.updateUser({ ...user, status, updatedAt: nowIso() }, `${status}用户账号`)));
        return;
      }

      const userRecord = match(pathName, /^\/api\/auth\/users\/([^/]+)$/) || match(pathName, /^\/api\/v1\/auth\/users\/([^/]+)$/);
      if (req.method === 'PUT' && userRecord) {
        if (denyPermission('rbac:write')) return;
        const id = decodeURIComponent(userRecord[1]);
        const user = (await store.listUsers()).find((item) => item.id === id);
        if (!user) throw httpError(404, `用户不存在：${id}`);
        const body = await readJson(req);
        send(res, 200, apiOk(await store.updateUser(buildUserAccount({ ...user, ...body, id }, await store.listUsers()), '修改用户账号')));
        return;
      }

      if (req.method === 'DELETE' && userRecord) {
        if (denyPermission('rbac:write')) return;
        const id = decodeURIComponent(userRecord[1]);
        send(res, 200, apiOk(await store.deleteUser(id)));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/auth/roles/permissions' || pathName === '/api/v1/auth/roles/permissions')) {
        send(res, 200, apiOk(await store.listRolePermissions()));
        return;
      }

      const rolePermissionRoute = match(pathName, /^\/api\/auth\/roles\/([^/]+)\/permissions$/) || match(pathName, /^\/api\/v1\/auth\/roles\/([^/]+)\/permissions$/);
      if (req.method === 'POST' && rolePermissionRoute) {
        if (denyPermission('rbac:write')) return;
        const body = await readJson(req);
        send(res, 200, apiOk(await store.saveRolePermissions(buildRolePermission(decodeURIComponent(rolePermissionRoute[1]), body))));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/logs' || pathName === '/api/v1/logs')) {
        send(res, 200, apiOk(await store.listLogs({ ...queryFilters(url.searchParams), limit: Number(url.searchParams.get('limit') || 100) })));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/log/search-jobs' || pathName === '/api/v1/log/search-jobs')) {
        send(res, 200, apiOk(await store.listLogSearchJobs()));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/log/retention/status' || pathName === '/api/v1/log/retention/status')) {
        if (denyPermission('audit:read')) return;
        send(res, 200, apiOk(await buildLogRetentionStatus(store)));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/log/search-jobs' || pathName === '/api/v1/log/search-jobs')) {
        if (denyPermission('audit:read')) return;
        const body = await readJson(req);
        const logs = await store.listLogs(body);
        send(res, 200, apiOk(await store.createLogSearchJob(buildLogSearchJob(body, logs))));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/logs/export' || pathName === '/api/v1/logs/export')) {
        if (denyPermission('audit:export')) return;
        const logs = await store.listLogs({ ...queryFilters(url.searchParams), limit: Number(url.searchParams.get('limit') || 500) });
        sendCsv(res, `river-watch-audit-${Date.now()}.csv`, buildAuditCsv(logs));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/ops/status' || pathName === '/api/v1/ops/status')) {
        if (denyPermission('ops:read')) return;
        send(res, 200, apiOk(await buildOpsStatus(store)));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/field/integration/status' || pathName === '/api/v1/field/integration/status')) {
        if (denyPermission('ops:read')) return;
        send(res, 200, apiOk(await buildFieldIntegrationStatus(store)));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/ops/runs' || pathName === '/api/v1/ops/runs')) {
        if (denyPermission('ops:read')) return;
        send(res, 200, apiOk(await store.listOpsRuns(Number(url.searchParams.get('limit') || 50))));
        return;
      }

      const opsRun = match(pathName, /^\/api\/ops\/(backup|restore|offline-images|hardening)\/verify$/) || match(pathName, /^\/api\/v1\/ops\/(backup|restore|offline-images|hardening)\/verify$/);
      if (req.method === 'POST' && opsRun) {
        if (denyPermission('ops:write')) return;
        const body = await readJson(req);
        send(res, 200, apiOk(await store.createOpsRun(await buildOpsRun(store, opsRun[1], body))));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/import/jobs' || pathName === '/api/imports' || pathName === '/api/v1/import/jobs')) {
        const jobs = await store.listImportJobs();
        send(res, 200, apiOk(jobs.map(normalizeImportJob)));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/import/jobs' || pathName === '/api/v1/import/jobs')) {
        const body = await readJson(req);
        const job = await buildImportJob(store, body);
        send(res, 200, apiOk(await store.createImportJob(job)));
        return;
      }

      const importReanalyze = match(pathName, /^\/api\/import\/jobs\/([^/]+)\/reanalyze$/) || match(pathName, /^\/api\/v1\/import\/jobs\/([^/]+)\/reanalyze$/);
      if (req.method === 'POST' && importReanalyze) {
        const id = decodeURIComponent(importReanalyze[1]);
        const body = await readJson(req);
        const job = await store.getImportJob(id);
        if (!job) throw httpError(404, `导入任务不存在：${id}`);
        const updated = rebuildImportAnalysis(normalizeImportJob(job), body);
        send(res, 200, apiOk(await store.updateImportJob(updated, '重新分析导入任务')));
        return;
      }

      const importConvert = match(pathName, /^\/api\/import\/jobs\/([^/]+)\/convert-alarm$/) || match(pathName, /^\/api\/v1\/import\/jobs\/([^/]+)\/convert-alarm$/);
      if (req.method === 'POST' && importConvert) {
        const id = decodeURIComponent(importConvert[1]);
        const body = await readJson(req);
        send(res, 200, apiOk(await convertImportJobToAlarm(store, id, body)));
        return;
      }

      const importDelete = match(pathName, /^\/api\/import\/jobs\/([^/]+)$/) || match(pathName, /^\/api\/v1\/import\/jobs\/([^/]+)$/);
      if (req.method === 'DELETE' && importDelete) {
        const id = decodeURIComponent(importDelete[1]);
        send(res, 200, apiOk(await store.deleteImportJob(id)));
        return;
      }

      if (req.method === 'GET' && (pathName === '/api/evidence' || pathName === '/api/evidence/bundles' || pathName === '/api/v1/evidence/bundles')) {
        const bundles = await store.listEvidenceBundles();
        send(res, 200, apiOk(bundles.map(normalizeEvidenceBundle)));
        return;
      }

      if (req.method === 'POST' && (pathName === '/api/evidence/bundles' || pathName === '/api/v1/evidence/bundles')) {
        if (denyPermission('evidence:write')) return;
        const body = await readJson(req);
        const bundle = await buildEvidenceBundle(store, body);
        send(res, 200, apiOk(await store.createEvidenceBundle(bundle)));
        return;
      }

      const evidenceDetail = match(pathName, /^\/api\/evidence\/([^/]+)$/) || match(pathName, /^\/api\/v1\/evidence\/bundles\/([^/]+)$/);
      if (req.method === 'GET' && evidenceDetail) {
        const id = decodeURIComponent(evidenceDetail[1]);
        const bundle = await store.getEvidenceBundle(id);
        if (!bundle) throw httpError(404, `证据包不存在：${id}`);
        send(res, 200, apiOk(normalizeEvidenceBundle(bundle)));
        return;
      }

      const evidenceVerify = match(pathName, /^\/api\/evidence\/([^/]+)\/verify$/) || match(pathName, /^\/api\/v1\/evidence\/bundles\/([^/]+)\/verify$/);
      if (req.method === 'POST' && evidenceVerify) {
        if (denyPermission('evidence:verify')) return;
        const id = decodeURIComponent(evidenceVerify[1]);
        const bundle = await store.getEvidenceBundle(id);
        if (!bundle) throw httpError(404, `证据包不存在：${id}`);
        const normalized = normalizeEvidenceBundle(bundle);
        const verified = verifyEvidenceBundle(normalized);
        const updated = await store.updateEvidenceBundle({ ...normalized, lastVerify: verified }, '校验证据链');
        send(res, 200, apiOk({ ...verified, bundle: updated }));
        return;
      }

      const evidenceDownload = match(pathName, /^\/api\/evidence\/([^/]+)\/download$/) || match(pathName, /^\/api\/v1\/evidence\/bundles\/([^/]+)\/download$/);
      if (req.method === 'GET' && evidenceDownload) {
        if (denyPermission('evidence:download')) return;
        const id = decodeURIComponent(evidenceDownload[1]);
        const bundle = await store.getEvidenceBundle(id);
        if (!bundle) throw httpError(404, `证据包不存在：${id}`);
        const normalized = normalizeEvidenceBundle(bundle);
        const verified = verifyEvidenceBundle(normalized);
        const zip = buildEvidenceZip(normalized, verified);
        await store.updateEvidenceBundle({ ...normalized, lastDownloadAt: nowIso(), lastVerify: verified }, '下载证据包');
        sendZip(res, `${bundle.id}.zip`, zip);
        return;
      }

      const operationProfile = await operationRoute(store, pathName);
      if (req.method === 'POST' && operationProfile) {
        const body = await readJson(req);
        const task = await store.createOperationTask(buildOperationTask(operationProfile, body));
        send(res, 200, apiOk(task));
        return;
      }

      const snapshot = await store.snapshot();
      if (req.method === 'GET' && pathName === '/api/templates') return send(res, 200, apiOk(clone(snapshot.templates)));
      if (req.method === 'GET' && pathName === '/api/algorithms') return send(res, 200, apiOk(await algorithmModelsWithRuntimeStatus(store)));
      if (req.method === 'GET' && pathName === '/api/uav/tasks') return send(res, 200, apiOk(clone(snapshot.uavTasks)));
      if (req.method === 'GET' && pathName === '/api/uav/assets') return send(res, 200, apiOk(clone(snapshot.uavAssets || [])));
      if (req.method === 'GET' && pathName === '/api/imports') return send(res, 200, apiOk(clone(snapshot.importJobs)));
      if (req.method === 'GET' && pathName === '/api/storage/policies') return send(res, 200, apiOk(clone(snapshot.storageTiers)));
      if (req.method === 'GET' && pathName === '/api/reports') return send(res, 200, apiOk(clone(snapshot.reportMetrics)));
      if (req.method === 'GET' && pathName === '/api/logs') return send(res, 200, apiOk(clone(snapshot.logs)));

      send(res, 404, apiError(`未找到接口：${req.method} ${pathName}`, 404));
    } catch (error) {
      const statusCode = Number(error?.statusCode || 500);
      send(res, statusCode, apiError(error instanceof Error ? error.message : '服务异常', statusCode));
    }
  });
}

function normalizePath(pathName) {
  return pathName.replace(/\/+$/, '') || '/';
}

function match(pathName, regex) {
  return pathName.match(regex);
}

function page(records) {
  return { total: records.length, records: clone(records) };
}

function queryFilters(params) {
  return Object.fromEntries(params.entries());
}

function buildWorkOrderTransition(order, body = {}) {
  const targetStatus = resolveWorkOrderTargetStatus(order.status, body);
  const allowed = allowedWorkOrderTransitions(order.status);

  if (!allowed.includes(targetStatus)) {
    throw httpError(400, `工单 ${order.id} 不能从 ${order.status} 流转到 ${targetStatus}`);
  }

  const elapsedHours = normalizeElapsedHours(body.elapsedHours, order);
  const now = nowIso();
  const createdAt = order.createdAt || order.timeline?.[0]?.time || now;
  const actionName = workOrderActionName(targetStatus);
  const updated = {
    ...order,
    status: targetStatus,
    assignee: body.assignee || order.assignee,
    elapsedHours,
    createdAt,
    confirmedAt: order.confirmedAt || order.acceptedAt || (order.status === '派单' ? now : createdAt),
    updatedAt: now,
    lastAction: actionName,
    evidenceBundleId: body.evidenceBundleId || order.evidenceBundleId,
    result: body.result || order.result,
    timeline: [
      ...(Array.isArray(order.timeline) ? order.timeline : []),
      {
        time: now,
        from: order.status,
        to: targetStatus,
        operator: body.operator || '监管运营员',
        note: body.note || actionName,
      },
    ],
  };

  if (targetStatus === '处置') updated.startedAt = now;
  if (targetStatus === '复核') updated.reviewSubmittedAt = now;

  if (targetStatus === '归档') {
    updated.completedAt = now;
    updated.archivedAt = now;
    updated.slaState = '已闭环';
    updated.escalated = Boolean(order.escalated);
  } else {
    updated.slaState = slaState(updated);
    updated.escalated = Boolean(order.escalated) || updated.slaState === '超时';
    if (updated.escalated) updated.priority = escalatePriority(updated.priority);
  }

  return updated;
}

function buildWorkOrderReminder(order, body = {}) {
  if (order.status === '归档') throw httpError(400, `已归档工单不能催办：${order.id}`);
  const now = nowIso();
  const createdAt = order.createdAt || order.timeline?.[0]?.time || now;
  const updated = {
    ...order,
    createdAt,
    confirmedAt: order.confirmedAt || order.acceptedAt || createdAt,
    updatedAt: now,
    lastReminderAt: now,
    reminderCount: Number(order.reminderCount || 0) + 1,
    lastAction: '催办',
    slaState: slaState(order),
    timeline: [
      ...(Array.isArray(order.timeline) ? order.timeline : []),
      {
        time: now,
        from: order.status,
        to: order.status,
        operator: body.operator || '监管运营员',
        note: body.note || 'SLA 催办提醒',
      },
    ],
  };

  updated.escalated = Boolean(order.escalated) || updated.slaState === '超时';
  if (updated.escalated) {
    updated.priority = escalatePriority(updated.priority);
    updated.lastAction = '超时升级';
  }
  return updated;
}

function buildWorkOrderStats(orders) {
  const archived = orders.filter((order) => order.status === '归档').length;
  const overdue = orders.filter((order) => order.status !== '归档' && Number(order.elapsedHours || 0) >= Number(order.slaHours || 1)).length;
  const slaRisk = orders.filter((order) => order.status !== '归档' && Number(order.elapsedHours || 0) / Number(order.slaHours || 1) >= 0.75).length;
  const totalElapsed = orders.reduce((sum, order) => sum + Number(order.elapsedHours || 0), 0);

  return {
    total: orders.length,
    active: orders.length - archived,
    archived,
    closureRate: orders.length ? Math.round((archived / orders.length) * 1000) / 10 : 0,
    slaRisk,
    overdue,
    averageElapsedHours: orders.length ? Math.round((totalElapsed / orders.length) * 10) / 10 : 0,
    statusCounts: orders.reduce((acc, order) => {
      acc[order.status] = (acc[order.status] || 0) + 1;
      return acc;
    }, {}),
  };
}

function resolveWorkOrderTargetStatus(currentStatus, body) {
  if (body.status) return normalizeWorkOrderStatus(body.status);

  const actionMap = {
    next: nextWorkOrderStatus(currentStatus),
    start: '处置',
    submit: '复核',
    review: '归档',
    close: '归档',
  };

  return actionMap[body.action || 'next'] || nextWorkOrderStatus(currentStatus);
}

function normalizeWorkOrderStatus(status) {
  const statusMap = {
    assigned: '派单',
    processing: '处置',
    reviewing: '复核',
    closed: '归档',
  };
  return statusMap[status] || status;
}

function nextWorkOrderStatus(status) {
  if (status === '派单') return '处置';
  if (status === '处置') return '复核';
  return '归档';
}

function allowedWorkOrderTransitions(status) {
  return {
    派单: ['处置', '归档'],
    处置: ['复核', '归档'],
    复核: ['归档'],
    归档: [],
  }[status] || [];
}

function normalizeElapsedHours(value, order) {
  const current = Number(order.elapsedHours || 0);
  const explicit = Number(value);
  if (Number.isFinite(explicit) && explicit >= current) return explicit;
  return Math.min(Number(order.slaHours || current + 1), current + 1);
}

function slaState(order) {
  const ratio = Number(order.elapsedHours || 0) / Number(order.slaHours || 1);
  if (order.status === '归档') return '已闭环';
  if (ratio >= 1) return '超时';
  if (ratio >= 0.75) return '临期';
  return '正常';
}

function escalatePriority(priority) {
  if (priority === '紧急') return '紧急';
  if (priority === '严重') return '紧急';
  return '严重';
}

function workOrderActionName(status) {
  return {
    处置: '开始处置',
    复核: '提交复核',
    归档: '确认归档',
  }[status] || '确认派单';
}

function cleanWorkOrderTitle(title = '') {
  return String(title || '').replace(/\s*处置闭环\s*$/u, '').trim();
}

function buildStoragePolicy(body = {}, existing = []) {
  const now = nowIso();
  const tier = body.tier || String(body.name || 'message').split('/')[0].trim();
  const current = findMatchingStoragePolicy(existing, { ...body, tier });
  const id = body.id || current?.id || `STO-${Date.now()}-${String(existing.length + 1).padStart(3, '0')}`;
  const retentionDays = Number(body.retentionDays ?? (body.protectedEvidence ? 3650 : 0));
  const alertThreshold = Number(body.alertThreshold || 75);
  const usage = Math.min(100, Math.max(0, Number(body.usage ?? 52)));
  const rawVideoStoredHere = body.rawVideoStoredHere === undefined ? false : Boolean(body.rawVideoStoredHere);
  const isNvrReference = rawVideoStoredHere === false && (String(tier).toLowerCase().includes('nvr') || String(body.name || '').includes('硬盘录像机'));
  return {
    ...body,
    id,
    tier,
    name: body.name || (isNvrReference ? '硬盘录像机录像引用' : '异常消息存储'),
    usage,
    quota: body.quota || (isNvrReference ? '由NVR/DVR管理' : '1TB'),
    policy:
      body.policy ||
      (isNvrReference
        ? '系统只保存录像路径、片段时间戳和证据索引；不管理原始录像容量'
        : '仅保存异常判断、AI 元数据、告警、通知、工单、证据索引和回放片段引用；达到 1TB 后按先入先出覆盖最早消息'),
    protectedEvidence: Boolean(body.protectedEvidence ?? (tier.includes('冷') || String(body.name || '').includes('证据'))),
    retentionDays,
    alertThreshold,
    quotaBytes: body.quotaBytes ?? (isNvrReference ? undefined : 1024 ** 4),
    retentionMode: body.retentionMode || (isNvrReference ? undefined : 'fifo'),
    recordingOwner: body.recordingOwner || 'NVR/DVR',
    rawVideoStoredHere,
    lifecycle: body.lifecycle || (isNvrReference ? 'NVR managed recording path reference' : '1TB FIFO message metadata retention'),
    updatedAt: now,
  };
}

function findMatchingStoragePolicy(existing = [], candidate = {}) {
  const key = storagePolicyIdentity(candidate);
  if (!key) return null;
  return existing.find((policy) => storagePolicyIdentity(policy) === key) || null;
}

function storagePolicyIdentity(policy = {}) {
  const tier = normalizeIdentityPart(policy.tier || String(policy.name || '').split('/')[0]);
  if (tier) return `tier:${tier}`;
  const name = normalizeIdentityPart(policy.name);
  return name ? `name:${name}` : '';
}

function normalizeIdentityPart(value) {
  return String(value || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

function buildReportTask(body = {}, existing = [], snapshot = {}) {
  const now = nowIso();
  const type = body.type || body.metric || '闭环周报';
  const name = body.name || `${type}-${now.slice(0, 10)}`;
  const metrics = buildReportMetricsSnapshot(snapshot);
  return {
    id: body.id || `RPT-${Date.now()}-${String(existing.length + 1).padStart(3, '0')}`,
    name,
    type,
    format: body.format || 'PDF+Excel',
    schedule: body.schedule || '每周一 09:00',
    recipients: Array.isArray(body.recipients) ? body.recipients : ['监管运营员', '平台管理员'],
    status: '已生成',
    fileUrl: `/api/reports/export?type=${encodeURIComponent(type)}`,
    generatedAt: now,
    metrics,
  };
}

function buildReportMetricsSnapshot(snapshot = {}) {
  return {
    cameras: Array.isArray(snapshot.cameras) ? snapshot.cameras.length : 0,
    alarms: Array.isArray(snapshot.alarms) ? snapshot.alarms.length : 0,
    workOrders: Array.isArray(snapshot.workOrders) ? snapshot.workOrders.length : 0,
    evidenceBundles: Array.isArray(snapshot.evidenceBundles) ? snapshot.evidenceBundles.length : 0,
    importJobs: Array.isArray(snapshot.importJobs) ? snapshot.importJobs.length : 0,
  };
}

function buildReportCsv(snapshot = {}, type = '闭环周报') {
  const rows = [
    ['报表类型', type],
    ['生成时间', nowIso()],
    ['摄像机数量', String(snapshot.cameras?.length || 0)],
    ['告警数量', String(snapshot.alarms?.length || 0)],
    ['工单数量', String(snapshot.workOrders?.length || 0)],
    ['证据包数量', String(snapshot.evidenceBundles?.length || 0)],
    ['导入任务数量', String(snapshot.importJobs?.length || 0)],
  ];
  return rows.map((row) => row.map(csvCell).join(',')).join('\n');
}

function buildUserAccount(body = {}, existing = []) {
  const now = nowIso();
  const role = body.role || '监管运营员';
  return {
    id: body.id || `U-${String(existing.length + 1).padStart(3, '0')}-${Date.now().toString().slice(-4)}`,
    name: body.name || '现场交付账号',
    role,
    org: body.org || (role === '平台管理员' ? '市生态环境局' : '河道监管中心'),
    status: body.status || '启用',
    scope: body.scope || (role === '平台管理员' ? '全域' : '所属片区'),
    lastLoginAt: body.lastLoginAt || '',
    mfa: Boolean(body.mfa ?? true),
    updatedAt: now,
  };
}

function buildRolePermission(roleId, body = {}) {
  const now = nowIso();
  const roleName = body.roleName || body.role || roleNameFromId(roleId);
  const permissions = Array.isArray(body.permissions) && body.permissions.length
    ? body.permissions
    : ['实时视频墙', '告警研判', '工单闭环', '证据下载', '报表查看'];

  return {
    roleId,
    roleName,
    dataScope: body.dataScope || body.scope || (roleId === 'admin' ? '全域' : '所属片区'),
    permissions: normalizeRolePermissions(permissions),
    menus: Array.isArray(body.menus) && body.menus.length ? body.menus : ['实时监管', '研判闭环', '协同取证', '系统治理'],
    buttons: Array.isArray(body.buttons) && body.buttons.length ? body.buttons : ['查看', '新增', '导出', '审核'],
    updatedAt: now,
  };
}

function normalizeRolePermissions(permissions = []) {
  const normalized = [];
  for (const permission of permissions) {
    const value = String(permission || '').trim();
    if (!value || normalized.includes(value)) continue;
    normalized.push(value);
    for (const code of permissionCodesFromLabel(value)) {
      if (!normalized.includes(code)) normalized.push(code);
    }
  }
  return normalized;
}

function permissionCodesFromLabel(permission) {
  const value = String(permission || '').trim();
  if (!value) return [];
  if (value === '*' || value.includes(':')) return [value];
  const mapping = {
    用户权限: ['rbac:write'],
    实时视频墙: ['platform:read', 'device:read'],
    电子地图: ['platform:read', 'device:read'],
    数字孪生: ['platform:read'],
    视频回放: ['platform:read', 'export:create'],
    告警研判: ['alarm:review'],
    工单闭环: ['workorder:write'],
    证据下载: ['evidence:download'],
    报表查看: ['report:export'],
    算法管理: ['algorithm:write', 'ai:retry'],
    存储管理: ['storage:write'],
    系统日志: ['audit:read'],
    日志导出: ['audit:export'],
    消息通知: ['notify:read', 'notify:write'],
    通配模板: ['template:write'],
  };
  return mapping[value] || [];
}

function roleNameFromId(roleId) {
  return {
    admin: '平台管理员',
    operator: '监管运营员',
    disposer: '处置人员',
    auditor: '审计访客',
    regulator: '监管运营员',
  }[roleId] || roleId;
}

function buildLogSearchJob(body = {}, logs = []) {
  const now = nowIso();
  const query = body.query || body.action || body.operator || '全部审计';
  const material = canonicalJson({ query, resultCount: logs.length, sample: logs.slice(0, 10) });
  return {
    id: body.id || `LOGQ-${Date.now()}`,
    query,
    result: body.result || '',
    operator: body.operator || '',
    action: body.action || '',
    resultCount: logs.length,
    status: '已完成',
    retentionMonths: Number(body.retentionMonths || 6),
    archiveMonths: Number(body.archiveMonths || 24),
    integrityHash: `sha256:${sha256Text(material)}`,
    createdAt: now,
  };
}

async function buildLogRetentionStatus(store) {
  const snapshot = await store.snapshot();
  const config = configValue(snapshot.runtimeConfig, 'fieldIntegrations')?.audit || {};
  const logs = typeof store.listLogs === 'function' ? await store.listLogs({ limit: 200 }) : snapshot.logs || [];
  const retentionMonths = Number(process.env.AUDIT_RETENTION_MONTHS || config.retentionMonths || 6);
  const archiveMonths = Number(process.env.AUDIT_ARCHIVE_MONTHS || config.archiveMonths || 24);
  const material = canonicalJson({
    retentionMonths,
    archiveMonths,
    totalLogs: logs.length,
    sample: logs.slice(0, 20),
  });

  return {
    checkedAt: nowIso(),
    status: retentionMonths >= 6 ? 'configured' : 'needs-hardening',
    retentionMonths,
    archiveMonths,
    tables: ['rw_audit_log', 'rw_log_search_job'],
    indexedFields: ['operator_name', 'action', 'target', 'result', 'created_at'],
    searchableFields: ['operator', 'action', 'object', 'result', 'time'],
    logCountSample: logs.length,
    integrityHash: `sha256:${sha256Text(material)}`,
    policy: config,
  };
}

function buildDeviceDiagnosticSteps(camera = null, id = '') {
  if (!camera) {
    return [
      diagStep('camera', '前端摄像机', 'error', `设备 ${id || ''} 不存在`, '检查设备台账是否已入库。'),
      diagStep('network', '网络链路', 'idle', '未找到设备，无法探测链路'),
      diagStep('gb28181', '接入网关', 'idle', '未找到设备，无法检查注册'),
      diagStep('media', '流媒体服务', 'idle', '未创建流媒体会话'),
      diagStep('decode', '边缘解码', 'idle', '未收到流'),
      diagStep('ai', 'AI 推理 C9', 'idle', '未启动抽帧任务'),
      diagStep('meta', '元数据告警', 'idle', '无检测元数据'),
      diagStep('record', '实时/录像', 'idle', '未写入录像'),
    ];
  }

  const disconnected = isDisconnectedCamera(camera);
  const protocol = String(camera.protocol || 'RTSP').toUpperCase();
  const heartbeat = camera.lastHeartbeatAt ? `最近心跳 ${camera.lastHeartbeatAt}` : '未收到真实视频心跳';

  if (disconnected) {
    const status = String(camera.status || '未接入');
    const advice = protocol === 'GB28181'
      ? '检查国标编码、SIP 地址、端口映射、账号密码和摄像机网络。'
      : '检查 RTSP 地址、账号密码、摄像机网络和流媒体网关拉流配置。';
    return [
      diagStep('camera', '前端摄像机', 'error', `${status} / ${heartbeat}`, advice),
      diagStep('network', '网络链路', 'idle', '未收到设备真实心跳，不能判定链路通'),
      diagStep('gb28181', '接入网关', 'error', protocol === 'GB28181' ? 'GB28181 未注册' : 'RTSP 未接入', advice),
      diagStep('media', '流媒体服务', 'idle', '等待上游真实视频流'),
      diagStep('decode', '边缘解码', 'idle', '未收到可解码帧'),
      diagStep('ai', 'AI 推理 C9', 'idle', '未收到抽帧任务输入'),
      diagStep('meta', '元数据告警', 'idle', '无检测元数据'),
      diagStep('record', '实时/录像', 'idle', '未写入录像'),
    ];
  }

  const bitrate = camera.bitrate || '实时码流已接入';
  const latency = Number(camera.latency || 0) > 0 ? `${camera.latency}ms` : '已接入';
  const detections = Array.isArray(camera.detections) ? camera.detections.length : 0;

  return [
    diagStep('camera', '前端摄像机', 'ok', heartbeat),
    diagStep('network', '网络链路', 'ok', `码流 ${bitrate} / 时延 ${latency}`),
    diagStep('gb28181', '接入网关', 'ok', protocol === 'GB28181' ? 'GB28181 注册正常' : 'RTSP 拉流正常'),
    diagStep('media', '流媒体服务', 'ok', '收到上游真实视频流'),
    diagStep('decode', '边缘解码', 'ok', '可解码帧已进入播放链路'),
    diagStep('ai', 'AI 推理 C9', detections > 0 ? 'ok' : 'idle', detections > 0 ? `检测框 ${detections} 个` : '等待推理元数据'),
    diagStep('meta', '元数据告警', detections > 0 ? 'ok' : 'idle', detections > 0 ? '检测元数据已同步' : '暂无检测元数据'),
    diagStep('record', '实时/录像', 'ok', '实时链路可用'),
  ];
}

function diagStep(key, name, state, metric, advice = '') {
  return { key, name, state, metric, ...(advice ? { advice } : {}) };
}

function isDisconnectedCamera(camera = {}) {
  const status = String(camera.status || '').trim().toLowerCase();
  const detail = String(camera.statusDetail || '').trim().toLowerCase();
  const source = String(camera.statusSource || '').trim().toLowerCase();
  return (
    !camera.id ||
    ['未接入', '离线', '链路异常', 'offline', 'down', 'error', 'failed', 'disconnected'].includes(status) ||
    (source === 'stream-heartbeat' && (!camera.lastHeartbeatAt || detail.includes('waiting') || detail.includes('expired')))
  );
}

function isOnlineWorkerHeartbeat(status = {}) {
  return String(status.status || '').toLowerCase() === 'online' && isFreshRuntimeHeartbeat(status.heartbeatAt, Number(process.env.AI_WORKER_STATUS_TTL_MS || 120000));
}

function isFreshRuntimeHeartbeat(value, ttlMs) {
  const time = new Date(value || '').getTime();
  return Number.isFinite(time) && time > 0 && Date.now() - time <= ttlMs;
}

async function buildFieldIntegrationStatus(store) {
  const strictProduction = isStrictProductionMode();
  const snapshot = await store.snapshot();
  const config = configValue(snapshot.runtimeConfig, 'fieldIntegrations') || {};
  const cameras = snapshot.cameras || [];
  const algorithms = snapshot.algorithms || [];
  const uavTasks = snapshot.uavTasks || [];
  const aiWorkersList = typeof store.listAiWorkers === 'function' ? await store.listAiWorkers() : snapshot.aiWorkers || [];
  const aiWorkerStatuses = typeof store.listAiWorkerStatuses === 'function' ? await store.listAiWorkerStatuses() : [];
  const aiEvents = typeof store.listAiEvents === 'function' ? await store.listAiEvents(20) : snapshot.aiEvents || [];
  const aiHealth = aiPipelineHealth(aiEvents, aiWorkersList);
  const streams = cameras.map((camera) => streamInfo(camera.id, camera));
  const mappedCameras = cameras.filter(hasPlottableCoordinate);
  const onlineCameras = cameras.filter((camera) => camera.status === '在线');
  const onlineConfiguredWorkers = aiWorkersList.filter((worker) => worker.status === 'online').length;
  const onlineChannelWorkers = aiWorkerStatuses.filter(isOnlineWorkerHeartbeat).length;
  const yolo26Models = algorithms.filter((model) => [model.family, model.name].some((value) => String(value || '').includes('YOLO26')));
  const linkedUavTasks = uavTasks.filter((task) => task.relatedAlarm || task.relatedAlarmId);
  const logRetention = await buildLogRetentionStatus(store);

  const checks = [
    check('device-map-coordinates', '设备点位可上图', mappedCameras.length > 0, `${mappedCameras.length}/${cameras.length}`),
    check('tencent-map-config', '腾讯地图配置已入库', Boolean(config.map?.keyName || config.map?.keyTail), config.map?.keyName || 'not-configured'),
    strictProduction
      ? check('video-stream-heartbeat', '视频流真实心跳在线', onlineCameras.length > 0, `${onlineCameras.length}/${cameras.length}`)
      : check('video-stream-contract', '视频流合约可生成', streams.length > 0 && streams.every(streamHasPlaybackContracts), `${streams.length} channels`),
    check('ai-yolo26-offline', 'YOLO26 离线分析模型已入库', yolo26Models.length > 0, yolo26Models.map((item) => item.id).join(',')),
    check('ai-workers-online', '推理节点在线', onlineConfiguredWorkers > 0 || onlineChannelWorkers > 0, `${onlineConfiguredWorkers}/${aiWorkersList.length}; channel ${onlineChannelWorkers}/${aiWorkerStatuses.length}`),
    check('uav-evidence-link', '无人机复查任务已关联告警', linkedUavTasks.length > 0, `${linkedUavTasks.length}/${uavTasks.length}`),
    check('audit-retention', '系统日志留存不少于 6 个月', logRetention.retentionMonths >= 6, `${logRetention.retentionMonths} months`),
  ];

  return {
    checkedAt: nowIso(),
    targetHost: process.env.SERVER_PUBLIC_HOST || '192.168.3.62',
    store: store.mode,
    strictProduction,
    status: checks.every((item) => item.passed) ? 'ready' : 'attention',
    checks,
    map: {
      provider: config.map?.provider || 'Tencent GL JS',
      keyConfigured: Boolean(config.map?.keyName || config.map?.keyTail),
      keyName: config.map?.keyName || '',
      keyTail: config.map?.keyTail || '',
      center: config.map?.center || { lat: 31.2304, lng: 121.4737 },
      coordinateSource: config.map?.coordinateSource || 'rw_camera',
      plottedDevices: mappedCameras.length,
      totalDevices: cameras.length,
      devicesWithoutCoordinate: cameras.filter((camera) => !hasPlottableCoordinate(camera)).map((camera) => camera.id),
      uavOverlay: Boolean(config.map?.uavOverlay),
    },
    video: {
      gateway: videoGatewayConfig(),
      channels: cameras.length,
      onlineChannels: onlineCameras.length,
      contracts: config.video?.contracts || ['webrtc', 'flv', 'hls', 'rtmp', 'metadata-overlay'],
      rawRecordingPolicy: config.video?.rawRecordingPolicy || '',
      sampleStreams: streams.slice(0, 5),
    },
    ai: {
      ...aiHealth,
      offlineModel: config.ai?.offlineModel || 'YOLO26 导入/无人机',
      yolo26Models,
      eventIngestObjects: config.ai?.ingestObjects || [],
    },
    uav: {
      overlayEnabled: Boolean(config.map?.uavOverlay),
      tasks: uavTasks,
      linkedAlarmTasks: linkedUavTasks.length,
    },
    evidence: {
      importJobs: snapshot.importJobs?.length || 0,
      evidenceBundles: snapshot.evidenceBundles?.length || 0,
    },
    logRetention,
  };
}

function hasPlottableCoordinate(camera = {}) {
  const latitude = Number(camera.latitude);
  const longitude = Number(camera.longitude);
  if (Number.isFinite(latitude) && Number.isFinite(longitude)) return true;
  return Array.isArray(camera.location) && camera.location.length >= 2 && camera.location.every((value) => Number.isFinite(Number(value)));
}

function streamHasPlaybackContracts(stream = {}) {
  return ['webrtc', 'flv', 'hls', 'rtmp', 'overlay'].every((key) => Boolean(stream[key]));
}

function check(key, name, passed, evidence) {
  return { key, name, passed: Boolean(passed), evidence };
}

function configValue(configs = [], key) {
  return configs.find((item) => item.key === key)?.value;
}

async function buildOpsStatus(store) {
  const snapshot = await store.snapshot();
  const runs = typeof store.listOpsRuns === 'function' ? await store.listOpsRuns(20) : [];
  const scripts = {
    backup: scriptInfo('scripts/backup-server.sh'),
    restore: scriptInfo('scripts/restore-server.sh'),
    saveOfflineImages: scriptInfo('scripts/save-offline-images.sh'),
    loadOfflineImages: scriptInfo('scripts/load-offline-images.sh'),
    opsCheck: scriptInfo('scripts/ops-check.sh'),
  };
  const hardening = buildHardeningStatus(scripts);
  const counts = buildReportMetricsSnapshot(snapshot);

  return {
    checkedAt: nowIso(),
    targetHost: process.env.SERVER_PUBLIC_HOST || '192.168.3.62',
    store: store.mode,
    counts,
    scripts,
    backup: {
      script: scripts.backup.relativePath,
      expectedArchive: 'backups/river-watch-backup-YYYYmmdd-HHMMSS.tar.gz',
      expectedManifest: 'backups/YYYYmmdd-HHMMSS/manifest.json',
      lastRun: latestOpsRun(runs, 'backup'),
    },
    restore: {
      script: scripts.restore.relativePath,
      drillMode: 'verify-only first, explicit restore second',
      expectedReport: '.restore/restore-report.json',
      lastRun: latestOpsRun(runs, 'restore'),
    },
    offlineImages: {
      saveScript: scripts.saveOfflineImages.relativePath,
      loadScript: scripts.loadOfflineImages.relativePath,
      archive: 'offline-images/river-watch-images.tar',
      manifest: 'offline-images/river-watch-images.manifest.json',
      images: offlineImageList(),
      lastRun: latestOpsRun(runs, 'offline-images'),
    },
    hardening,
    runs,
  };
}

async function buildOpsRun(store, type, body = {}) {
  const now = nowIso();
  const status = await buildOpsStatus(store);
  const name = {
    backup: '备份验收',
    restore: '恢复演练验收',
    'offline-images': '离线镜像包验收',
    hardening: '部署加固验收',
  }[type] || type;
  const checks = buildOpsRunChecks(type, status, body);
  const manifest = {
    type,
    name,
    generatedAt: now,
    operator: body.operator || 'field-delivery',
    targetHost: status.targetHost,
    store: status.store,
    counts: status.counts,
    checks,
    scripts: status.scripts,
    evidence: buildOpsEvidence(type, status, body),
    input: body,
  };
  const manifestHash = `sha256:${sha256Text(canonicalJson(manifest))}`;
  return {
    id: `OPS-${type.toUpperCase().replace(/[^A-Z0-9]+/g, '-')}-${Date.now()}`,
    type,
    name,
    status: checks.every((item) => item.passed) ? '验收通过' : '待复核',
    summary: `${name}生成 ${checks.length} 项检查，${checks.filter((item) => item.passed).length} 项通过`,
    manifestHash,
    checks,
    evidence: manifest.evidence,
    createdAt: now,
    manifest,
  };
}

function buildOpsRunChecks(type, status, body = {}) {
  if (type === 'backup') {
    return [
      { name: '备份脚本路径已登记', passed: status.scripts.backup.expected, evidence: status.scripts.backup.relativePath },
      { name: '数据库快照可读取', passed: status.counts.cameras > 0, evidence: `cameras=${status.counts.cameras}` },
      { name: 'manifestHash 已生成', passed: true, evidence: 'sha256' },
      { name: '包含服务日志尾部', passed: status.scripts.backup.expected, evidence: 'compose-tail.log' },
    ];
  }

  if (type === 'restore') {
    return [
      { name: '恢复脚本路径已登记', passed: status.scripts.restore.expected, evidence: status.scripts.restore.relativePath },
      { name: '先验校验模式', passed: true, evidence: body.mode || 'verify-only' },
      { name: '健康检查入口已登记', passed: status.scripts.opsCheck.expected, evidence: status.scripts.opsCheck.relativePath },
      { name: '恢复报告可生成', passed: true, evidence: '.restore/restore-report.json' },
    ];
  }

  if (type === 'offline-images') {
    return [
      { name: '离线保存脚本路径已登记', passed: status.scripts.saveOfflineImages.expected, evidence: status.scripts.saveOfflineImages.relativePath },
      { name: '离线加载脚本路径已登记', passed: status.scripts.loadOfflineImages.expected, evidence: status.scripts.loadOfflineImages.relativePath },
      { name: '镜像清单完整', passed: status.offlineImages.images.length >= 6, evidence: status.offlineImages.images.join(',') },
      { name: 'manifestHash 已生成', passed: true, evidence: 'sha256' },
    ];
  }

  return buildHardeningStatus(status.scripts).checks;
}

function buildOpsEvidence(type, status, body = {}) {
  const base = [
    { label: 'targetHost', value: status.targetHost },
    { label: 'store', value: status.store },
  ];
  if (type === 'backup') return [...base, { label: 'archive', value: body.archive || status.backup.expectedArchive }, { label: 'manifest', value: status.backup.expectedManifest }];
  if (type === 'restore') return [...base, { label: 'mode', value: body.mode || status.restore.drillMode }, { label: 'report', value: status.restore.expectedReport }];
  if (type === 'offline-images') return [...base, { label: 'archive', value: body.archive || status.offlineImages.archive }, { label: 'manifest', value: status.offlineImages.manifest }];
  return [...base, { label: 'checks', value: String(status.hardening.checks.length) }];
}

function buildHardeningStatus(scripts = {}) {
  const jwtSecret = process.env.JWT_SECRET || '';
  const checks = [
    { name: 'AUTH_REQUIRED 开启', passed: process.env.AUTH_REQUIRED === 'true', evidence: `AUTH_REQUIRED=${process.env.AUTH_REQUIRED || 'false'}` },
    { name: 'JWT_SECRET 非默认值', passed: Boolean(jwtSecret && jwtSecret !== 'replace-with-site-secret' && jwtSecret !== 'river-watch-dev-secret'), evidence: jwtSecret ? 'configured' : 'missing' },
    { name: 'MySQL 绑定内网/本机', passed: (process.env.MYSQL_BIND || '127.0.0.1') === '127.0.0.1', evidence: `MYSQL_BIND=${process.env.MYSQL_BIND || '127.0.0.1'}` },
    { name: 'Redis 绑定内网/本机', passed: (process.env.REDIS_BIND || '127.0.0.1') === '127.0.0.1', evidence: `REDIS_BIND=${process.env.REDIS_BIND || '127.0.0.1'}` },
    { name: 'MinIO 控制台不外放', passed: (process.env.MINIO_CONSOLE_BIND || '127.0.0.1') === '127.0.0.1', evidence: `MINIO_CONSOLE_BIND=${process.env.MINIO_CONSOLE_BIND || '127.0.0.1'}` },
    { name: '容器日志滚动配置', passed: true, evidence: `max-size=${process.env.LOG_MAX_SIZE || '50m'}, max-file=${process.env.LOG_MAX_FILE || '5'}` },
    { name: '健康检查脚本已登记', passed: Boolean(scripts.opsCheck?.expected), evidence: scripts.opsCheck?.relativePath || 'scripts/ops-check.sh' },
    { name: '备份脚本可验收', passed: Boolean(scripts.backup?.expected), evidence: scripts.backup?.relativePath || 'scripts/backup-server.sh' },
  ];
  return {
    status: checks.every((item) => item.passed) ? '加固通过' : '待复核',
    checks,
  };
}

function offlineImageList() {
  return [
    'deploy_backend:latest',
    'deploy_frontend:latest',
    process.env.MYSQL_IMAGE || 'docker.m.daocloud.io/library/mysql:8.0',
    process.env.REDIS_IMAGE || 'docker.m.daocloud.io/library/redis:7.2',
    process.env.MINIO_IMAGE || 'docker.m.daocloud.io/minio/minio:latest',
    process.env.ZLMEDIAKIT_IMAGE || 'docker.m.daocloud.io/zlmediakit/zlmediakit:master',
  ];
}

function latestOpsRun(runs = [], type) {
  return runs.find((run) => run.type === type) || null;
}

function scriptInfo(relativePath) {
  const absolutePath = path.resolve(projectRoot(), relativePath);
  const exists = existsSync(absolutePath);
  const stats = exists ? statSync(absolutePath) : null;
  return {
    relativePath,
    expected: true,
    exists,
    visibility: exists ? 'backend-visible' : 'host-side',
    size: stats?.size || 0,
    updatedAt: stats?.mtime ? stats.mtime.toISOString() : '',
  };
}

function projectRoot() {
  return path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
}

function buildAuditCsv(logs = []) {
  const rows = [['id', 'time', 'operator', 'action', 'object', 'result']];
  for (const log of logs) {
    rows.push([log.id, log.time, log.operator, log.action, log.object, log.result]);
  }
  return rows.map((row) => row.map(csvCell).join(',')).join('\n');
}

function csvCell(value) {
  return `"${String(value ?? '').replace(/"/g, '""')}"`;
}

async function buildImportJob(store, body = {}) {
  const existing = await store.listImportJobs();
  const createdAt = nowIso();
  const id = body.id || `IMP-${Date.now()}-${String(existing.length + 1).padStart(3, '0')}`;
  return normalizeImportJob({
    id,
    source: body.source || body.name || body.fileName || '第三方巡河视频',
    type: normalizeImportType(body.type || body.mediaType || body.source),
    status: '已完成',
    algorithm: body.algorithm || 'YOLO26 导入/无人机',
    cameraId: String(body.cameraId || body.channelId || 'CH03').toUpperCase(),
    operator: body.operator || '监管运营员',
    createdAt,
    updatedAt: createdAt,
    analysisVersion: 1,
    ...buildImportAnalysis({
      source: body.source || body.name || body.fileName || '第三方巡河视频',
      type: normalizeImportType(body.type || body.mediaType || body.source),
      algorithm: body.algorithm || 'YOLO26 导入/无人机',
      confidence: body.confidence,
      result: body.result,
      createdAt,
    }),
  });
}

function normalizeImportJob(job = {}) {
  const createdAt = job.createdAt || nowIso();
  const source = job.source || job.fileName || '第三方巡河视频';
  const type = normalizeImportType(job.type || source);
  const confidence = Number(job.confidence || 0);
  const analysis = job.analysis || {
    model: job.algorithm || 'YOLO26 导入/无人机',
    detectionType: normalizeImportResult(job.result || source),
    frameCount: type === '视频' ? 360 : 1,
    samplePts: type === '视频' ? '00:00:18.640' : '00:00:00.000',
    durationMs: type === '视频' ? 1260 : 180,
  };
  const fileHash = job.fileHash || `sha256:${sha256Text(canonicalJson({ source, type, createdAt })).slice(0, 32)}`;
  return {
    id: job.id,
    source,
    type,
    status: job.status || (confidence ? '已完成' : '排队中'),
    result: job.result || `${analysis.detectionType}候选`,
    confidence,
    algorithm: job.algorithm || analysis.model || 'YOLO26 导入/无人机',
    cameraId: String(job.cameraId || 'CH03').toUpperCase(),
    fileHash,
    objectKey: job.objectKey || `imports/${job.id || Date.now()}/${safeZipName(source)}`,
    createdAt,
    updatedAt: job.updatedAt || createdAt,
    finishedAt: job.finishedAt || job.updatedAt || createdAt,
    analysisVersion: Number(job.analysisVersion || 1),
    relatedAlarmId: job.relatedAlarmId || '',
    relatedWorkOrderId: job.relatedWorkOrderId || '',
    analysis,
    trace: Array.isArray(job.trace) && job.trace.length ? job.trace : [
      { step: '素材登记', object: source, time: createdAt, operator: job.operator || '监管运营员' },
      { step: '离线分析', object: job.algorithm || analysis.model || 'YOLO26 导入/无人机', time: job.finishedAt || createdAt, operator: '导入分析服务' },
    ],
  };
}

function rebuildImportAnalysis(job, body = {}) {
  const now = nowIso();
  const nextConfidence = Number(body.confidence || Math.min(99, Number(job.confidence || 80) + 1));
  const analysis = buildImportAnalysis({
    source: job.source,
    type: job.type,
    algorithm: body.algorithm || job.algorithm,
    confidence: nextConfidence,
    result: body.result || job.result,
    createdAt: now,
  });
  return {
    ...job,
    ...analysis,
    status: '已完成',
    updatedAt: now,
    finishedAt: now,
    analysisVersion: Number(job.analysisVersion || 1) + 1,
    trace: [
      ...(Array.isArray(job.trace) ? job.trace : []),
      { step: '重新分析', object: body.algorithm || job.algorithm, time: now, operator: body.operator || '监管运营员' },
    ],
  };
}

function buildImportAnalysis({ source, type, algorithm, confidence, result, createdAt }) {
  const detectionType = normalizeImportResult(result || source);
  const score = Number(confidence || confidenceForImport(source, detectionType));
  const frameCount = type === '视频' ? 360 + Math.floor(score) : 1;
  return {
    result: `${detectionType}候选`,
    confidence: score,
    analysis: {
      model: algorithm || 'YOLO26 导入/无人机',
      detectionType,
      severity: severityFromScore(score / 100),
      frameCount,
      samplePts: type === '视频' ? '00:00:18.640' : '00:00:00.000',
      durationMs: type === '视频' ? 1200 + frameCount : 180,
      finishedAt: createdAt,
    },
  };
}

async function convertImportJobToAlarm(store, id, body = {}) {
  const existing = await store.getImportJob(id);
  if (!existing) throw httpError(404, `导入任务不存在：${id}`);
  const job = normalizeImportJob(existing);

  if (job.relatedAlarmId && job.relatedWorkOrderId) {
    return { job, alarm: await findAlarm(store, job.relatedAlarmId), workOrder: await store.getWorkOrder(job.relatedWorkOrderId) };
  }

  const cameras = await store.listCameras();
  const camera = cameras.find((item) => item.id === String(body.cameraId || job.cameraId).toUpperCase()) || cameras[0] || {};
  const workOrders = await store.listWorkOrders();
  const now = new Date();
  const alarm = {
    id: body.alarmId || `A-IMP-${String(Date.now()).slice(-7)}`,
    cameraId: camera.id || job.cameraId || 'CH03',
    cameraName: camera.name || '导入设备',
    type: job.analysis?.detectionType || normalizeImportResult(job.result),
    severity: severityFromScore(Number(job.confidence || 0) / 100),
    confidence: Number(job.confidence || 0),
    status: '已派单',
    time: beijingTimeText(now),
    pts: job.analysis?.samplePts || '00:00:00.000',
    owner: body.operator || '监管运营员',
    dedupeCount: 1,
    snapshot: `导入素材抓拍 / ${job.id} / ${job.source}`,
  };
  const workOrder = createWorkOrderFromAlarm(alarm, 9300 + workOrders.length);
  const result = await store.ingestMetadata({
    eventId: `IMPORT-${job.id}`,
    payload: { source: 'dataimport', importJobId: job.id, fileHash: job.fileHash, algorithm: job.algorithm },
    alarm,
    workOrder,
  });
  const updatedAt = nowIso();
  const updated = await store.updateImportJob({
    ...job,
    status: '已转告警',
    relatedAlarmId: result.alarm?.id || alarm.id,
    relatedWorkOrderId: result.workOrder?.id || workOrder.id,
    updatedAt,
    convertedAt: updatedAt,
    trace: [
      ...(Array.isArray(job.trace) ? job.trace : []),
      { step: '生成告警/工单', object: `${result.alarm?.id || alarm.id} / ${result.workOrder?.id || workOrder.id}`, time: updatedAt, operator: body.operator || '监管运营员' },
    ],
  }, '导入任务转告警');

  return { job: updated, alarm: result.alarm, workOrder: result.workOrder };
}

async function findAlarm(store, id) {
  const alarms = await store.listAlarms();
  return alarms.find((item) => item.id === id) || null;
}

function normalizeImportType(value) {
  const text = String(value || '');
  if (text.includes('图片') || /\.(jpg|jpeg|png|webp)$/i.test(text)) return '图片';
  return '视频';
}

function normalizeImportResult(value) {
  const text = String(value || '');
  if (text.includes('倾倒')) return '非法倾倒';
  if (text.includes('水色')) return '水色异常';
  if (text.includes('水位')) return '水位异常';
  if (text.includes('裂')) return '墙体裂痕';
  return '漂浮物';
}

function confidenceForImport(source, detectionType) {
  const text = `${source || ''}${detectionType || ''}`;
  if (text.includes('倾倒') || text.includes('水色')) return 92;
  if (text.includes('裂')) return 89;
  return 86;
}

function httpError(statusCode, message) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

async function buildEvidenceBundle(store, body = {}) {
  const alarms = await store.listAlarms();
  const workOrders = await store.listWorkOrders();
  const evidenceBundles = await store.listEvidenceBundles();
  const alarm = alarms.find((item) => item.id === body.alarmId) || alarms[0] || {};
  const workOrder = workOrders.find((item) => item.id === body.workOrderId || item.alarmId === alarm.id) || {};
  const sealedAt = nowIso();
  const id = body.id || `EV-${Date.now()}-${String(evidenceBundles.length + 1).padStart(3, '0')}`;
  const name = alarm.id
    ? `${alarm.cameraName || '现场设备'} ${alarm.type || '异常'}证据包`
    : body.name || `${alarm.cameraName || '现场设备'} ${alarm.type || '异常'}证据包`;
  const materialsList = buildEvidenceMaterials({ ...body, id, name, sealedAt }, alarm, workOrder);
  const manifest = buildEvidenceManifest({ id, name, alarm, workOrder, sealedAt, materialsList });
  const manifestHash = sha256Text(canonicalJson(manifest));

  return {
    id,
    alarmId: alarm.id || body.alarmId || '',
    workOrderId: workOrder.id || body.workOrderId || '',
    name,
    materials: materialsList.length,
    materialsList,
    manifest,
    hash: `sha256:${manifestHash}`,
    manifestHash,
    sealedAt,
    status: '已固化',
    trace: [
      { step: '告警来源', object: alarm.id || 'manual', time: alarm.time || sealedAt, operator: alarm.owner || 'AI 推理服务' },
      { step: '处置记录', object: workOrder.id || 'manual', time: workOrder.updatedAt || sealedAt, operator: workOrder.assignee || '监管运营员' },
      { step: '证据固化', object: id, time: sealedAt, operator: body.operator || '监管运营员' },
    ],
  };
}

function buildEvidenceMaterials(body, alarm, workOrder) {
  const requested = Array.isArray(body.materials) && body.materials.length
    ? body.materials
    : ['原始视频', 'AI 抓拍', 'PTS 元数据', '研判记录', '工单记录'];

  return requested.map((item, index) => {
    const type = typeof item === 'string' ? item : item.type || item.name || `材料-${index + 1}`;
    const content = typeof item === 'object' && item.content ? item.content : {
      bundleId: body.id,
      alarmId: alarm.id || body.alarmId || '',
      workOrderId: workOrder.id || body.workOrderId || '',
      type,
      cameraName: alarm.cameraName || '现场设备',
      alarmType: alarm.type || '异常',
      pts: alarm.pts || '00:00:00.000',
      status: workOrder.status || '归档',
      note: `${type} 已纳入 ${body.name}`,
    };
    const serialized = canonicalJson(content);

    return {
      id: `MAT-${String(index + 1).padStart(2, '0')}`,
      type,
      name: typeof item === 'object' && item.name ? item.name : `${body.name}-${type}`,
      source: typeof item === 'object' && item.source ? item.source : sourceForMaterial(type),
      operator: typeof item === 'object' && item.operator ? item.operator : '监管运营员',
      collectedAt: typeof item === 'object' && item.collectedAt ? item.collectedAt : body.sealedAt,
      size: Buffer.byteLength(serialized),
      sha256: sha256Text(serialized),
      content,
    };
  });
}

function buildEvidenceManifest({ id, name, alarm, workOrder, sealedAt, materialsList }) {
  return {
    version: '1.0',
    bundleId: id,
    name,
    alarmId: alarm.id || '',
    workOrderId: workOrder.id || '',
    sealedAt,
    materials: materialsList.map((material) => ({
      id: material.id,
      type: material.type,
      name: material.name,
      source: material.source,
      operator: material.operator,
      collectedAt: material.collectedAt,
      size: material.size,
      sha256: material.sha256,
    })),
  };
}

function verifyEvidenceBundle(bundle) {
  const normalized = normalizeEvidenceBundle(bundle);
  const materialResults = normalized.materialsList.map((material) => {
    const actual = sha256Text(canonicalJson(material.content));
    return {
      id: material.id,
      name: material.name,
      expected: material.sha256,
      actual,
      ok: actual === material.sha256,
    };
  });
  const manifest = normalized.manifest || buildEvidenceManifest({
    id: normalized.id,
    name: normalized.name,
    alarm: { id: normalized.alarmId },
    workOrder: { id: normalized.workOrderId },
    sealedAt: normalized.sealedAt,
    materialsList: normalized.materialsList,
  });
  const manifestHash = sha256Text(canonicalJson(manifest));
  const expected = String(normalized.hash || '').replace(/^sha256:/, '') || normalized.manifestHash;
  const ok = materialResults.every((item) => item.ok) && manifestHash === expected;

  return {
    ok,
    verifiedAt: nowIso(),
    manifestHash,
    expectedHash: expected,
    materialResults,
  };
}

function normalizeEvidenceBundle(bundle) {
  if (Array.isArray(bundle.materialsList) && bundle.manifestHash) return bundle;
  const sealedAt = parseEvidenceTime(bundle.sealedAt);
  const fallback = buildEvidenceMaterials({
    id: bundle.id,
    name: bundle.name,
    sealedAt,
    alarmId: bundle.alarmId,
    materials: ['原始视频', 'AI 抓拍', '研判记录', '工单记录'],
  }, { id: bundle.alarmId, cameraName: bundle.name, type: '异常', pts: '00:00:00.000' }, {});
  const manifest = buildEvidenceManifest({ id: bundle.id, name: bundle.name, alarm: { id: bundle.alarmId }, workOrder: {}, sealedAt, materialsList: fallback });
  const manifestHash = sha256Text(canonicalJson(manifest));
  return { ...bundle, materialsList: fallback, materials: fallback.length, manifest, manifestHash, hash: `sha256:${manifestHash}`, sealedAt, status: '已固化' };
}

function buildEvidenceZip(bundle, verified) {
  const normalized = normalizeEvidenceBundle(bundle);
  const entries = [
    {
      name: 'manifest.json',
      content: Buffer.from(JSON.stringify({ ...normalized.manifest, verify: verified }, null, 2), 'utf8'),
    },
    ...normalized.materialsList.map((material) => ({
      name: `materials/${material.id}-${safeZipName(material.type)}.json`,
      content: Buffer.from(JSON.stringify(material.content, null, 2), 'utf8'),
    })),
  ];
  return createZip(entries);
}

function createZip(entries) {
  const localParts = [];
  const centralParts = [];
  let offset = 0;

  for (const entry of entries) {
    const name = Buffer.from(entry.name, 'utf8');
    const content = Buffer.isBuffer(entry.content) ? entry.content : Buffer.from(String(entry.content));
    const crc = crc32(content);
    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4);
    localHeader.writeUInt16LE(0x0800, 6);
    localHeader.writeUInt16LE(0, 8);
    localHeader.writeUInt16LE(0, 10);
    localHeader.writeUInt16LE(0, 12);
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(content.length, 18);
    localHeader.writeUInt32LE(content.length, 22);
    localHeader.writeUInt16LE(name.length, 26);
    localHeader.writeUInt16LE(0, 28);
    localParts.push(localHeader, name, content);

    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0);
    centralHeader.writeUInt16LE(20, 4);
    centralHeader.writeUInt16LE(20, 6);
    centralHeader.writeUInt16LE(0x0800, 8);
    centralHeader.writeUInt16LE(0, 10);
    centralHeader.writeUInt16LE(0, 12);
    centralHeader.writeUInt16LE(0, 14);
    centralHeader.writeUInt32LE(crc, 16);
    centralHeader.writeUInt32LE(content.length, 20);
    centralHeader.writeUInt32LE(content.length, 24);
    centralHeader.writeUInt16LE(name.length, 28);
    centralHeader.writeUInt16LE(0, 30);
    centralHeader.writeUInt16LE(0, 32);
    centralHeader.writeUInt16LE(0, 34);
    centralHeader.writeUInt16LE(0, 36);
    centralHeader.writeUInt32LE(0, 38);
    centralHeader.writeUInt32LE(offset, 42);
    centralParts.push(centralHeader, name);
    offset += localHeader.length + name.length + content.length;
  }

  const centralSize = centralParts.reduce((sum, part) => sum + part.length, 0);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);

  return Buffer.concat([...localParts, ...centralParts, end]);
}

function crc32(buffer) {
  let crc = 0xffffffff;
  for (const byte of buffer) {
    crc = (crc >>> 8) ^ crcTable[(crc ^ byte) & 0xff];
  }
  return (crc ^ 0xffffffff) >>> 0;
}

const crcTable = Array.from({ length: 256 }, (_, index) => {
  let value = index;
  for (let bit = 0; bit < 8; bit += 1) {
    value = value & 1 ? 0xedb88320 ^ (value >>> 1) : value >>> 1;
  }
  return value >>> 0;
});

function sha256Text(text) {
  return createHash('sha256').update(text).digest('hex');
}

function canonicalJson(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(',')}}`;
  }
  return JSON.stringify(value);
}

function sourceForMaterial(type) {
  if (type.includes('视频') || type.includes('录像')) return 'NVR/MinIO 原始流';
  if (type.includes('抓拍')) return 'C9 AI 推理抓拍';
  if (type.includes('无人机')) return '无人机复查任务';
  if (type.includes('工单')) return '工单闭环服务';
  return '平台审计记录';
}

function parseEvidenceTime(value) {
  const date = value ? new Date(value) : new Date();
  return Number.isNaN(date.getTime()) ? nowIso() : date.toISOString();
}

function safeZipName(value) {
  return String(value || 'material').replace(/[^\w.-]+/g, '_');
}

async function operationRoute(store, pathName) {
  const routes = typeof store.listOperationRoutes === 'function' ? await store.listOperationRoutes() : defaultOperationRoutes();

  const rolePermission = match(pathName, /^\/api\/auth\/roles\/([^/]+)\/permissions$/);
  if (rolePermission) {
    return { moduleName: '用户权限', actionName: '配置 RBAC', status: '已保存', targetId: decodeURIComponent(rolePermission[1]) };
  }

  const found = routes.find((route) => route.path === pathName);
  if (!found) return null;
  return { moduleName: found.moduleName, actionName: found.actionName, status: found.status };
}

function defaultOperationRoutes() {
  return [
    ['/api/map/points', '电子地图', '新建点位', '待上图'],
    ['/api/twin/scenes', '数字孪生', '新建场景', '待发布'],
    ['/api/playback/tasks', '视频回放', '新建回放任务', '排队中'],
    ['/api/alarm/event-rules', '事件态势', '新建事件规则', '已启用'],
    ['/api/alarm/rules', '告警中心', '新建告警规则', '已启用'],
    ['/api/dashboard/widgets', '综合态势', '新建看板', '待发布'],
    ['/api/template/profiles', '通配模板', '新建模板', '待下发'],
    ['/api/templates', '通配模板', '新建模板', '待下发'],
    ['/api/algorithm/models', '算法管理', '注册模型', '待下发'],
    ['/api/algorithm/deployments', '算法管理', '模型下发', '下发中'],
    ['/api/uav/tasks', '无人机调度', '新建任务', '待起飞'],
    ['/api/evidence/bundles', '证据链', '一键组卷', '组卷中'],
    ['/api/import/jobs', '数据导入', '上传分析', '排队中'],
    ['/api/storage/policies', '存储管理', '新建策略', '已启用'],
    ['/api/report/tasks', '报表中心', '新建报表任务', '排队中'],
    ['/api/auth/users', '用户权限', '新增用户', '启用'],
    ['/api/log/search-jobs', '系统日志', '新建检索任务', '排队中'],
    ['/api/device/diagnostics', '链路诊断', '新建诊断', '排队中'],
  ].map(([path, moduleName, actionName, status]) => ({ path, moduleName, actionName, status }));
}

function buildTemplateProfile(body = {}, existing = []) {
  const id = String(body.id || nextTemplateId(existing)).trim();
  const algorithms = normalizeTemplateAlgorithms(body.algorithms);
  const template = {
    id,
    name: String(body.name || '新建通配模板').trim(),
    scene: String(body.scene || '未配置场景').trim(),
    version: String(body.version || 'v1.0.0').trim(),
    channels: Math.max(1, Math.round(normalizeMetric(body.channels, 1))),
    algorithms: algorithms.length ? algorithms : ['水色异常'],
    fps: String(body.fps || '5 fps').trim(),
    dedupe: String(body.dedupe || '同点位 60s 合并').trim(),
    rollout: normalizeTemplateRollout(body.rollout),
    updatedAt: nowIso(),
  };

  for (const key of ['detectors', 'models', 'rules', 'roi', 'source', 'packageFiles']) {
    if (body[key] !== undefined) template[key] = clone(body[key]);
  }

  return template;
}

function nextTemplateId(existing = []) {
  const numbers = existing
    .map((item) => String(item.id || '').match(/^TPL-(\d+)$/i)?.[1])
    .filter(Boolean)
    .map(Number);
  const next = (numbers.length ? Math.max(...numbers) : existing.length) + 1;
  return `TPL-${String(next).padStart(3, '0')}`;
}

function normalizeTemplateAlgorithms(value) {
  if (Array.isArray(value)) return value.map((item) => String(item).trim()).filter(Boolean);
  return String(value || '')
    .split(/[,，\n]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function normalizeTemplateRollout(value) {
  const text = String(value || '').trim();
  if (text === '灰度' || text === '草稿') return text;
  return '全量';
}

function buildAlgorithmModel(body = {}, existing = []) {
  const sourceFile = String(body.sourceFile || body.fileName || body.name || '').trim();
  const id = String(body.id || nextAlgorithmId(existing)).trim();
  const name = String(body.name || modelNameFromFile(sourceFile) || id).trim();
  const family = String(body.family || inferModelFamily(`${name} ${sourceFile}`) || 'YOLO11n').trim();
  const version = String(body.version || inferModelVersion(`${name} ${sourceFile}`) || '未标注').trim();
  const format = normalizeModelFormat(body.format || inferModelFormat(sourceFile));

  return {
    id,
    name,
    family,
    version,
    format,
    node: String(body.node || 'C9-POOL').trim(),
    fps: normalizeMetric(body.fps, 0),
    latency: normalizeMetric(body.latency, 0),
    utilization: normalizeMetric(body.utilization, 0),
    accuracy: normalizeMetric(body.accuracy, 0),
    sourceFile: sourceFile || body.sourceFile,
    fileSize: normalizeMetric(body.fileSize, 0),
    importedAt: body.importedAt || nowIso(),
    inputSize: normalizeMetric(body.inputSize ?? body.imgsz, 640),
    confidence: normalizeMetric(body.confidence ?? body.conf, 0.35),
    iou: normalizeMetric(body.iou, 0.45),
    labels: String(body.labels || 'person,bottle,crack,stain').trim(),
    runtime: String(body.runtime || (format === 'TensorRT' ? 'tensorrt' : 'onnxruntime-cpu')).trim(),
    status: String(body.status || '待下发').trim(),
  };
}

async function syncAlgorithmModelsFromFiles(store) {
  const snapshot = await store.snapshot();
  const existing = snapshot.algorithms || [];
  const runtime = await readAiModelRuntime(store);
  const files = preferRuntimeModelFiles(discoverModelFiles(), runtime.modelBasenames);
  const models = [];

  for (const file of files) {
    const stat = statSync(file);
    const runtimeUsage = runtime.byModelBase.get(path.basename(file)) || null;
    const model = buildAlgorithmModel(
      {
        id: `ALG-FILE-${sha256Text(path.basename(file)).slice(0, 10).toUpperCase()}`,
        name: modelNameFromFile(file),
        sourceFile: file,
        fileSize: stat.size,
        importedAt: nowIso(stat.mtime),
        family: inferModelFamily(file) || (String(file).toLowerCase().includes('yolo11') ? 'YOLO11n' : undefined),
        node: runtimeUsage?.node || inferModelNode(file),
        fps: runtimeUsage?.fps ?? 0,
        latency: runtimeUsage?.latency ?? 0,
        utilization: runtimeUsage?.utilization ?? 0,
        labels: runtimeUsage?.labels || undefined,
        runtime: runtimeUsage?.runtime || (inferModelFormat(file) === 'ONNX' ? runtime.defaultRuntime : undefined),
        status: runtimeUsage?.status || '已停用',
      },
      [...existing, ...models],
    );
    models.push(await store.createAlgorithm(model));
  }

  return {
    scanDirs: modelScanDirs(),
    scanned: files.length,
    models,
  };
}

async function algorithmModelsWithRuntimeStatus(store) {
  const snapshot = await store.snapshot();
  const existing = snapshot.algorithms || [];
  const runtime = await readAiModelRuntime(store);
  const models = existing.map((algorithm) => decorateAlgorithmWithRuntimeStatus(algorithm, runtime));
  const coveredRuntimeModels = new Set(
    models
      .map((algorithm) => algorithm.runtimeModelBase)
      .filter(Boolean)
      .map((value) => String(value).toLowerCase()),
  );

  for (const [base, usage] of runtime.byModelBase.entries()) {
    const normalizedBase = String(base).toLowerCase();
    if (coveredRuntimeModels.has(normalizedBase)) continue;
    models.unshift(
      buildAlgorithmModel(
        {
          id: `ALG-RUNTIME-${sha256Text(base).slice(0, 10).toUpperCase()}`,
          name: modelNameFromFile(base),
          sourceFile: usage.sourceFile || base,
          family: inferModelFamily(base) || 'YOLO11n',
          node: usage.node,
          fps: usage.fps,
          latency: usage.latency,
          utilization: usage.utilization,
          labels: usage.labels,
          runtime: usage.runtime,
          status: usage.status,
        },
        models,
      ),
    );
    models[0].runtimeChannels = usage.channels;
    models[0].runtimeOnlineChannels = usage.onlineChannels;
    models[0].runtimeModelBase = base;
  }

  return models;
}

function decorateAlgorithmWithRuntimeStatus(algorithm, runtime) {
  const model = clone(algorithm);
  const usage = runtimeUsageForAlgorithm(model, runtime);
  if (!usage) {
    const sourceFile = String(model.sourceFile || '').trim();
    return {
      ...model,
      status: sourceFile && !existsSync(sourceFile) ? '文件缺失' : '已入库',
      runtimeChannels: [],
      runtimeOnlineChannels: 0,
    };
  }
  return {
    ...model,
    status: usage.status,
    fps: usage.fps,
    latency: usage.latency,
    utilization: usage.utilization,
    runtime: usage.runtime || model.runtime,
    labels: usage.labels || model.labels,
    node: usage.node || model.node,
    runtimeChannels: usage.channels,
    runtimeOnlineChannels: usage.onlineChannels,
    runtimeModelBase: usage.modelBase,
  };
}

function runtimeUsageForAlgorithm(algorithm, runtime) {
  if (!runtime?.byModelBase) return null;
  const candidates = [
    algorithm.sourceFile,
    algorithm.fileName,
    algorithm.modelFile,
    algorithm.name,
    algorithm.id,
  ]
    .map((value) => path.basename(String(value || '').trim()))
    .filter(Boolean);

  for (const candidate of candidates) {
    const direct = runtime.byModelBase.get(candidate);
    if (direct) return direct;
  }

  const haystack = candidates.join(' ').toLowerCase();
  for (const [base, usage] of runtime.byModelBase.entries()) {
    if (haystack.includes(String(base).toLowerCase())) return usage;
  }

  return null;
}

async function readAiModelRuntime(store) {
  const statuses = new Map();
  if (typeof store?.listAiWorkerStatuses === 'function') {
    for (const item of await store.listAiWorkerStatuses()) {
      statuses.set(String(item.workerId || item.worker_id || '').trim(), item);
    }
  }

  const envs = readAiWorkerEnvFiles();
  const byModelBase = new Map();
  const modelBasenames = new Set();
  const defaultRuntime = inferOrtRuntimeProvider(envs);

  for (const env of envs) {
    const modelPath = String(env.values.YOLO_ONNX || env.values.MODEL_PATH || '').trim();
    if (!modelPath) continue;
    const base = path.basename(modelPath);
    modelBasenames.add(base);
    const status = statuses.get(env.channel) || {};
    const online = String(status.status || '').toLowerCase() === 'online' || String(status.status || '').includes('在线');
    const current = byModelBase.get(base) || {
      channels: [],
      onlineChannels: 0,
      fpsValues: [],
      latencyValues: [],
      sourceFile: modelPath,
      modelBase: base,
      labels: env.values.YOLO_LABELS || env.values.LABELS || '',
      runtime: inferOrtRuntimeProvider([env]),
      node: inferRuntimeNodeFromChannel(env.channel),
    };
    current.channels.push(env.channel);
    if (online && !String(status.detail || '').toLowerCase().includes('sentinel disabled')) current.onlineChannels += 1;
    const fps = Number(status.fps);
    if (Number.isFinite(fps)) current.fpsValues.push(fps);
    const latency = Number(status.latencyMs ?? status.latency_ms);
    if (Number.isFinite(latency)) current.latencyValues.push(latency);
    if (env.values.YOLO_LABELS || env.values.LABELS) current.labels = env.values.YOLO_LABELS || env.values.LABELS;
    current.runtime = current.runtime || inferOrtRuntimeProvider([env]);
    current.node = current.node || inferRuntimeNodeFromChannel(env.channel);
    byModelBase.set(base, current);
  }

  for (const [base, value] of byModelBase.entries()) {
    const fps = averageNumber(value.fpsValues);
    const latency = averageNumber(value.latencyValues);
    byModelBase.set(base, {
      ...value,
      fps,
      latency,
      utilization: Math.min(100, value.onlineChannels * 10),
      status: value.onlineChannels > 0 ? '运行中' : '已停止',
    });
  }

  return { byModelBase, modelBasenames, defaultRuntime };
}

function readAiWorkerEnvFiles() {
  const dirs = uniqueStrings([
    ...splitPathList(process.env.RIVER_WATCH_AI_ENV_DIRS),
    process.env.RIVER_WATCH_AI_ENV_DIR,
    '/etc/river-watch',
  ].filter(Boolean));
  const envs = [];
  for (const dir of dirs) {
    if (!existsSync(dir)) continue;
    try {
      for (const entry of readdirSync(dir, { withFileTypes: true })) {
        if (!entry.isFile() || !/^ai-worker-.+\.env$/i.test(entry.name)) continue;
        const fullPath = path.join(dir, entry.name);
        const values = parseSimpleEnv(readFileSync(fullPath, 'utf8'));
        const channel = entry.name.replace(/^ai-worker-/i, '').replace(/\.env$/i, '');
        envs.push({ channel, fullPath, values });
      }
    } catch {
      // Ignore unreadable runtime env directories; model file scan still reports inventory.
    }
  }
  return envs;
}

function parseSimpleEnv(text = '') {
  const values = {};
  for (const line of String(text).split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#') || !trimmed.includes('=')) continue;
    const index = trimmed.indexOf('=');
    const key = trimmed.slice(0, index).trim();
    let value = trimmed.slice(index + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    values[key] = value;
  }
  return values;
}

function preferRuntimeModelFiles(files = [], runtimeModelBasenames = new Set()) {
  const byBase = new Map();
  const sorted = [...files].sort((a, b) => modelFilePriority(a, runtimeModelBasenames) - modelFilePriority(b, runtimeModelBasenames));
  for (const file of sorted) {
    const base = path.basename(file);
    if (!byBase.has(base)) byBase.set(base, file);
  }
  return Array.from(byBase.values()).sort((a, b) => a.localeCompare(b, 'en'));
}

function modelFilePriority(file, runtimeModelBasenames) {
  const base = path.basename(file);
  if (runtimeModelBasenames.has(base)) return 0;
  if (String(file).startsWith('/opt/river-watch/models')) return 1;
  return 2;
}

function inferOrtRuntimeProvider(envs = []) {
  const text = envs.map((env) => `${env.values.ORT_PROVIDERS || ''} ${env.values.ONNXRUNTIME_PROVIDERS || ''}`).join(' ').toLowerCase();
  if (text.includes('migraphx') || text.includes('rocm') || text.includes('cuda')) return 'onnxruntime-gpu';
  return 'onnxruntime-cpu';
}

function inferRuntimeNodeFromChannel(channel = '') {
  const index = Number(String(channel).match(/\d+/)?.[0] || 0);
  if (index >= 9) return 'C9-EDGE-03';
  if (index >= 5) return 'C9-EDGE-02';
  return 'C9-EDGE-01';
}

function averageNumber(values = []) {
  const valid = values.map(Number).filter(Number.isFinite);
  if (!valid.length) return 0;
  return Math.round((valid.reduce((sum, value) => sum + value, 0) / valid.length) * 10) / 10;
}

function discoverModelFiles() {
  const allowed = new Set(['.onnx', '.engine', '.plan', '.rknn', '.xmodel']);
  const files = [];
  for (const dir of modelScanDirs()) {
    for (const file of walkFiles(dir)) {
      if (allowed.has(path.extname(file).toLowerCase())) files.push(file);
    }
  }
  return uniqueStrings(files).sort((a, b) => a.localeCompare(b, 'en'));
}

function modelScanDirs() {
  return uniqueStrings([
    ...splitPathList(process.env.RIVER_WATCH_MODEL_DIRS),
    process.env.RIVER_WATCH_MODEL_DIR,
    process.env.AI_MODEL_DIR,
    '/opt/river-watch/models',
    path.resolve(process.cwd(), 'models'),
    path.resolve(process.cwd(), '..', 'models'),
  ].filter(Boolean));
}

function splitPathList(value = '') {
  return String(value)
    .split(/[;,]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function walkFiles(dir) {
  if (!existsSync(dir)) return [];
  const entries = [];
  try {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) entries.push(...walkFiles(fullPath));
      else if (entry.isFile()) entries.push(fullPath);
    }
  } catch {
    return [];
  }
  return entries;
}

function inferModelNode(fileName = '') {
  const lower = String(fileName).toLowerCase();
  if (lower.includes('structure') || lower.includes('seg')) return 'C9-EDGE-03';
  if (lower.includes('pool') || lower.includes('uav') || lower.includes('import')) return 'C9-POOL';
  if (lower.includes('edge-02') || lower.includes('ch05') || lower.includes('ch08')) return 'C9-EDGE-02';
  return 'C9-EDGE-01';
}

function uniqueStrings(values = []) {
  return Array.from(new Set(values.map((value) => String(value || '').trim()).filter(Boolean)));
}

function nextAlgorithmId(existing = []) {
  const numbers = existing
    .map((item) => String(item.id || '').match(/^ALG-(\d+)$/i)?.[1])
    .filter(Boolean)
    .map(Number);
  const next = (numbers.length ? Math.max(...numbers) : existing.length) + 1;
  return `ALG-${String(next).padStart(2, '0')}`;
}

function modelNameFromFile(fileName = '') {
  const base = path.basename(String(fileName), path.extname(String(fileName)));
  return base.replace(/[_-]+/g, ' ').replace(/\s+/g, ' ').trim();
}

function inferModelFamily(value = '') {
  const upper = String(value).toUpperCase();
  if (/YOLO11N/i.test(String(value))) return 'YOLO11n';
  const match = upper.match(/YOLO(?:V)?\d+|YOLO\d+[A-Z-]*/);
  if (!match) return '';
  return match[0].replace('YOLOV', 'YOLOv').replace(/^YOLO(\d)/, 'YOLO$1');
}

function inferModelVersion(value = '') {
  const text = String(value);
  const explicit = text.match(/(?:^|[-_\s])v?(\d+(?:\.\d+){1,3})(?:[-_\s.]|$)/i);
  if (explicit) return explicit[1].startsWith('v') ? explicit[1] : explicit[1];
  const yolo = text.match(/yolo(?:v)?(\d+)/i);
  return yolo ? `${yolo[1]}.0.0` : '';
}

function inferModelFormat(fileName = '') {
  const ext = path.extname(String(fileName)).toLowerCase();
  if (ext === '.engine' || ext === '.plan') return 'TensorRT';
  if (ext === '.rknn' || ext === '.xmodel') return 'Ryzen AI';
  return 'ONNX';
}

function normalizeModelFormat(value = '') {
  const text = String(value).toLowerCase();
  if (text.includes('tensor') || text.includes('engine') || text.includes('plan')) return 'TensorRT';
  if (text.includes('ryzen') || text.includes('xmodel') || text.includes('rknn')) return 'Ryzen AI';
  return 'ONNX';
}

function normalizeMetric(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

async function runtimeSentinelMode(store) {
  const value = store?.getRuntimeConfig ? await store.getRuntimeConfig('sentinelMode') : null;
  return normalizeRuntimeSentinelMode(value);
}

async function saveRuntimeSentinelMode(store, body = {}, authContext = null) {
  const current = await runtimeSentinelMode(store);
  const next = normalizeRuntimeSentinelMode({
    ...current,
    enabled: body.enabled,
    updatedAt: nowIso(),
    updatedBy: body.updatedBy || authContext?.user?.name || authContext?.user?.username || 'system',
    reason: body.reason || (body.enabled === false ? 'manual-stop' : 'manual-start'),
  });
  if (typeof store?.saveRuntimeConfig === 'function') {
    await store.saveRuntimeConfig({ key: 'sentinelMode', group: 'runtime', value: next });
  }
  return next;
}

function normalizeRuntimeSentinelMode(value = {}) {
  return {
    enabled: value?.enabled !== false,
    updatedAt: value?.updatedAt || null,
    updatedBy: value?.updatedBy || 'system',
    reason: value?.reason || '',
  };
}

async function runtimeConfidenceThresholds(store) {
  const value = store?.getRuntimeConfig ? await store.getRuntimeConfig('confidenceThresholds') : null;
  return normalizeConfidenceThresholds(value);
}

async function saveRuntimeConfidenceThresholds(store, body = {}) {
  const current = await runtimeConfidenceThresholds(store);
  const incoming = normalizeConfidenceThresholds(body.thresholds || {});
  const next = { ...current, ...incoming };
  const cameraId = String(body.cameraId || body.channelId || '').trim();
  if (cameraId) next[cameraId] = normalizeConfidencePercent(body.value ?? body.confidence ?? body.threshold, current[cameraId] ?? 50);
  if (typeof store?.saveRuntimeConfig === 'function') {
    await store.saveRuntimeConfig({ key: 'confidenceThresholds', group: 'runtime', value: next, updatedAt: nowIso() });
  }
  return next;
}

function normalizeConfidenceThresholds(value = {}) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const next = {};
  for (const [key, raw] of Object.entries(source)) {
    const cameraId = String(key || '').trim();
    if (!cameraId) continue;
    next[cameraId] = normalizeConfidencePercent(raw, 50);
  }
  return next;
}

function normalizeConfidencePercent(value, fallback = 50) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return fallback;
  return Math.max(0, Math.min(100, Math.round(numeric)));
}

function isPublicRoute(method, pathName) {
  if (method === 'OPTIONS') return true;
  if (method === 'GET' && (pathName === '/health' || pathName === '/api/health')) return true;
  if (method === 'POST' && (pathName === '/api/auth/login' || pathName === '/api/v1/auth/login')) return true;
  return false;
}

function isAiIngestRoute(method, pathName) {
  if (method === 'GET' && [
    '/api/runtime/sentinel',
    '/api/v1/runtime/sentinel',
  ].includes(pathName)) return true;

  return method === 'POST' && [
    '/api/ai/metadata',
    '/api/v1/alarms/metadata',
    '/api/device/status',
    '/api/v1/device/status',
    '/api/ai/worker-status',
    '/api/v1/ai/worker-status',
  ].includes(pathName);
}

async function syncStreamRelayCamera(streamRelay, camera) {
  if (!streamRelay || typeof streamRelay.syncCamera !== 'function') return;
  try {
    await streamRelay.syncCamera(camera);
  } catch (error) {
    console.warn(`[stream-relay] sync failed for ${camera?.id || 'unknown'}: ${error?.message || error}`);
  }
}

async function removeStreamRelayCamera(streamRelay, cameraId) {
  if (!streamRelay || typeof streamRelay.removeCamera !== 'function') return;
  try {
    await streamRelay.removeCamera(cameraId);
  } catch (error) {
    console.warn(`[stream-relay] remove failed for ${cameraId || 'unknown'}: ${error?.message || error}`);
  }
}

function buildCamera(body, existing = []) {
  const id = String(body.id || body.channelId || nextCameraId(existing)).toUpperCase();
  const nextIndex = channelNumber(id) || existing.length + 1;
  const isPool = String(body.template || body.name || '').includes('厌氧池');
  const current = existing.find((camera) => camera.id === id) || {};
  const protocol = body.protocol || current.protocol || 'GB28181';
  const ip = body.ip || current.ip || body.stream || `10.20.1.${20 + nextIndex}`;
  const cameraType = body.cameraType || current.cameraType || (Boolean(body.ptz ?? current.ptz ?? true) ? '云台球机' : '固定枪机');
  const latitude = numericOrUndefined(body.latitude ?? current.latitude);
  const longitude = numericOrUndefined(body.longitude ?? current.longitude);
  const streamUrl = String(body.streamUrl || body.stream || current.streamUrl || '').trim();
  const node = body.node || current.node || 'C9-EDGE-02';
  const defaultStreams = defaultCameraStreams(id, node, streamUrl);
  const streams = {
    display: mergeDisplayStreams(defaultStreams.display, current.streams?.display, body.streams?.display),
    inference: { ...defaultStreams.inference, ...(current.streams?.inference || {}), ...(body.streams?.inference || {}) },
    metadata: { ...defaultStreams.metadata, ...(current.streams?.metadata || {}), ...(body.streams?.metadata || {}) },
  };

  return {
    id,
    name: body.name || current.name || `排水口-${String(nextIndex).padStart(2, '0')}`,
    cameraType,
    status: body.status || current.status || '在线',
    scene: isPool ? '厌氧池' : '排水口',
    protocol,
    ip,
    streamUrl,
    displayStreamUrl: body.displayStreamUrl || streams.display.hls || '',
    inferenceStreamUrl: body.inferenceStreamUrl || current.inferenceStreamUrl || streams.inference.rtsp || '',
    inferenceSampleFps: numericOrUndefined(body.inferenceSampleFps ?? current.inferenceSampleFps ?? streams.inference.sampleFps),
    inferenceModel: body.inferenceModel || current.inferenceModel || streams.inference.model || '',
    streams,
    longitude,
    latitude,
    group: body.group || current.group || (isPool ? '厌氧池监测' : '排水口监测'),
    node,
    ptz: Boolean(body.ptz ?? current.ptz ?? cameraType !== '固定枪机'),
    location: Array.isArray(body.location) ? body.location : current.location || [Math.min(88, 16 + nextIndex * 6), Math.min(82, 24 + nextIndex * 4)],
    templateId: body.templateId || current.templateId || (isPool ? 'TPL-POOL' : 'TPL-OUTLET'),
    bitrate: body.bitrate || current.bitrate || `${Number(4.1).toFixed(1)}Mbps`,
    latency: Number(body.latency || current.latency || 430),
    detections: Array.isArray(body.detections) ? body.detections : current.detections || [],
  };
}

function mergeDisplayStreams(defaultDisplay = {}, currentDisplay = {}, bodyDisplay = {}) {
  const generatedKeys = new Set(['source', 'webrtc', 'flv', 'rtmp', 'hls']);
  const currentCustom = Object.fromEntries(
    Object.entries(currentDisplay || {}).filter(([key]) => !generatedKeys.has(key)),
  );
  return {
    ...defaultDisplay,
    ...currentCustom,
    ...(bodyDisplay || {}),
  };
}

function defaultCameraStreams(id, node, streamUrl = '') {
  const publicHost = process.env.STREAM_PUBLIC_HOST || process.env.SERVER_PUBLIC_HOST || '192.168.3.62';
  const source = streamUrl || `http://${publicHost}:8060/live/${id}`;
  const sampleFps = cameraInferenceSampleFps(id);
  const model = cameraInferenceModel(id);
  return {
    display: {
      source,
      webrtc: `http://${publicHost}:8889/${id}`,
      flv: `http://${publicHost}:8060/live/${id}.live.flv`,
      rtmp: `rtmp://${publicHost}:1935/live/${id}`,
      hls: `http://${publicHost}:8060/live/${id}/hls.m3u8`,
    },
    inference: {
      rtsp: `rtsp://127.0.0.1:8554/${id}-infer`,
      sampleFps,
      node,
      model,
    },
    metadata: {
      post: '/api/v1/alarms/metadata',
      overlay: `/api/streams/${id}/metadata`,
      coordinateSpace: 'normalized',
    },
  };
}

function cameraInferenceSampleFps(id) {
  const number = channelNumber(id);
  if (number >= 9) return 2;
  return ['CH03', 'CH07'].includes(id) ? 6 : 4;
}

function cameraInferenceModel(id) {
  return channelNumber(id) >= 9 ? 'yolo26n-seg-structure-ft.onnx' : 'yolo26n-coco-base.onnx';
}

function buildUavAsset(body, existing = []) {
  const current = existing.find((asset) => asset.id === String(body.id || '').toUpperCase()) || {};
  const id = String(body.id || current.id || nextUavAssetId(existing)).toUpperCase();
  const longitude = numericOrUndefined(body.longitude ?? current.longitude);
  const latitude = numericOrUndefined(body.latitude ?? current.latitude);
  const location = Array.isArray(body.location)
    ? body.location
    : current.location || (longitude !== undefined && latitude !== undefined ? [48, 52] : undefined);

  return {
    id,
    name: body.name || current.name || '大疆机场无人机',
    assetType: body.assetType || current.assetType || '无人机+机巢',
    vendor: body.vendor || current.vendor || 'DJI',
    model: body.model || current.model || 'DJI Dock 2 + Matrice 3TD',
    dockName: body.dockName || current.dockName || '默认机巢',
    dockSn: body.dockSn || current.dockSn || '',
    droneSn: body.droneSn || current.droneSn || '',
    status: body.status || current.status || '待命',
    mode: body.mode || current.mode || 'auto',
    longitude,
    latitude,
    location,
    battery: numericOrUndefined(body.battery ?? current.battery),
    signal: numericOrUndefined(body.signal ?? current.signal),
    altitude: numericOrUndefined(body.altitude ?? current.altitude),
    speed: numericOrUndefined(body.speed ?? current.speed),
    dockStatus: body.dockStatus || current.dockStatus || '状态待同步',
    dockWeather: body.dockWeather || current.dockWeather || '气象待同步',
    rtkStatus: body.rtkStatus || current.rtkStatus || 'RTK 待同步',
    firmware: body.firmware || current.firmware || '',
    payload: body.payload || current.payload || '',
    videoReturn: body.videoReturn || current.videoReturn || '视频回传待建立',
    activeTaskId: body.activeTaskId || current.activeTaskId || '',
    relatedAlarm: body.relatedAlarm || current.relatedAlarm || '',
    lastHeartbeatAt: body.lastHeartbeatAt || current.lastHeartbeatAt || nowIso(),
  };
}

function numericOrUndefined(value) {
  if (value === undefined || value === null || value === '') return undefined;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

function nextCameraId(existing = []) {
  const used = new Set(existing.map((camera) => channelNumber(camera.id)).filter(Boolean));
  for (let index = 1; index <= used.size + 1; index += 1) {
    if (!used.has(index)) return `CH${String(index).padStart(2, '0')}`;
  }
  return `CH${String(existing.length + 1).padStart(2, '0')}`;
}

function nextUavAssetId(existing = []) {
  const used = new Set(existing.map((asset) => {
    const match = String(asset.id || '').match(/^UAV-(\d+)$/i);
    return match ? Number(match[1]) : 0;
  }).filter(Boolean));
  for (let index = 1; index <= used.size + 1; index += 1) {
    if (!used.has(index)) return `UAV-${String(index).padStart(3, '0')}`;
  }
  return `UAV-${String(existing.length + 1).padStart(3, '0')}`;
}

function channelNumber(id) {
  const match = String(id || '').match(/^CH(\d+)$/i);
  return match ? Number(match[1]) : 0;
}

function buildOperationTask(profile, payload) {
  const createdAt = nowIso();
  const shortId = randomUUID().slice(0, 8).toUpperCase();
  return {
    id: `OP-${Date.now()}-${shortId}`,
    moduleName: profile.moduleName,
    actionName: profile.actionName,
    status: profile.status,
    targetId: profile.targetId || payload.id || payload.alarmId || payload.name || '',
    payload,
    createdAt,
    updatedAt: createdAt,
  };
}

function streamInfo(cameraId, camera = null) {
  const id = cameraId.toUpperCase();
  const gateway = videoGatewayConfig();
  const streamBase = process.env.STREAM_BASE_URL || `${gateway.zlmHttpUrl}/live`;
  const webrtcBase = process.env.WEBRTC_BASE_URL || `http://${gateway.publicHost}:8889`;
  const jessibucaBase = process.env.JESSIBUCA_BASE_URL || streamBase;
  const rtmpBase = process.env.RTMP_BASE_URL || `${gateway.zlmRtmpUrl}/live`;
  const hlsBase = process.env.HLS_BASE_URL || `${gateway.zlmHttpUrl}/live`;
  const displayStreams = camera?.streams?.display || {};
  const inferenceStreams = camera?.streams?.inference || {};
  const metadataStreams = camera?.streams?.metadata || {};
  const display = {
    role: 'display',
    purpose: 'frontend-hd',
    source: displayStreams.source || camera?.streamUrl || camera?.displayStreamUrl || `${streamBase}/${id}`,
    webrtc: displayStreams.webrtc || camera?.displayStreamUrl || `${webrtcBase}/${id}`,
    flv: normalizeZlmFlvUrl(displayStreams.flv || `${jessibucaBase}/${id}.live.flv`),
    rtmp: displayStreams.rtmp || `${rtmpBase}/${id}`,
    hls: displayStreams.hls || `${hlsBase}/${id}/hls.m3u8`,
  };
  const inference = {
    role: 'inference',
    purpose: 'ai-sampled',
    rtsp: camera?.inferenceStreamUrl || inferenceStreams.rtsp || camera?.streamUrl || `${streamBase}/${id}`,
    sampleFps: Number(camera?.inferenceSampleFps || inferenceStreams.sampleFps || 4),
    node: camera?.node || inferenceStreams.node || '',
    model: camera?.inferenceModel || inferenceStreams.model || '',
  };
  const metadata = {
    role: 'metadata',
    coordinateSpace: metadataStreams.coordinateSpace || 'normalized',
    post: metadataStreams.post || '/api/v1/alarms/metadata',
    overlay: metadataStreams.overlay || `/api/streams/${id}/metadata`,
  };
  return {
    cameraId: id,
    sourceProtocol: camera?.protocol || 'GB28181',
    ingestMode: gateway.mode,
    display,
    inference,
    metadata,
    clean: display.source,
    webrtc: display.webrtc,
    flv: display.flv,
    rtmp: display.rtmp,
    hls: display.hls,
    overlay: metadata.overlay,
    gateway,
  };
}

function normalizeZlmFlvUrl(url = '') {
  return String(url || '').replace(/\/live\/([^/?#.]+)\.flv(?=([?#]|$))/, '/live/$1.live.flv');
}

function videoGatewayConfig() {
  const publicHost = process.env.STREAM_PUBLIC_HOST || process.env.SERVER_PUBLIC_HOST || '192.168.3.62';
  return {
    mode: process.env.VIDEO_GATEWAY_MODE || 'wvp-zlm',
    publicHost,
    wvpBaseUrl: process.env.WVP_BASE_URL || `http://${publicHost}:18080`,
    zlmHttpUrl: process.env.ZLMEDIAKIT_HTTP_URL || `http://${publicHost}:8060`,
    zlmRtmpUrl: process.env.ZLMEDIAKIT_RTMP_URL || `rtmp://${publicHost}:1935`,
    sipDomain: process.env.GB28181_SIP_DOMAIN || '3402000000',
    sipServerId: process.env.GB28181_SERVER_ID || '34020000002000000001',
    playbackDays: Number(process.env.VIDEO_PLAYBACK_DAYS || 30),
  };
}

async function buildAlarmRecord(store, body = {}) {
  const cameraId = String(body.cameraId || body.channelId || '').trim().toUpperCase();
  if (!cameraId) throw httpError(400, '缺少 cameraId');
  const camera = await store.getCamera(cameraId);
  if (!camera) throw httpError(404, `设备不存在：${cameraId}`);

  const confidence = normalizePercent(body.confidence ?? body.score ?? 86);
  const status = validAlarmStatus(body.status) ? body.status : '待研判';
  const dispatchId = body.dispatchId || (status === '已派单' || status === '已确认' || String(body.source || '') === 'realtime-dispatch' ? `DP-${String(Date.now()).slice(-10)}` : '');
  return {
    id: String(body.id || `A-${Date.now()}`),
    cameraId: camera.id,
    cameraName: camera.name,
    type: String(body.type || body.label || body.cls || 'AI识别事件'),
    severity: validSeverity(body.severity) ? body.severity : severityFromScore(confidence / 100),
    confidence,
    status,
    time: String(body.time || beijingTimeText()),
    pts: String(body.pts || '00:00:00.000'),
    owner: String(body.owner || 'AI 推理服务'),
    dedupeCount: Math.max(1, Number(body.dedupeCount || 1)),
    snapshot: String(body.snapshot || `实时推理 / ${camera.id}`),
    ...(dispatchId ? { dispatchId: String(dispatchId) } : {}),
    ...(dispatchId ? { dispatchedAt: String(body.dispatchedAt || nowIso()) } : {}),
    ...(body.reviewResult ? { reviewResult: String(body.reviewResult) } : {}),
    ...(body.archiveReason ? { archiveReason: String(body.archiveReason) } : {}),
    ...(body.archivedAt ? { archivedAt: String(body.archivedAt) } : {}),
    ...(body.updatedAt ? { updatedAt: String(body.updatedAt) } : {}),
  };
}

function normalizePercent(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return 86;
  const percent = numeric <= 1 ? numeric * 100 : numeric;
  return Math.max(0, Math.min(100, Math.round(percent * 10) / 10));
}

function validAlarmStatus(value) {
  return ['待研判', '已确认', '已派单', '误报', '已归档'].includes(value);
}

function validSeverity(value) {
  return ['提示', '一般', '严重', '紧急'].includes(value);
}

function aiPipelineHealth(recentEvents, workers = defaultAiWorkers(), ingestStats = null) {
  const onlineWorkers = workers.filter((worker) => worker.status === 'online').length;
  const failedEvents = recentEvents.filter((event) => event.retryStatus === 'failed').length;
  const queue = ingestStats || {
    driver: process.env.AI_QUEUE_DRIVER || 'redis-stream',
    stream: process.env.AI_QUEUE_STREAM || 'riverwatch.ai.metadata',
    retryMaxAttempts: Number(process.env.AI_RETRY_MAX_ATTEMPTS || 3),
    retryBackoff: process.env.AI_RETRY_BACKOFF || 'exponential',
    backlog: 0,
    deadLetters: 0,
  };
  return {
    status: onlineWorkers > 0 && failedEvents === 0 && Number(queue.deadLetters || 0) === 0 ? 'UP' : 'DEGRADED',
    queue,
    workers,
    recentEvents: recentEvents.length,
    failedEvents,
  };
}

function aiWorkers() {
  if (process.env.AI_WORKERS_JSON) {
    try {
      return JSON.parse(process.env.AI_WORKERS_JSON);
    } catch {
      return defaultAiWorkers('AI_WORKERS_JSON_PARSE_ERROR');
    }
  }

  return defaultAiWorkers();
}

function defaultAiWorkers(reason = '') {
  return [
    {
      id: 'C9-EDGE-01',
      name: 'C9 边缘推理 01',
      status: 'online',
      model: 'YOLOv8#1',
      runtime: 'onnxruntime',
      channels: ['CH01', 'CH02', 'CH03', 'CH04'],
      fps: 21.4,
      latencyMs: 48,
      retryPolicy: { maxAttempts: Number(process.env.AI_RETRY_MAX_ATTEMPTS || 3), backoff: process.env.AI_RETRY_BACKOFF || 'exponential' },
      note: reason,
    },
    {
      id: 'C9-EDGE-02',
      name: 'C9 边缘推理 02',
      status: 'online',
      model: 'YOLOv8#2',
      runtime: 'onnxruntime',
      channels: ['CH05', 'CH06', 'CH07', 'CH11'],
      fps: 20.8,
      latencyMs: 51,
      retryPolicy: { maxAttempts: Number(process.env.AI_RETRY_MAX_ATTEMPTS || 3), backoff: process.env.AI_RETRY_BACKOFF || 'exponential' },
      note: reason,
    },
  ];
}

async function readJson(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  if (chunks.length === 0) return {};
  const text = Buffer.concat(chunks).toString('utf8');
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    throw httpError(400, '请求体不是合法 JSON');
  }
}

function signToken(userOrName) {
  const user = typeof userOrName === 'string' ? userProfile(userOrName) : userOrName;
  const payload = Buffer.from(JSON.stringify({ sub: user.name, roleId: user.roleId, permissions: user.permissions, iat: Date.now() })).toString('base64url');
  const secret = process.env.JWT_SECRET || 'river-watch-dev-secret';
  const signature = createHmac('sha256', secret).update(payload).digest('base64url');
  return `${payload}.${signature}`;
}

function verifyToken(header) {
  const token = bearerToken(header);
  const [payload, signature] = token.split('.');
  if (!payload || !signature) return null;

  const secret = process.env.JWT_SECRET || 'river-watch-dev-secret';
  const expected = createHmac('sha256', secret).update(payload).digest('base64url');
  if (signature !== expected) return null;

  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    const ttlMs = Number(process.env.AUTH_TOKEN_TTL_HOURS || 8) * 60 * 60 * 1000;
    if (!data.iat || Date.now() - Number(data.iat) > ttlMs) return null;
    return data;
  } catch {
    return null;
  }
}

function verifyIngestToken(header) {
  const expected = String(process.env.AI_INGEST_TOKEN || '').trim();
  const token = bearerToken(header);
  if (!expected || !token || token !== expected) return null;
  return {
    sub: 'ai-worker',
    roleId: 'service',
    permissions: ['ai:ingest', 'runtime:read'],
    serviceToken: true,
  };
}

function bearerToken(header = '') {
  return String(header || '').startsWith('Bearer ') ? String(header).slice('Bearer '.length) : '';
}

async function authUserProfile(store, username = 'admin', roleHint = '') {
  const fallback = userProfile(username, roleHint);
  const users = typeof store.listUsers === 'function' ? await store.listUsers() : [];
  const roles = typeof store.listRolePermissions === 'function' ? await store.listRolePermissions() : [];
  const lower = String(username || '').toLowerCase();
  const matchedUser = users.find((user) =>
    [user.id, user.name, user.username].filter(Boolean).some((value) => String(value).toLowerCase() === lower),
  );
  const roleId = roleHint || roleIdFromName(matchedUser?.role || fallback.roleId);
  const matchedRole = roles.find((role) => role.roleId === roleId || role.roleName === matchedUser?.role || role.roleName === fallback.role);
  const storedPermissions = Array.isArray(matchedRole?.permissions) ? matchedRole.permissions : [];
  const hasStoredPermissionCodes = storedPermissions.some((permission) => {
    const value = String(permission || '').trim();
    return value === '*' || value.includes(':');
  });
  const dbPermissions = storedPermissions.length
    ? permissionCodesFromRole(storedPermissions)
    : [];

  return {
    name: matchedUser?.name || username,
    roleId,
    role: matchedRole?.roleName || matchedUser?.role || fallback.role,
    tenant: '市生态环境局 / 河道监管中心',
    dataScope: matchedRole?.dataScope || matchedUser?.scope || '所属片区',
    permissions: roleId === 'admin' ? ['*'] : resolveAuthPermissions(fallback.permissions, dbPermissions, hasStoredPermissionCodes),
  };
}

function roleIdFromName(role = '') {
  const value = String(role).toLowerCase();
  if (value.includes('admin') || value.includes('管理')) return 'admin';
  if (value.includes('audit') || value.includes('审计')) return 'auditor';
  if (value.includes('处置')) return 'disposer';
  return value || 'operator';
}

function hasPermission(authContext, permission) {
  if (!permission) return true;
  if (!authContext) return false;
  const permissions = Array.isArray(authContext.permissions) ? authContext.permissions : userProfile(authContext.sub, authContext.roleId).permissions;
  return permissions.includes('*') || permissions.includes(permission);
}

function permissionCodesFromRole(permissions = []) {
  const codes = [];
  for (const permission of permissions) {
    for (const code of permissionCodesFromLabel(permission)) {
      if (!codes.includes(code)) codes.push(code);
    }
  }
  return codes;
}

function resolveAuthPermissions(fallback = [], dbPermissions = [], hasStoredPermissionCodes = false) {
  if (!dbPermissions.length) return fallback;
  if (hasStoredPermissionCodes) return dbPermissions;
  return [...new Set([...fallback, ...dbPermissions])];
}

function userProfile(username = 'admin', roleHint = '') {
  const name = String(username || 'admin');
  const lower = name.toLowerCase();
  const roleId = roleHint || (
    lower.includes('auditor') || name.includes('审计')
      ? 'auditor'
      : lower.includes('admin') || name.includes('管理员')
        ? 'admin'
        : name.includes('处置')
          ? 'disposer'
          : 'operator'
  );
  const profile = roleProfiles()[roleId] || roleProfiles().operator;
  return {
    name,
    roleId,
    role: profile.role,
    tenant: '市生态环境局 / 河道监管中心',
    permissions: profile.permissions,
  };
}

function roleProfiles() {
  return {
    admin: {
      role: '平台管理员',
      permissions: ['*'],
    },
    operator: {
      role: '监管运营员',
      permissions: defaultPermissions(),
    },
    disposer: {
      role: '处置人员',
      permissions: ['platform:read', 'workorder:write', 'evidence:download'],
    },
    auditor: {
      role: '审计访客',
      permissions: ['platform:read', 'report:export', 'audit:read', 'evidence:download', 'ops:read'],
    },
  };
}

function defaultPermissions() {
  return [
    'platform:read',
    'device:read',
    'alarm:review',
    'workorder:write',
    'ai:ingest',
    'ai:retry',
    'algorithm:write',
    'template:write',
    'export:create',
    'storage:write',
    'report:write',
    'report:export',
    'rbac:write',
    'evidence:write',
    'evidence:verify',
    'evidence:download',
    'audit:read',
    'audit:export',
    'ops:read',
    'ops:write',
    'notify:read',
    'notify:write',
  ];
}

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Accept');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
}

function clientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (typeof fwd === 'string' && fwd) return fwd.split(',')[0].trim();
  return req.socket?.remoteAddress || 'unknown';
}

function send(res, status, payload) {
  applySecurityHeaders(res);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(payload));
}

function sendBinary(res, contentType, data, extraHeaders = {}) {
  const buffer = Buffer.isBuffer(data) ? data : Buffer.from(data);
  applySecurityHeaders(res);
  res.writeHead(200, {
    'Content-Type': contentType,
    'Content-Length': buffer.length,
    ...extraHeaders,
  });
  res.end(buffer);
}

function sendZip(res, filename, buffer) {
  res.writeHead(200, {
    'Content-Type': 'application/zip',
    'Content-Disposition': `attachment; filename="${filename}"`,
    'Content-Length': buffer.length,
  });
  res.end(buffer);
}

function sendCsv(res, filename, content) {
  const buffer = Buffer.from(content, 'utf8');
  res.writeHead(200, {
    'Content-Type': 'text/csv; charset=utf-8',
    'Content-Disposition': `attachment; filename="${filename}"`,
    'Content-Length': buffer.length,
  });
  res.end(buffer);
}

async function collectHardwareMetrics() {
  const cpus = os.cpus() || [];
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMem = Math.max(0, totalMem - freeMem);
  const load = os.loadavg();
  return {
    sampledAt: nowIso(),
    host: os.hostname(),
    cpu: {
      available: cpus.length > 0,
      model: cpus[0]?.model || 'unknown',
      cores: cpus.length,
      load1: round(load[0]),
      load5: round(load[1]),
      load15: round(load[2]),
      usagePercent: cpus.length ? clampPercent((load[0] / cpus.length) * 100) : 0,
    },
    memory: {
      totalBytes: totalMem,
      usedBytes: usedMem,
      freeBytes: freeMem,
      usagePercent: totalMem ? clampPercent((usedMem / totalMem) * 100) : 0,
    },
    gpu: await collectGpuMetrics(),
    npu: await collectNpuMetrics(),
    disk: await collectDiskMetrics(),
  };
}

async function collectDiskMetrics() {
  const mount = process.env.HARDWARE_METRICS_DISK_PATH || '/';
  const df = await runMetricCommand('df', ['-Pk', mount]);
  if (!df.ok) {
    return {
      available: false,
      mount,
      status: df.stderr || df.error || 'disk metrics command unavailable',
      totalBytes: null,
      usedBytes: null,
      freeBytes: null,
      usagePercent: null,
    };
  }

  const lines = String(df.stdout || '').trim().split(/\r?\n/).filter(Boolean);
  const row = lines[1]?.trim().split(/\s+/);
  if (!row || row.length < 6) {
    return {
      available: false,
      mount,
      status: 'disk metrics output is not parseable',
      totalBytes: null,
      usedBytes: null,
      freeBytes: null,
      usagePercent: null,
    };
  }

  const totalBytes = Number(row[1]) * 1024;
  const usedBytes = Number(row[2]) * 1024;
  const freeBytes = Number(row[3]) * 1024;
  const usagePercent = Number(String(row[4]).replace('%', ''));
  const mountedOn = row.slice(5).join(' ') || mount;

  return {
    available: Number.isFinite(totalBytes) && totalBytes > 0,
    mount: mountedOn,
    status: 'disk metrics available',
    totalBytes: Number.isFinite(totalBytes) ? totalBytes : null,
    usedBytes: Number.isFinite(usedBytes) ? usedBytes : null,
    freeBytes: Number.isFinite(freeBytes) ? freeBytes : null,
    usagePercent: Number.isFinite(usagePercent) ? clampPercent(usagePercent) : null,
  };
}

async function collectGpuMetrics() {
  const amdSmi = await runMetricCommand('amd-smi', ['metric', '--json']);
  if (amdSmi.ok) return parseGpuMetricText('amd-smi', amdSmi.stdout);

  const rocmSmi = await runMetricCommand('rocm-smi', ['--showuse', '--showmemuse', '--showmeminfo', 'vram', '--json']);
  if (rocmSmi.ok) return parseGpuMetricText('rocm-smi', rocmSmi.stdout);

  const sysfs = collectAmdGpuSysfsMetrics();
  if (sysfs.available) return sysfs;

  return {
    available: false,
    provider: 'not-exposed',
    status: 'GPU metrics command not available in backend runtime',
    usagePercent: null,
    memoryUsagePercent: null,
  };
}

function collectAmdGpuSysfsMetrics() {
  const drmDir = '/sys/class/drm';
  if (!existsSync(drmDir)) return { available: false };

  const cards = readdirSync(drmDir)
    .filter((entry) => /^card\d+$/.test(entry))
    .map((entry) => path.join(drmDir, entry, 'device'))
    .filter((devicePath) => existsSync(devicePath));

  for (const devicePath of cards) {
    const vendor = readSysfsText(path.join(devicePath, 'vendor')).toLowerCase();
    if (vendor && vendor !== '0x1002') continue;

    const usagePercent = readSysfsNumber(path.join(devicePath, 'gpu_busy_percent'));
    const vramTotal = readFirstSysfsNumber([
      path.join(devicePath, 'mem_info_vram_total'),
      path.join(devicePath, 'mem_info_vis_vram_total'),
    ]);
    const vramUsed = readFirstSysfsNumber([
      path.join(devicePath, 'mem_info_vram_used'),
      path.join(devicePath, 'mem_info_vis_vram_used'),
    ]);
    const memoryUsagePercent = vramTotal > 0 && vramUsed >= 0 ? clampPercent((vramUsed / vramTotal) * 100) : null;

    return {
      available: true,
      provider: 'sysfs-amdgpu',
      status: 'AMD GPU sysfs metrics available',
      usagePercent: usagePercent === null ? null : clampPercent(usagePercent),
      memoryUsagePercent,
      memoryTotalBytes: vramTotal || null,
      memoryUsedBytes: vramUsed || null,
    };
  }

  return { available: false };
}

function readFirstSysfsNumber(paths = []) {
  for (const item of paths) {
    const value = readSysfsNumber(item);
    if (value !== null) return value;
  }
  return null;
}

function readSysfsNumber(filePath) {
  const text = readSysfsText(filePath);
  if (!text) return null;
  const value = Number(text);
  return Number.isFinite(value) ? value : null;
}

function readSysfsText(filePath) {
  try {
    return readFileSync(filePath, 'utf8').trim();
  } catch {
    return '';
  }
}

async function collectNpuMetrics() {
  const xrt = await runMetricCommand('xrt-smi', ['examine']);
  if (xrt.ok) {
    return {
      available: true,
      provider: 'xrt-smi',
      status: firstMeaningfulLine(xrt.stdout) || 'NPU visible',
      raw: trimMetricRaw(xrt.stdout),
    };
  }

  const deviceNodes = await runMetricCommand('sh', ['-lc', 'ls -1 /dev/accel /dev/dri/renderD* 2>/dev/null | head -20']);
  if (deviceNodes.ok && deviceNodes.stdout.trim()) {
    return {
      available: true,
      provider: 'device-node',
      status: 'accelerator device node visible',
      raw: trimMetricRaw(deviceNodes.stdout),
    };
  }

  return {
    available: false,
    provider: 'not-exposed',
    status: 'NPU metrics command or device node not available in backend runtime',
  };
}

function runMetricCommand(command, args = []) {
  return new Promise((resolve) => {
    execFile(command, args, { timeout: 2500, maxBuffer: 1024 * 1024 }, (error, stdout, stderr) => {
      if (error) {
        resolve({ ok: false, stdout: String(stdout || ''), stderr: String(stderr || ''), error: error.message });
        return;
      }
      resolve({ ok: true, stdout: String(stdout || ''), stderr: String(stderr || '') });
    });
  });
}

function parseGpuMetricText(provider, text = '') {
  const parsed = tryParseJson(text);
  const metricText = parsed ? JSON.stringify(parsed) : String(text || '');
  const usagePercent = firstMetricNumber(metricText, [
    /"gpu[_\s-]*(?:use|usage)[^"]*"\s*:\s*"?([0-9.]+)/i,
    /GPU use \(%\)[^0-9]*([0-9.]+)/i,
    /GPU\s*Activity[^0-9]*([0-9.]+)/i,
  ]);
  const memoryUsagePercent = firstMetricNumber(metricText, [
    /"vram[_\s-]*(?:use|usage|percent)[^"]*"\s*:\s*"?([0-9.]+)/i,
    /GPU Memory Allocated \(VRAM%\)[^0-9]*([0-9.]+)/i,
    /VRAM.*?([0-9.]+)\s*%/i,
  ]);

  return {
    available: true,
    provider,
    status: firstMeaningfulLine(text) || 'GPU metrics available',
    usagePercent: usagePercent === null ? null : clampPercent(usagePercent),
    memoryUsagePercent: memoryUsagePercent === null ? null : clampPercent(memoryUsagePercent),
    raw: trimMetricRaw(text),
  };
}

function tryParseJson(text) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function firstMetricNumber(text, patterns = []) {
  for (const pattern of patterns) {
    const result = String(text || '').match(pattern);
    if (!result) continue;
    const value = Number(result[1]);
    if (Number.isFinite(value)) return value;
  }
  return null;
}

function firstMeaningfulLine(text = '') {
  return String(text || '').split(/\r?\n/).map((line) => line.trim()).find(Boolean) || '';
}

function trimMetricRaw(text = '') {
  return String(text || '').trim().slice(0, 2000);
}

function round(value, digits = 2) {
  const number = Number(value);
  if (!Number.isFinite(number)) return 0;
  const factor = 10 ** digits;
  return Math.round(number * factor) / factor;
}

function clampPercent(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return 0;
  return Math.max(0, Math.min(100, round(number, 1)));
}

export function startCameraStatusProbe(store, options = {}) {
  const enabled = options.enabled ?? (isStrictProductionMode() && process.env.CAMERA_STREAM_PROBE_ENABLED !== 'false');
  if (!enabled || !store || typeof store.listCameras !== 'function' || typeof store.recordCameraStatus !== 'function') {
    return { stop() {} };
  }

  const intervalMs = Number(options.intervalMs || process.env.CAMERA_STREAM_PROBE_INTERVAL_MS || DEFAULT_CAMERA_PROBE_INTERVAL_MS);
  let running = false;
  const run = async () => {
    if (running) return;
    running = true;
    try {
      await runCameraStatusProbeOnce(store, options);
    } catch (error) {
      console.warn('[camera-probe] failed:', error instanceof Error ? error.message : error);
    } finally {
      running = false;
    }
  };

  void run();
  const timer = setInterval(run, Math.max(5000, intervalMs));
  timer.unref?.();
  return {
    stop() {
      clearInterval(timer);
    },
  };
}

export async function runCameraStatusProbeOnce(store, options = {}) {
  if (!store || typeof store.listCameras !== 'function' || typeof store.recordCameraStatus !== 'function') return [];
  const cameras = await store.listCameras();
  const probeEndpoint = options.probeEndpoint || probeAnyEndpoint;
  const timeoutMs = Number(options.timeoutMs || process.env.CAMERA_STREAM_PROBE_TIMEOUT_MS || DEFAULT_CAMERA_PROBE_TIMEOUT_MS);
  const requirePlayable = options.requirePlayable ?? (
    String(process.env.CAMERA_STATUS_REQUIRE_PLAYABLE ?? 'false').toLowerCase() !== 'false'
  );
  const now = options.now || (() => nowIso());
  const records = [];

  await Promise.all((cameras || []).map(async (camera) => {
    const targets = cameraProbeTargets(camera);
    if (!targets.length) return;
    const mustPassHttp = requirePlayable && targets.some((target) => target.kind === 'http');
    const attempts = [];
    let success = null;
    for (const target of targets) {
      const result = normalizeProbeResult(await probeEndpoint({ ...target, timeoutMs }));
      attempts.push({ target, result });
      if (result.ok && (!mustPassHttp || target.kind === 'http')) {
        success = { target, result };
        break;
      }
    }
    const target = success?.target || targets[0];
    const result = success?.result || attempts[attempts.length - 1]?.result || { ok: false, latencyMs: 0 };
    const detail = attempts.map(({ target: attemptedTarget, result: attemptedResult }) => {
      const label = attemptedTarget.kind === 'http' ? 'hls playlist' : 'rtsp tcp probe';
      return `${label} ${attemptedResult.ok ? 'ok' : 'failed'}`;
    }).join('; ');
    const record = {
      cameraId: camera.id,
      status: success ? 'online' : '\u672a\u63a5\u5165',
      source: 'stream-probe',
      detail,
      bitrate: success ? camera.bitrate || '' : '0Mbps',
      latency: success ? result.latencyMs : 0,
      heartbeatAt: now(),
      target: target.kind === 'http' ? target.url : `${target.host}:${target.port}`,
    };
    await store.recordCameraStatus(record);
    records.push(record);
  }));

  records.sort((a, b) => String(a.cameraId).localeCompare(String(b.cameraId)));
  return records;
}

function cameraProbeTargets(camera = {}) {
  const targets = [];
  const hlsCandidates = [
    camera.streams?.display?.hls,
    camera.displayStreamUrl,
  ].filter(Boolean);
  for (const candidate of hlsCandidates) {
    const value = String(candidate || '').trim();
    if (/^https?:\/\//i.test(value)) targets.push({ kind: 'http', url: value });
  }

  const candidates = [camera.streamUrl, camera.rtsp, camera.inferenceStreamUrl].filter(Boolean);
  for (const candidate of candidates) {
    const target = rtspTargetFromUrl(candidate);
    if (target) targets.push(target);
  }
  const host = String(camera.ip || '').trim();
  if (host) targets.push({ kind: 'tcp', host, port: 554 });
  return uniqueProbeTargets(targets);
}

function uniqueProbeTargets(targets = []) {
  const seen = new Set();
  const unique = [];
  for (const target of targets) {
    const key = target.kind === 'http' ? `http:${target.url}` : `tcp:${target.host}:${target.port}`;
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(target);
  }
  return unique;
}

function rtspTargetFromUrl(value) {
  try {
    const parsed = new URL(String(value));
    if (parsed.protocol !== 'rtsp:' && parsed.protocol !== 'rtsps:') return null;
    return {
      kind: 'tcp',
      host: parsed.hostname,
      port: Number(parsed.port || (parsed.protocol === 'rtsps:' ? 322 : 554)),
    };
  } catch {
    return null;
  }
}

function normalizeProbeResult(result) {
  if (typeof result === 'boolean') return { ok: result, latencyMs: 0 };
  return {
    ok: Boolean(result?.ok),
    latencyMs: Number(result?.latencyMs || 0),
  };
}

function probeTcpEndpoint({ host, port, timeoutMs }) {
  return new Promise((resolve) => {
    const startedAt = Date.now();
    const socket = net.connect({ host, port, timeout: timeoutMs });
    const finish = (ok) => {
      socket.removeAllListeners();
      socket.destroy();
      resolve({ ok, latencyMs: ok ? Date.now() - startedAt : 0 });
    };
    socket.once('connect', () => finish(true));
    socket.once('timeout', () => finish(false));
    socket.once('error', () => finish(false));
  });
}

function probeAnyEndpoint(target) {
  if (target?.kind === 'http') return probeHttpEndpoint(target);
  return probeTcpEndpoint(target);
}

async function probeHttpEndpoint({ url, timeoutMs }) {
  const startedAt = Date.now();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: 'GET',
      cache: 'no-store',
      signal: controller.signal,
    });
    if (!response.ok) return { ok: false, latencyMs: 0 };
    const text = await response.text();
    return {
      ok: !/\.m3u8(?:$|\?)/i.test(url) || text.includes('#EXTM3U'),
      latencyMs: Date.now() - startedAt,
    };
  } catch {
    return { ok: false, latencyMs: 0 };
  } finally {
    clearTimeout(timer);
  }
}

export function createStreamRelayManagerFromEnv(env = process.env) {
  const enabled = String(env.STREAM_RELAY_ENABLED ?? 'false').toLowerCase() !== 'false';
  const ffmpegBin = env.FFMPEG_BIN || 'ffmpeg';
  const rtmpBaseUrl = stripTrailingSlash(env.STREAM_RELAY_RTMP_BASE_URL || env.ZLMEDIAKIT_RTMP_URL || 'rtmp://zlmediakit/live');
  const videoCodec = env.STREAM_RELAY_VIDEO_CODEC || 'libx264';
  const restartDelayMs = Number(env.STREAM_RELAY_RESTART_DELAY_MS || 3000);
  const maxWidth = boundedNumber(env.STREAM_RELAY_MAX_WIDTH, 1920, 0, 7680);
  const fps = boundedNumber(env.STREAM_RELAY_FPS, 20, 1, 60);
  const gopSeconds = boundedNumber(env.STREAM_RELAY_GOP_SECONDS, 1, 1, 10);
  const crf = boundedNumber(env.STREAM_RELAY_CRF, 23, 16, 32);
  const x264Preset = env.STREAM_RELAY_X264_PRESET || 'ultrafast';
  const maxrate = env.STREAM_RELAY_MAXRATE || '3500k';
  const bufsize = env.STREAM_RELAY_BUFSIZE || '7000k';
  const vaapiDevice = env.STREAM_RELAY_VAAPI_DEVICE || '/dev/dri/renderD128';
  const inputTimeoutUs = boundedNumber(env.STREAM_RELAY_INPUT_TIMEOUT_US, 0, 0, 120000000);
  return new FfmpegStreamRelayManager({
    enabled,
    ffmpegBin,
    rtmpBaseUrl,
    videoCodec,
    restartDelayMs,
    maxWidth,
    fps,
    gopSeconds,
    crf,
    x264Preset,
    maxrate,
    bufsize,
    vaapiDevice,
    inputTimeoutUs,
  });
}

class FfmpegStreamRelayManager {
  constructor(options = {}) {
    this.enabled = Boolean(options.enabled);
    this.ffmpegBin = options.ffmpegBin || 'ffmpeg';
    this.rtmpBaseUrl = stripTrailingSlash(options.rtmpBaseUrl || 'rtmp://zlmediakit/live');
    this.videoCodec = options.videoCodec || 'libx264';
    this.restartDelayMs = Number(options.restartDelayMs || 3000);
    this.maxWidth = boundedNumber(options.maxWidth, 1920, 0, 7680);
    this.fps = boundedNumber(options.fps, 20, 1, 60);
    this.gopSeconds = boundedNumber(options.gopSeconds, 1, 1, 10);
    this.crf = boundedNumber(options.crf, 23, 16, 32);
    this.x264Preset = options.x264Preset || 'ultrafast';
    this.maxrate = options.maxrate || '3500k';
    this.bufsize = options.bufsize || '7000k';
    this.vaapiDevice = options.vaapiDevice || '/dev/dri/renderD128';
    this.inputTimeoutUs = boundedNumber(options.inputTimeoutUs, 0, 0, 120000000);
    this.relays = new Map();
  }

  async syncCameras(cameras = []) {
    const activeIds = new Set();
    for (const camera of cameras) {
      if (!camera?.id) continue;
      activeIds.add(String(camera.id).toUpperCase());
      await this.syncCamera(camera);
    }
    for (const id of [...this.relays.keys()]) {
      if (!activeIds.has(id)) this.removeCamera(id);
    }
  }

  syncCamera(camera = {}) {
    if (!this.enabled) return;
    const id = String(camera.id || '').trim().toUpperCase();
    const source = rtspRelaySource(camera);
    if (!id || !source) {
      if (id) this.removeCamera(id);
      return;
    }

    const existing = this.relays.get(id);
    if (existing?.source === source && existing.child && !existing.child.killed) return;

    this.removeCamera(id);
    const relay = { id, source, child: null, restartTimer: null, stopping: false };
    this.relays.set(id, relay);
    this.startRelay(relay);
  }

  removeCamera(cameraId) {
    const id = String(cameraId || '').trim().toUpperCase();
    const relay = this.relays.get(id);
    if (!relay) return;
    relay.stopping = true;
    if (relay.restartTimer) clearTimeout(relay.restartTimer);
    if (relay.child && !relay.child.killed) relay.child.kill('SIGTERM');
    this.relays.delete(id);
  }

  stopAll() {
    for (const id of [...this.relays.keys()]) this.removeCamera(id);
  }

  startRelay(relay) {
    if (relay.stopping || !this.relays.has(relay.id)) return;
    const target = `${this.rtmpBaseUrl}/${relay.id}`;
    const args = this.buildFfmpegArgs(relay.source, target);
    relay.child = spawn(this.ffmpegBin, args, { stdio: ['ignore', 'ignore', 'pipe'] });
    relay.child.stderr?.on('data', (chunk) => {
      const message = String(chunk || '').trim();
      if (message) console.warn(`[stream-relay] ${relay.id}: ${message}`);
    });
    relay.child.on('error', (error) => {
      console.warn(`[stream-relay] ${relay.id} failed to start: ${error?.message || error}`);
    });
    relay.child.on('exit', (code, signal) => {
      relay.child = null;
      if (relay.stopping || !this.relays.has(relay.id)) return;
      console.warn(`[stream-relay] ${relay.id} exited code=${code ?? ''} signal=${signal ?? ''}; restarting`);
      relay.restartTimer = setTimeout(() => this.startRelay(relay), this.restartDelayMs);
    });
  }

  buildFfmpegArgs(source, target) {
    const codec = String(this.videoCodec).toLowerCase();
    const args = [
      '-nostdin',
      '-hide_banner',
      '-loglevel',
      'warning',
      '-rtsp_transport',
      'tcp',
      '-fflags',
      '+genpts+nobuffer',
      '-flags',
      'low_delay',
      '-analyzeduration',
      '1000000',
      '-probesize',
      '1000000',
    ];
    if (this.inputTimeoutUs > 0) {
      args.push('-rw_timeout', String(this.inputTimeoutUs));
    }

    if (codec === 'h264_vaapi') {
      args.push(
        '-hwaccel',
        'vaapi',
        '-hwaccel_device',
        this.vaapiDevice,
        '-hwaccel_output_format',
        'vaapi',
      );
    }

    args.push('-i', source, '-an');

    if (codec === 'copy') {
      args.push('-c:v', 'copy');
    } else if (codec === 'libx264') {
      const gop = Math.max(1, Math.round(this.fps * this.gopSeconds));
      if (this.maxWidth > 0) {
        args.push('-vf', `scale=w='min(${Math.round(this.maxWidth)},iw)':h=-2`);
      }
      args.push(
        '-r',
        String(this.fps),
        '-c:v',
        'libx264',
        '-preset',
        this.x264Preset,
        '-tune',
        'zerolatency',
        '-pix_fmt',
        'yuv420p',
        '-profile:v',
        'main',
        '-g',
        String(gop),
        '-keyint_min',
        String(gop),
        '-sc_threshold',
        '0',
        '-bf',
        '0',
        '-refs',
        '1',
        '-crf',
        String(this.crf),
        '-force_key_frames',
        `expr:gte(t,n_forced*${this.gopSeconds})`,
      );
      if (this.maxrate) args.push('-maxrate', this.maxrate);
      if (this.bufsize) args.push('-bufsize', this.bufsize);
    } else if (codec === 'h264_vaapi') {
      const gop = Math.max(1, Math.round(this.fps * this.gopSeconds));
      if (this.maxWidth > 0) {
        args.push('-vf', `scale_vaapi=w='min(${Math.round(this.maxWidth)},iw)':h=-2:format=nv12`);
      } else {
        args.push('-vf', 'scale_vaapi=format=nv12');
      }
      args.push(
        '-r',
        String(this.fps),
        '-c:v',
        'h264_vaapi',
        '-profile:v',
        'main',
        '-g',
        String(gop),
        '-bf',
        '0',
        '-qp',
        String(Math.max(18, Math.min(32, this.crf))),
      );
      if (this.maxrate) args.push('-maxrate', this.maxrate);
      if (this.bufsize) args.push('-bufsize', this.bufsize);
    } else {
      args.push('-c:v', this.videoCodec);
    }

    args.push(
      '-max_muxing_queue_size',
      '1024',
      '-flvflags',
      'no_duration_filesize',
      '-f',
      'flv',
      target,
    );
    return args;
  }
}

function rtspRelaySource(camera = {}) {
  const candidates = [
    camera.streamUrl,
    camera.rtsp,
    camera.sourceStreamUrl,
    camera.streams?.display?.source,
  ];
  for (const candidate of candidates) {
    const value = String(candidate || '').trim();
    if (/^rtsps?:\/\//i.test(value)) return value;
  }
  return '';
}

function stripTrailingSlash(value = '') {
  return String(value).replace(/\/+$/, '');
}

function boundedNumber(value, fallback, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(max, Math.max(min, number));
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);

if (isMain) {
  bootSecurityCheck();
  const store = await createStoreFromEnv();
  const integrations = await configureIntegrationsFromEnv();
  const cameraProbe = startCameraStatusProbe(store);
  const streamRelay = createStreamRelayManagerFromEnv();
  await streamRelay.syncCameras(await store.listCameras());
  const wvpSync = createWvpSyncFromEnv();
  if (wvpSync) {
    wvpSync.start(store).catch((err) => console.warn('[wvp-sync] start failed:', err?.message || err));
    console.log('[wvp-sync] DEVICE_SYNC_DRIVER=wvp 已启用，开始从 WVP-pro 拉取 GB28181 通道');
  }
  const integrationSummary = [
    `audit=${integrations.audit?.driver || 'noop'}`,
    `metrics=${integrations.metrics?.driver || 'noop'}`,
    `eventBus=${integrations.bus?.driver || 'memory'}`,
    `deviceSync=${wvpSync?.driver || 'noop'}`,
  ].join(' ');
  const stopRuntimeWorkers = () => {
    cameraProbe.stop();
    streamRelay.stopAll();
    if (wvpSync) wvpSync.stop().catch(() => {});
    if (integrations.bus?.stop) integrations.bus.stop().catch(() => {});
  };
  process.once('SIGINT', stopRuntimeWorkers);
  process.once('SIGTERM', stopRuntimeWorkers);
  createApp({ store, streamRelay }).listen(defaultPort, () => {
    console.log(`River-Watch backend listening on http://127.0.0.1:${defaultPort} store=${store.mode} [${integrationSummary}]`);
  });
}
