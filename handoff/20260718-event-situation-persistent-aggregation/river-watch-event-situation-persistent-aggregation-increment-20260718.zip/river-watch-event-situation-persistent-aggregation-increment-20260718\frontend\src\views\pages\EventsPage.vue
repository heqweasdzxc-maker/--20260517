<script setup lang="ts">
import { computed, ref, watch } from 'vue';
import { Activity, AlertTriangle, ArrowRight, CheckCircle2, CircleDot, Clock3, CloudUpload, Download, FileCheck2, Pause, Play, Plus, RefreshCw, RotateCcw, ScanLine, Send, ShieldCheck, SlidersHorizontal, TimerReset, Workflow } from '@lucide/vue';
import KpiCard from '../../components/KpiCard.vue';
import RiskTrendChart from '../../components/RiskTrendChart.vue';
import StatusBadge from '../../components/StatusBadge.vue';
import StreamPlayer from '../../components/StreamPlayer.vue';
import TencentMapPanel from '../../components/TencentMapPanel.vue';
import VideoTile from '../../components/VideoTile.vue';
import { useWorkspace } from '../../composables/useWorkspace';
import { eventQueueRows, summarizeEventQueue, type EventQueueRow } from '../../services/eventGroups';

const {
  platform,
  alarmDrawer,
  operationDialog,
  operationAction,
  deviceDialog,
  deviceDialogMode,
  deviceSubmitting,
  cameraPreviewDialog,
  cameraPreviewMode,
  cameraPreviewId,
  cameraTypeOptions,
  protocolOptions,
  inferenceNodeOptions,
  deviceForm,
  page,
  pageTitle,
  selectedAlarm,
  selectedCamera,
  mainTrend,
  playbackPageSize,
  playbackPage,
  playbackPlaying,
  playbackProgress,
  playbackNotice,
  templateCoverage,
  algorithmAverageLatency,
  eventKpis,
  eventTypeStats,
  eventStatusStats,
  pageRecordCount,
  workOrderStats,
  latestEvidenceVerification,
  deviceRows,
  playbackEvents,
  playbackTotalPages,
  pagedPlaybackEvents,
  playbackCurrentTime,
  selectedAlarmWorkOrder,
  selectedAlarmCamera,
  selectedAlarmDeviceName,
  selectedAlarmUavTask,
  selectedAlarmEvidence,
  previewCamera,
  cameraPreviewTitle,
  cameraNameById,
  openAlarm,
  openPlaybackAlarm,
  alarmDeviceName,
  alarmReviewTitle,
  deviceNameById,
  workOrderDisplayTitle,
  uavTaskDisplayTitle,
  evidenceBundleDisplayName,
  openOperation,
  handleOperationDone,
  openCreateDevice,
  openEditDevice,
  resetDeviceForm,
  submitDeviceForm,
  deleteDevice,
  devicePayloadFromForm,
  parseCoordinate,
  cameraTypeOf,
  cameraCoordinate,
  streamUrlOf,
  channelNumber,
  reviewSelectedAlarm,
  findCameraAlarm,
  openCameraAlarm,
  openCameraMap,
  openCameraPreview,
  handleCameraAction,
  openAlarmRow,
  reviewAlarmRow,
  nextWorkOrderAction,
  advanceWorkOrder,
  remindWorkOrder,
  createEvidenceBundle,
  verifyEvidenceBundle,
  downloadEvidenceBundle,
  createImportJob,
  reanalyzeImportJob,
  convertImportJobToAlarm,
  deleteImportJob,
  createStoragePolicy,
  protectStoragePolicy,
  createReportTask,
  downloadReport,
  createUserAccount,
  toggleUserStatus,
  saveRolePermissions,
  searchAuditLogs,
  exportAuditLogs,
  verifyOps,
  opsTone,
  resetPlayback,
  startPlayback,
  pausePlayback,
  locateSelectedAlarm,
  importStatusTone,
  goDiagnostics,
  handleMapCameraSelect,
  stepTone,
  ptsToProgress,
  progressToTime,
  timecodeToSeconds,
  severityTone,
  statusTone,
  progressOfWorkOrder,
  isSlaRisk,
} = useWorkspace();

const EVENT_PAGE_SIZE = 10;
const eventPage = ref(1);
const eventQueueRecords = computed<EventQueueRow[]>(() => eventQueueRows(platform.events || [], platform.workOrders));
const eventTotalPages = computed(() => Math.max(1, Math.ceil(eventQueueRecords.value.length / EVENT_PAGE_SIZE)));
const pagedEventQueue = computed(() => {
  const start = (eventPage.value - 1) * EVENT_PAGE_SIZE;
  return eventQueueRecords.value.slice(start, start + EVENT_PAGE_SIZE);
});
const eventQueueKpis = computed(() => {
  const summary = summarizeEventQueue(platform.events || [], platform.workOrders);

  return [
    { label: '队列事件', value: `${summary.openCount}`, hint: '未关闭事件生命周期', tone: 'blue' },
    { label: '待研判', value: `${summary.pendingCount}`, hint: '需要人工确认', tone: 'red' },
    { label: '去重命中', value: `${summary.dedupeHits}`, hint: '原始告警已归入事件', tone: 'amber' },
    { label: '处置闭环中', value: `${summary.activeWorkOrders}`, hint: '已派单未归档', tone: 'green' },
  ];
});
const eventQueueTypeStats = computed(() => {
  const counts = eventQueueRecords.value.reduce<Record<string, number>>((acc, record) => {
    acc[record.type] = (acc[record.type] || 0) + 1;
    return acc;
  }, {});
  const max = Math.max(1, ...Object.values(counts));

  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .map(([name, count]) => ({ name, count, percentage: Math.round((count / max) * 100) }));
});
const eventQueueStatusStats = computed(() => {
  const stages = ['待研判', '待派单', '处置中', '复核中'] as const;
  return stages.map((status) => ({
    status,
    count: eventQueueRecords.value.filter((record) => record.stage === status).length,
  }));
});

watch(eventTotalPages, (totalPages) => {
  if (eventPage.value > totalPages) eventPage.value = totalPages;
});

async function handleEventAction(record: EventQueueRow) {
  if (record.workOrder && record.workOrder.status !== '归档') {
    await advanceWorkOrder(record.workOrder);
    return;
  }
  openAlarm(record.reviewAlarmId);
}
</script>

<template>
  <section class="page-stack">
    <div class="event-kpi-grid">
      <article v-for="kpi in eventQueueKpis" :key="kpi.label" class="panel event-kpi" :class="`tone-${kpi.tone}`">
        <span>{{ kpi.label }}</span>
        <strong>{{ kpi.value }}</strong>
        <small>{{ kpi.hint }}</small>
      </article>
    </div>
    <div class="event-layout">
      <section class="panel">
        <div class="panel-title">
          <div>
            <h2>事件研判队列</h2>
          </div>
          <StatusBadge label="分级时间窗归集" tone="amber" />
        </div>
        <div class="table-card event-table" :data-page-size="EVENT_PAGE_SIZE" :data-total="eventQueueRecords.length">
          <table>
            <colgroup>
              <col class="event-col-name" />
              <col class="event-col-device" />
              <col class="event-col-level" />
              <col class="event-col-time" />
              <col class="event-col-time" />
              <col class="event-col-count" />
              <col class="event-col-duration" />
              <col class="event-col-status" />
              <col class="event-col-workorder" />
              <col class="event-col-action" />
            </colgroup>
            <thead><tr><th>事件</th><th>设备名称</th><th>等级</th><th>首次发生</th><th>最近报警</th><th>次数</th><th>持续时间</th><th>状态</th><th>工单闭环</th><th>动作</th></tr></thead>
            <tbody>
              <tr v-for="record in pagedEventQueue" :key="record.id">
                <td :title="`${record.type} · ${record.id}`"><strong>{{ record.type }}</strong><small> · {{ record.id }}</small></td>
                <td :title="record.cameraName">{{ record.cameraName }}</td>
                <td><StatusBadge :label="record.severity" :tone="severityTone(record.severity)" /></td>
                <td class="event-time-cell" :title="record.firstOccurredText">{{ record.firstOccurredText }}</td>
                <td class="event-time-cell" :title="record.latestOccurredText">{{ record.latestOccurredText }}</td>
                <td class="event-count-cell">{{ record.occurrenceCount }} 次</td>
                <td :title="record.durationText">{{ record.durationText }}</td>
                <td><StatusBadge :label="record.stage" :tone="record.stageTone" /></td>
                <td :title="record.workOrder ? `${record.workOrder.id} / ${record.workOrder.status}` : '研判后进入工单闭环'">{{ record.workOrder ? `${record.workOrder.id} / ${record.workOrder.status}` : '研判后进入工单闭环' }}</td>
                <td><el-button size="small" type="primary" plain @click="handleEventAction(record)">{{ record.actionLabel }}</el-button></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div v-if="eventQueueRecords.length > EVENT_PAGE_SIZE" class="event-pager">
          <span>每页 {{ EVENT_PAGE_SIZE }} 条，共 {{ eventQueueRecords.length }} 条</span>
          <el-pagination
            v-model:current-page="eventPage"
            background
            small
            layout="prev, pager, next"
            :page-size="EVENT_PAGE_SIZE"
            :total="eventQueueRecords.length"
          />
        </div>
      </section>
      <section class="event-analysis-row">
        <article class="panel event-side-card">
          <div class="panel-title compact">
            <h2>事件分布与研判状态</h2>
          </div>
          <div class="event-type-list">
            <div v-for="item in eventQueueTypeStats" :key="item.name">
              <span>{{ item.name }}</span>
              <i><b :style="{ width: `${item.percentage}%` }" /></i>
              <strong>{{ item.count }}</strong>
            </div>
          </div>
        </article>
        <article class="panel event-side-card">
          <div class="panel-title compact">
            <h2>研判状态</h2>
          </div>
          <div class="event-stage-grid">
            <div v-for="item in eventQueueStatusStats" :key="item.status">
              <strong>{{ item.count }}</strong>
              <span>{{ item.status }}</span>
            </div>
          </div>
        </article>
      </section>
    </div>
  </section>
</template>
