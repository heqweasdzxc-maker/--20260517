# River Watch 事件态势持久归集增量包

目标服务器：`192.168.2.167`

本包只处理事件态势队列，不修改 AI worker、模型、采样频率、GPU 调度、视频流或其他菜单功能。

## 业务标准

- 所有原始异常告警继续逐条进入告警中心并保留，不再被事件去重吞并。
- 事件态势按“设备 + 异常类型”建立一个开放事件生命周期。
- 开放期间持续更新首次发生、最近报警、次数、持续时间、最高置信度和最高等级。
- 只有在研判对话框点击“忽略”或“已处理”后，当前事件才关闭并进入工单闭环。
- 关闭后再次出现相同设备和异常类型时，新建事件，不复活历史事件。
- 历史归集通过 `/api/v1/events?history=true` 查询。

## 界面调整

- 事件研判队列使用 10 个稳定列，首次发生和最近报警均显示完整日期时间。
- 内容保持单行，长文本省略并提供悬浮提示；表格内部横向滚动，不撑宽整个页面。
- 首列与操作列固定，便于宽表连续研判。
- 告警研判对话框维持 13 项信息，并按三列显示；新增首次发生、最近报警和归集统计。

## 部署

```bash
cd /home/ai-river
sha256sum -c river-watch-event-situation-persistent-aggregation-increment-20260718.zip.sha256
rm -rf river-watch-event-situation-persistent-aggregation-increment-20260718
unzip -o river-watch-event-situation-persistent-aggregation-increment-20260718.zip
cd river-watch-event-situation-persistent-aggregation-increment-20260718
sha256sum -c SHA256SUMS
python3 tests/test_package.py
bash -n scripts/*.sh
chmod +x scripts/*.sh
sudo -v

LOG="/home/ai-river/event-situation-aggregation-apply-$(date +%Y%m%d-%H%M%S).log"
nohup sudo -n env APP_DIR=/home/ai-river/river-watch \
  bash scripts/apply-event-situation-persistent-aggregation-20260718.sh \
  >"$LOG" 2>&1 &
echo "pid=$!"
echo "log=$LOG"
tail -f "$LOG"
```

日志以 `VERIFY OK`、`DONE` 结束才表示部署完成。

## 复核

```bash
cd /home/ai-river/river-watch-event-situation-persistent-aggregation-increment-20260718
sudo env APP_DIR=/home/ai-river/river-watch \
  bash scripts/verify-event-situation-persistent-aggregation-20260718.sh
```

## 回滚

```bash
cd /home/ai-river/river-watch-event-situation-persistent-aggregation-increment-20260718
sudo env APP_DIR=/home/ai-river/river-watch \
  bash scripts/rollback-event-situation-persistent-aggregation-20260718.sh
```

回滚保留已形成的归集表数据，避免审计数据丢失；旧版本后端不会读取这些表。
