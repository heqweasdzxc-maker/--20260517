export type Severity = '提示' | '一般' | '严重' | '紧急';
export type AlarmStatus = '待研判' | '已确认' | '已派单' | '误报' | '已归档';
export type AlarmReviewAction = AlarmStatus | '忽略' | '已处理';
export type DeviceStatus = '在线' | '离线' | '链路异常' | '未接入' | '维护中';
export type WorkOrderStatus = '派单' | '处置' | '复核' | '归档';
export type DiagnosticState = 'ok' | 'warning' | 'error' | 'idle';
export type VideoTileAction = 'alarm' | 'map' | 'zoom' | 'fullscreen';

export interface Detection {
  id: string;
  label: string;
  confidence: number;
  severity: Severity;
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface Camera {
  id: string;
  name: string;
  cameraType?: '固定枪机' | '云台球机' | '全景枪球' | '热成像';
  group: '排水口监测' | '厌氧池监测' | '结构缺陷监测';
  scene: '排水口' | '厌氧池' | '墙体裂痕' | '地面水渍';
  protocol: 'GB28181' | 'RTSP' | 'Onvif';
  ip: string;
  streamUrl?: string;
  displayStreamUrl?: string;
  inferenceStreamUrl?: string;
  inferenceSampleFps?: number;
  inferenceModel?: string;
  streams?: {
    display?: {
      source?: string;
      webrtc?: string;
      flv?: string;
      rtmp?: string;
      hls?: string;
    };
    inference?: {
      rtsp?: string;
      sampleFps?: number;
      node?: string;
      model?: string;
    };
    metadata?: {
      post?: string;
      overlay?: string;
      coordinateSpace?: string;
    };
  };
  longitude?: number;
  latitude?: number;
  ptz: boolean;
  node: string;
  templateId: string;
  status: DeviceStatus;
  statusSource?: string;
  statusDetail?: string;
  lastHeartbeatAt?: string;
  bitrate: string;
  latency: number;
  location: [number, number];
  detections: Detection[];
}

export interface Alarm {
  id: string;
  cameraId: string;
  cameraName: string;
  type: string;
  severity: Severity;
  confidence: number;
  status: AlarmStatus;
  time: string;
  pts: string;
  owner: string;
  dedupeCount: number;
  snapshot: string;
  reviewResult?: '忽略' | '误报' | '已确认' | string;
  dispatchId?: string;
  dispatchedAt?: string;
  createdAt?: string;
  archiveReason?: string;
  archivedAt?: string;
  updatedAt?: string;
}

export interface AggregateEvent {
  id: string;
  dedupeKey: string;
  cameraId: string;
  cameraName: string;
  type: string;
  severity: Severity;
  status: '待研判' | '已忽略' | '已处理';
  firstAlarmId: string;
  latestAlarmId: string;
  firstOccurredAt: string;
  latestOccurredAt: string;
  occurrenceCount: number;
  firstConfidence: number;
  latestConfidence: number;
  maxConfidence: number;
  reviewAction?: '忽略' | '已处理' | '';
  closedAt?: string;
  workOrderId?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface WorkOrder {
  id: string;
  alarmId: string;
  title: string;
  assignee: string;
  status: WorkOrderStatus;
  slaHours: number;
  elapsedHours: number;
  priority: Severity;
  slaState?: '正常' | '临期' | '超时' | '已闭环';
  escalated?: boolean;
  reminderCount?: number;
  lastAction?: string;
  createdAt?: string;
  confirmedAt?: string;
  acceptedAt?: string;
  lastReminderAt?: string;
  startedAt?: string;
  reviewSubmittedAt?: string;
  archivedAt?: string;
  updatedAt?: string;
  completedAt?: string;
  evidenceBundleId?: string;
  timeline?: Array<{
    time: string;
    from: WorkOrderStatus;
    to: WorkOrderStatus;
    operator: string;
    note: string;
  }>;
}

export interface TemplateProfile {
  id: string;
  name: string;
  scene: string;
  version: string;
  channels: number;
  algorithms: string[];
  fps: string;
  dedupe: string;
  rollout: '全量' | '灰度' | '草稿';
}

export interface AlgorithmModel {
  id: string;
  name: string;
  family: string;
  version: string;
  format: 'ONNX' | 'TensorRT' | 'Ryzen AI';
  node: string;
  fps: number;
  latency: number;
  utilization: number;
  accuracy: number;
  sourceFile?: string;
  fileSize?: number;
  importedAt?: string;
  inputSize?: number;
  confidence?: number;
  iou?: number;
  labels?: string;
  runtime?: string;
  status?: '待配置' | '待下发' | '运行中' | '已停用' | '已停止' | '文件缺失';
  runtimeChannels?: string[];
  runtimeOnlineChannels?: number;
}

export interface UavTask {
  id: string;
  name: string;
  type: string;
  status: string;
  dock: string;
  eta: string;
  relatedAlarm?: string;
  mode?: 'auto' | 'manual';
  dockStatus?: string;
  dockWeather?: string;
  droneId?: string;
  battery?: number;
  signal?: number;
  altitude?: number;
  speed?: number;
  distance?: number;
  progress?: number;
  flightStage?: string;
  targetCameraId?: string;
  operator?: string;
  videoReturn?: string;
  flightPath?: Array<{
    x: number;
    y: number;
    label: string;
  }>;
}

export type UavAssetStatus = '待命' | '执行中' | '充电中' | '维护中' | '离线' | '故障';

export interface UavAsset {
  id: string;
  name: string;
  assetType: '无人机' | '无人机+机巢';
  vendor: 'DJI' | 'Other';
  model: string;
  dockName: string;
  dockSn?: string;
  droneSn?: string;
  status: UavAssetStatus;
  mode: 'auto' | 'manual';
  longitude?: number;
  latitude?: number;
  location?: [number, number];
  battery?: number;
  signal?: number;
  altitude?: number;
  speed?: number;
  dockStatus?: string;
  dockWeather?: string;
  rtkStatus?: string;
  firmware?: string;
  payload?: string;
  videoReturn?: string;
  activeTaskId?: string;
  relatedAlarm?: string;
  lastHeartbeatAt?: string;
}

export interface EvidenceBundle {
  id: string;
  alarmId: string;
  workOrderId?: string;
  name: string;
  materials: number;
  hash: string;
  manifestHash?: string;
  sealedAt: string;
  status: '已固化' | '组卷中' | '待校验';
  materialsList?: EvidenceMaterial[];
  lastVerify?: EvidenceVerifyResult;
  lastDownloadAt?: string;
  trace?: Array<{
    step: string;
    object: string;
    time: string;
    operator: string;
  }>;
}

export interface EvidenceMaterial {
  id: string;
  type: string;
  name: string;
  source: string;
  operator: string;
  collectedAt: string;
  size: number;
  sha256: string;
}

export interface EvidenceVerifyResult {
  ok: boolean;
  verifiedAt: string;
  manifestHash: string;
  expectedHash: string;
  materialResults: Array<{
    id: string;
    name: string;
    expected: string;
    actual: string;
    ok: boolean;
  }>;
}

export interface ImportJob {
  id: string;
  source: string;
  type: '视频' | '图片';
  status: '排队中' | '分析中' | '已完成' | '已转告警' | '失败';
  result: string;
  confidence: number;
  algorithm?: string;
  cameraId?: string;
  fileHash?: string;
  objectKey?: string;
  createdAt?: string;
  updatedAt?: string;
  finishedAt?: string;
  analysisVersion?: number;
  relatedAlarmId?: string;
  relatedWorkOrderId?: string;
  analysis?: {
    model: string;
    detectionType: string;
    severity: Severity;
    frameCount: number;
    samplePts: string;
    durationMs: number;
    finishedAt?: string;
  };
  trace?: Array<{
    step: string;
    object: string;
    time: string;
    operator: string;
  }>;
}

export interface StorageTier {
  id?: string;
  tier?: string;
  name: string;
  usage: number;
  quota: string;
  policy: string;
  protectedEvidence: boolean;
  retentionDays?: number;
  alertThreshold?: number;
  lifecycle?: string;
  quotaBytes?: number;
  retentionMode?: 'fifo' | string;
  recordingOwner?: string;
  rawVideoStoredHere?: boolean;
  recordingPathPolicy?: string;
  managedTables?: string[];
  updatedAt?: string;
}

export interface ReportMetric {
  id?: string;
  name: string;
  value: string;
  change: string;
  trend: number[];
  updatedAt?: string;
}

export interface ReportTask {
  id: string;
  name: string;
  type: string;
  format: string;
  schedule: string;
  status: '排队中' | '生成中' | '已生成' | '失败';
  generatedAt?: string;
  fileUrl?: string;
  metrics?: Record<string, number>;
}

export interface UserAccount {
  id: string;
  name: string;
  role: string;
  org: string;
  status: '启用' | '停用';
  scope: string;
  lastLoginAt?: string;
  mfa?: boolean;
  updatedAt?: string;
}

export interface RolePermission {
  roleId: string;
  roleName: string;
  dataScope: string;
  permissions: string[];
  menus?: string[];
  buttons?: string[];
  updatedAt?: string;
}

export interface AuditLog {
  id: string;
  time: string;
  operator: string;
  action: string;
  object: string;
  result: '成功' | '失败';
}

export interface LogSearchJob {
  id: string;
  query: string;
  result?: string;
  operator?: string;
  action?: string;
  resultCount: number;
  status: '排队中' | '已完成' | '失败';
  retentionMonths: number;
  archiveMonths: number;
  integrityHash: string;
  createdAt: string;
}

export interface ExportTask {
  id: string;
  status: string;
  module?: string;
  moduleName?: string;
  scope?: string;
  format?: string;
  createdAt?: string;
}

export interface AiRuntimeEvent {
  id: string;
  alarmId?: string;
  cameraId?: string;
  receivedAt?: string;
  retryCount?: number;
  retryStatus?: string;
  payload?: any;
  result?: {
    alarm?: Alarm;
    workOrder?: WorkOrder | null;
  };
}

export interface OperationTask {
  id: string;
  moduleName: string;
  actionName: string;
  status: string;
  createdAt?: string;
}

export interface OpsCheck {
  name: string;
  passed: boolean;
  evidence: string;
}

export interface OpsEvidenceItem {
  label: string;
  value: string;
}

export interface OpsRun {
  id: string;
  type: 'backup' | 'restore' | 'offline-images' | 'hardening' | string;
  name: string;
  status: '验收通过' | '待复核' | string;
  summary: string;
  manifestHash: string;
  checks: OpsCheck[];
  evidence: OpsEvidenceItem[];
  createdAt: string;
}

export interface OpsScriptInfo {
  relativePath: string;
  expected: boolean;
  exists: boolean;
  visibility: string;
  size: number;
  updatedAt: string;
}

export interface OpsStatus {
  checkedAt: string;
  targetHost: string;
  store: string;
  counts: Record<string, number>;
  scripts: Record<string, OpsScriptInfo>;
  backup: { expectedArchive: string; expectedManifest: string; lastRun?: OpsRun | null };
  restore: { drillMode: string; expectedReport: string; lastRun?: OpsRun | null };
  offlineImages: { archive: string; manifest: string; images: string[]; lastRun?: OpsRun | null };
  hardening: { status: string; checks: OpsCheck[] };
  runs: OpsRun[];
}

export interface RuntimeConfigItem<T = any> {
  key: string;
  group: string;
  value: T;
  updatedAt?: string;
}

export interface AiWorkerRuntime {
  id: string;
  name: string;
  status: string;
  model: string;
  runtime?: string;
  channels?: string[];
  fps?: number;
  latencyMs?: number;
}

export interface OperationRouteConfig {
  path: string;
  moduleName: string;
  actionName: string;
  status: string;
}

export type OperationFieldType = 'input' | 'textarea' | 'select' | 'radio' | 'checkbox' | 'switch' | 'dateRange' | 'number';
export type OperationFieldValue = string | number | boolean | string[];

export interface OperationFieldOption {
  label: string;
  value: string;
}

export interface OperationFieldConfig {
  key: string;
  label: string;
  type: OperationFieldType;
  defaultValue?: OperationFieldValue;
  placeholder?: string;
  options?: OperationFieldOption[];
  min?: number;
  max?: number;
  wide?: boolean;
}

export interface OperationProfileConfig {
  entity: string;
  api: string;
  owner: string;
  filterFields: OperationFieldConfig[];
  createFields: OperationFieldConfig[];
  exportScopes: string[];
  exportIncludes: string[];
}

export interface OperationDialogSpecConfig {
  title: string;
  eyebrow: string;
  description: string;
  fields: OperationFieldConfig[];
  confirmText: string;
  summary: string[];
}

export interface PlaybackClip {
  id: string;
  cameraId: string;
  cameraName?: string;
  alarmId: string | null;
  from: string;
  to: string;
  note?: string;
  status: string;
  fileHash: string;
  evidenceBundleId?: string;
  createdAt: string;
}

export interface NotificationRecord {
  id: string;
  alarmId: string | null;
  ruleId: string | null;
  title: string;
  content: string;
  severity: Severity;
  channel: string;
  receiver: string;
  status: '排队中' | '已送达' | '待配置' | '发送失败';
  attempts: number;
  receipt: { state: '待确认' | '已确认'; at: string | null };
  lastError: string | null;
  deliveredAt?: string | null;
  createdAt: string;
  mergeKey?: string | null;
  mergeWindowMinutes?: number;
  mergedCount?: number;
  mergedAlarmIds?: string[];
  firstAlarmAt?: string;
  lastAlarmAt?: string;
  alarmType?: string | null;
  cameraId?: string | null;
  cameraName?: string | null;
}

export interface NotifyRule {
  id: string;
  severity: Severity;
  channels: string[];
  receiver: string;
  enabled: boolean;
  quietHours: string | null;
  updatedAt: string;
}

export interface NotifyChannelStatus {
  channel: string;
  builtin: boolean;
  configured: boolean;
  envKey: string | null;
  endpoint: string | null;
}

export interface PlatformSnapshot {
  cameras: Camera[];
  alarms: Alarm[];
  events?: AggregateEvent[];
  workOrders: WorkOrder[];
  templates: TemplateProfile[];
  algorithms: AlgorithmModel[];
  uavTasks: UavTask[];
  uavAssets: UavAsset[];
  evidenceBundles: EvidenceBundle[];
  importJobs: ImportJob[];
  storageTiers: StorageTier[];
  reportMetrics: ReportMetric[];
  reportTasks?: ReportTask[];
  users: UserAccount[];
  rolePermissions?: RolePermission[];
  exportTasks?: ExportTask[];
  logs: AuditLog[];
  logSearchJobs?: LogSearchJob[];
  opsRuns?: OpsRun[];
  operationTasks?: OperationTask[];
  notifications?: NotificationRecord[];
  notifyRules?: NotifyRule[];
  playbackClips?: PlaybackClip[];
  aiEvents?: AiRuntimeEvent[];
  navItems: NavItem[];
  diagnostics: { healthy: DiagnosticStep[]; failed: DiagnosticStep[] };
  aiWorkers: AiWorkerRuntime[];
  operationRoutes: OperationRouteConfig[];
  operationProfiles: Record<string, OperationProfileConfig>;
  operationSpecialSpecs: Record<string, OperationDialogSpecConfig>;
  runtimeConfig: RuntimeConfigItem[];
}

export interface ApiResponse<T> {
  code: number;
  msg: string;
  data: T;
}

export interface DiagnosticStep {
  key: string;
  name: string;
  state: DiagnosticState;
  metric: string;
  advice?: string;
}

export interface NavItem {
  key: string;
  path: string;
  label: string;
  group: string;
  badge?: string;
}
