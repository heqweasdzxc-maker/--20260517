import type { AggregateEvent, WorkOrder } from '../types';

export type EventQueueTone = 'green' | 'blue' | 'amber' | 'red' | 'gray' | 'violet' | 'slate';

export interface EventQueueRow extends AggregateEvent {
  workOrder?: WorkOrder;
  stage: string;
  stageTone: EventQueueTone;
  actionLabel: string;
  reviewAlarmId: string;
  firstOccurredText: string;
  latestOccurredText: string;
  durationText: string;
}

export function formatEventDateTime(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '--';
  const parts = new Intl.DateTimeFormat('zh-CN', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date);
  const valueOf = (type: Intl.DateTimeFormatPartTypes) => parts.find((part) => part.type === type)?.value || '00';
  return `${valueOf('year')}-${valueOf('month')}-${valueOf('day')} ${valueOf('hour')}:${valueOf('minute')}:${valueOf('second')}`;
}

export function formatEventDuration(first: string, latest: string): string {
  const elapsedSeconds = Math.max(0, Math.floor((Date.parse(latest) - Date.parse(first)) / 1000));
  if (!Number.isFinite(elapsedSeconds) || elapsedSeconds < 60) return `${Math.max(0, elapsedSeconds)}秒`;
  const days = Math.floor(elapsedSeconds / 86400);
  const hours = Math.floor((elapsedSeconds % 86400) / 3600);
  const minutes = Math.floor((elapsedSeconds % 3600) / 60);
  if (days) return `${days}天${hours}小时`;
  if (hours) return `${hours}小时${minutes}分钟`;
  return `${minutes}分钟`;
}

export function eventQueueRows(events: AggregateEvent[], workOrders: WorkOrder[]): EventQueueRow[] {
  return [...events]
    .filter((event) => event.status === '待研判')
    .sort((a, b) => Date.parse(b.latestOccurredAt) - Date.parse(a.latestOccurredAt))
    .map((event) => {
      const workOrder = workOrders.find((order) =>
        order.id === event.workOrderId || order.alarmId === event.latestAlarmId || order.alarmId === event.firstAlarmId,
      );
      const meta = eventQueueMeta(workOrder);
      return {
        ...event,
        workOrder,
        ...meta,
        reviewAlarmId: event.latestAlarmId,
        firstOccurredText: formatEventDateTime(event.firstOccurredAt),
        latestOccurredText: formatEventDateTime(event.latestOccurredAt),
        durationText: formatEventDuration(event.firstOccurredAt, event.latestOccurredAt),
      };
    });
}

export function summarizeEventQueue(events: AggregateEvent[], workOrders: WorkOrder[]) {
  const open = events.filter((event) => event.status === '待研判');
  return {
    openCount: open.length,
    pendingCount: open.filter((event) => !event.workOrderId).length,
    dedupeHits: open.reduce((sum, event) => sum + Math.max(0, Number(event.occurrenceCount || 1) - 1), 0),
    activeWorkOrders: workOrders.filter((order) => order.status !== '归档').length,
  };
}

function eventQueueMeta(workOrder?: WorkOrder): Pick<EventQueueRow, 'stage' | 'stageTone' | 'actionLabel'> {
  if (workOrder?.status === '复核') return { stage: '复核中', stageTone: 'violet', actionLabel: '复核归档' };
  if (workOrder?.status === '处置') return { stage: '处置中', stageTone: 'amber', actionLabel: '提交复核' };
  if (workOrder?.status === '派单') return { stage: '待派单', stageTone: 'blue', actionLabel: '开始处置' };
  return { stage: '待研判', stageTone: 'red', actionLabel: '研判' };
}
