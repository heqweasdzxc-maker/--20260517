import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  closeAggregateEvent,
  createAggregateEvent,
  eventOccurredAt,
  mergeAggregateEvent,
  normalizeEventDedupeKey,
} from '../src/event-groups.mjs';

describe('aggregate event lifecycle', () => {
  it('normalizes the device and anomaly type into one stable key', () => {
    assert.equal(
      normalizeEventDedupeKey({ cameraId: ' ch04 ', type: ' 漂 浮物 ' }),
      'CH04:漂浮物',
    );
  });

  it('prefers complete alarm timestamps over the time-only display field', () => {
    assert.equal(
      eventOccurredAt({ createdAt: '2026-07-16T23:58:00.000Z', time: '07:58:00' }),
      '2026-07-16T23:58:00.000Z',
    );
  });

  it('keeps the first occurrence and advances the latest occurrence and summaries', () => {
    const first = createAggregateEvent(alarm({
      id: 'A-1',
      severity: '一般',
      confidence: 62,
      createdAt: '2026-07-17T01:00:00.000Z',
    }), { id: 'EG-1' });

    const merged = mergeAggregateEvent(first, alarm({
      id: 'A-2',
      severity: '严重',
      confidence: 88,
      createdAt: '2026-07-18T02:30:00.000Z',
    }));

    assert.equal(merged.firstAlarmId, 'A-1');
    assert.equal(merged.latestAlarmId, 'A-2');
    assert.equal(merged.firstOccurredAt, '2026-07-17T01:00:00.000Z');
    assert.equal(merged.latestOccurredAt, '2026-07-18T02:30:00.000Z');
    assert.equal(merged.occurrenceCount, 2);
    assert.equal(merged.severity, '严重');
    assert.equal(merged.latestConfidence, 88);
    assert.equal(merged.maxConfidence, 88);
  });

  it('does not increment when the same raw alarm is delivered again', () => {
    const firstAlarm = alarm({ id: 'A-1', createdAt: '2026-07-17T01:00:00.000Z' });
    const first = createAggregateEvent(firstAlarm, { id: 'EG-1' });
    const merged = mergeAggregateEvent(first, firstAlarm, { relationInserted: false });

    assert.deepEqual(merged, first);
  });

  it('preserves legacy dedupe counts during idempotent backfill', () => {
    const first = createAggregateEvent(alarm({ id: 'A-1' }), { id: 'EG-1' });
    const merged = mergeAggregateEvent(first, alarm({ id: 'A-2' }), { occurrenceIncrement: 5 });

    assert.equal(merged.occurrenceCount, 6);
  });

  it('closes only for ignore or handled and never mutates occurrence history', () => {
    const open = createAggregateEvent(alarm({ id: 'A-1' }), { id: 'EG-1' });
    assert.throws(() => closeAggregateEvent(open, '已确认'), /只允许忽略或已处理/);

    const closed = closeAggregateEvent(open, '已处理', {
      closedAt: '2026-07-17T03:00:00.000Z',
      workOrderId: 'WO-1',
    });

    assert.equal(closed.status, '已处理');
    assert.equal(closed.reviewAction, '已处理');
    assert.equal(closed.closedAt, '2026-07-17T03:00:00.000Z');
    assert.equal(closed.workOrderId, 'WO-1');
    assert.equal(closed.occurrenceCount, 1);
    assert.throws(() => mergeAggregateEvent(closed, alarm({ id: 'A-2' })), /已关闭/);
  });
});

function alarm(overrides = {}) {
  return {
    id: 'A-DEFAULT',
    cameraId: 'CH04',
    cameraName: '4号桥东',
    type: '漂浮物',
    severity: '一般',
    confidence: 60,
    status: '待研判',
    time: '09:00:00',
    createdAt: '2026-07-17T01:00:00.000Z',
    ...overrides,
  };
}
