import { ElMessage, ElMessageBox } from 'element-plus';
import { computed, reactive, ref, watch } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import type { DevicePayload } from '../api/deviceApi';
import type { OpsRunType } from '../api/opsApi';
import type { UavAssetPayload } from '../api/uavAssetApi';
import { displayStreamUrl, filterPlaybackEvents, progressOfWorkOrder, severityTone, statusTone, isSlaRisk } from '../services/business';
import { formatEventDateTime, summarizeEventQueue } from '../services/eventGroups';
import { cameraToTencentCoordinate } from '../services/tencentMap';
import { usePlatformStore } from '../stores/platform';
import type { Alarm, AlarmReviewAction, AlarmStatus, Camera, DiagnosticStep, EvidenceBundle, ImportJob, Severity, StorageTier, UavAsset, UavAssetStatus, UserAccount, VideoTileAction, WorkOrder } from '../types';

function createWorkspace() {
const route = useRoute();
const router = useRouter();
const platform = usePlatformStore();
const alarmDrawer = ref(false);
const selectedAlarmSnapshot = ref<Alarm | null>(null);
const operationDialog = ref(false);
const operationAction = ref<'filter' | 'export' | 'create' | 'upload' | 'rbac' | 'model' | null>(null);
type CameraType = NonNullable<Camera['cameraType']>;
type DeviceForm = {
  id: string;
  name: string;
  cameraType: CameraType;
  protocol: Camera['protocol'];
  longitude: string;
  latitude: string;
  ip: string;
  node: string;
  streamUrl: string;
  status: Camera['status'];
  ptz: boolean;
};
type UavAssetForm = {
  id: string;
  name: string;
  assetType: UavAsset['assetType'];
  vendor: UavAsset['vendor'];
  model: string;
  dockName: string;
  dockSn: string;
  droneSn: string;
  status: UavAssetStatus;
  mode: UavAsset['mode'];
  longitude: string;
  latitude: string;
  battery: number;
  signal: number;
  altitude: number;
  speed: number;
  dockStatus: string;
  dockWeather: string;
  rtkStatus: string;
  firmware: string;
  payload: string;
  videoReturn: string;
  activeTaskId: string;
  relatedAlarm: string;
};
type AlarmEvidenceBox = {
  id: string;
  label: string;
  confidence: number;
  severity: Severity;
  x: number;
  y: number;
  w: number;
  h: number;
};
type AlarmEvidenceMetadata = {
  alarmId: string;
  eventId: string;
  cameraId: string;
  capturedAt: string;
  coordinateSpace: string;
  boxes: unknown[];
};
const deviceDialog = ref(false);
const deviceDialogMode = ref<'create' | 'edit'>('create');
const deviceSubmitting = ref(false);
const uavAssetDialog = ref(false);
const uavAssetDialogMode = ref<'create' | 'edit'>('create');
const uavAssetSubmitting = ref(false);
const cameraPreviewDialog = ref(false);
const cameraPreviewMode = ref<'zoom' | 'fullscreen'>('zoom');
const cameraPreviewId = ref('');
const cameraTypeOptions: CameraType[] = ['固定枪机', '云台球机', '全景枪球', '热成像'];
const protocolOptions: Camera['protocol'][] = ['GB28181', 'RTSP', 'Onvif'];
const inferenceNodeOptions = ['C9-EDGE-01', 'C9-EDGE-02', 'C9-EDGE-03', 'C9-POOL'];
const uavAssetStatusOptions: UavAssetStatus[] = ['待命', '执行中', '充电中', '维护中', '离线', '故障'];
const uavAssetModelOptions = ['DJI Dock + Matrice 30T', 'DJI Dock 2 + Matrice 3TD', 'DJI Dock 3 + Matrice 4D'];
const deviceForm = reactive<DeviceForm>({
  id: '',
  name: '',
  cameraType: '云台球机',
  protocol: 'GB28181',
  longitude: '',
  latitude: '',
  ip: '',
  node: 'C9-EDGE-02',
  streamUrl: '',
  status: '在线',
  ptz: true,
});
const uavAssetForm = reactive<UavAssetForm>({
  id: '',
  name: '',
  assetType: '无人机+机巢',
  vendor: 'DJI',
  model: 'DJI Dock 2 + Matrice 3TD',
  dockName: '',
  dockSn: '',
  droneSn: '',
  status: '待命',
  mode: 'auto',
  longitude: '',
  latitude: '',
  battery: 100,
  signal: 100,
  altitude: 0,
  speed: 0,
  dockStatus: '在线待命',
  dockWeather: '气象待同步',
  rtkStatus: 'RTK 待同步',
  firmware: '',
  payload: '',
  videoReturn: '视频回传待建立',
  activeTaskId: '',
  relatedAlarm: '',
});

const page = computed(() => String(route.meta.page || 'monitor'));
const pageTitle = computed(() => String(route.meta.title || '实时视频墙'));
const selectedAlarm = computed(() => platform.selectedAlarm || selectedAlarmSnapshot.value || undefined);
const selectedAggregateEvent = computed(() => {
  const alarmId = selectedAlarm.value?.id;
  if (!alarmId) return undefined;
  return (platform.events || []).find((event) => event.firstAlarmId === alarmId || event.latestAlarmId === alarmId);
});
const capturedAlarmEvidenceUrl = ref('');
const capturedAlarmEvidenceMetadata = ref<AlarmEvidenceMetadata | null>(null);
let alarmEvidenceRequest = 0;

watch(
  () => selectedAlarm.value?.id,
  async (alarmId) => {
    const requestId = ++alarmEvidenceRequest;
    if (capturedAlarmEvidenceUrl.value) URL.revokeObjectURL(capturedAlarmEvidenceUrl.value);
    capturedAlarmEvidenceUrl.value = '';
    capturedAlarmEvidenceMetadata.value = null;
    if (!alarmId) return;

    const authorization: Record<string, string> = {};
    if (platform.authToken) authorization.Authorization = `Bearer ${platform.authToken}`;
    const loadMedia = async () => {
      try {
        const response = await fetch(`/api/alarm/alarms/${encodeURIComponent(alarmId)}/evidence`, {
          headers: { ...authorization, Accept: 'image/jpeg,image/*' },
        });
        if (!response.ok) return;
        const blob = await response.blob();
        if (requestId !== alarmEvidenceRequest || !blob.size) return;
        capturedAlarmEvidenceUrl.value = URL.createObjectURL(blob);
      } catch {
        // Missing historical evidence is rendered explicitly in the review dialog.
      }
    };
    const loadMetadata = async () => {
      try {
        const response = await fetch(`/api/alarm/alarms/${encodeURIComponent(alarmId)}/evidence/metadata`, {
          headers: { ...authorization, Accept: 'application/json' },
        });
        if (!response.ok) return;
        const body = await response.json();
        if (requestId !== alarmEvidenceRequest) return;
        capturedAlarmEvidenceMetadata.value = (body?.data || body) as AlarmEvidenceMetadata;
      } catch {
        // Legacy deployments continue to use the recent AI event fallback.
      }
    };
    await Promise.all([loadMedia(), loadMetadata()]);
  },
);
const selectedCamera = computed(() => platform.activeCamera);
const mainTrend = computed(() => platform.reportMetrics[0]?.trend ?? []);
const playbackPageSize = 10;
const playbackPage = ref(1);
const playbackPlaying = ref(false);
const playbackProgress = ref(42);
const playbackNotice = ref('已定位到告警 PTS 元数据');
const playbackTypeFilter = ref('');
const playbackSeverityFilter = ref<Severity | ''>('');
const playbackStatusFilter = ref<AlarmStatus | ''>('');
const templateCoverage = computed(() => platform.templates.reduce((sum, tpl) => sum + tpl.channels, 0));
const algorithmAverageLatency = computed(() => {
  if (platform.algorithms.length === 0) return 0;
  return Math.round(platform.algorithms.reduce((sum, model) => sum + model.latency, 0) / platform.algorithms.length);
});
const eventKpis = computed(() => {
  const summary = summarizeEventQueue(platform.events || [], platform.workOrders);

  return [
    { label: '队列事件', value: `${summary.openCount}`, hint: '未关闭事件生命周期', tone: 'blue' },
    { label: '待研判事件', value: `${summary.pendingCount}`, hint: '需要人工确认', tone: 'red' },
    { label: '去重命中', value: `${summary.dedupeHits}`, hint: '重复检测已聚合', tone: 'amber' },
    { label: '自动派单', value: `${summary.activeWorkOrders}`, hint: '确认后进入闭环', tone: 'green' },
  ];
});
const eventTypeStats = computed(() => {
  const counts = (platform.events || []).reduce<Record<string, number>>((acc, event) => {
    acc[event.type] = (acc[event.type] || 0) + 1;
    return acc;
  }, {});
  const max = Math.max(1, ...Object.values(counts));

  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .map(([name, count]) => ({ name, count, percentage: Math.round((count / max) * 100) }));
});
const eventStatusStats = computed(() => {
  const statuses = ['待研判', '已忽略', '已处理'] as const;

  return statuses.map((status) => ({
    status,
    count: (platform.events || []).filter((event) => event.status === status).length,
  }));
});
const pageRecordCount = computed(() => {
  const counts: Record<string, number> = {
    monitor: platform.cameras.length,
    map: platform.cameras.length,
    twin: platform.cameras.length,
    playback: platform.cameras.length,
    events: (platform.events || []).length,
    dashboard: platform.kpis.length,
    alarms: platform.alarms.length,
    workorder: platform.workOrders.length,
    evidence: platform.evidenceBundles.length,
    import: platform.importJobs.length,
    devices: platform.cameras.length,
    diag: platform.cameras.length,
    template: platform.templates.length,
    algorithm: platform.algorithms.length,
    storage: platform.storageTiers.length,
    report: platform.reportMetrics.length,
    user: platform.users.length,
    log: platform.logs.length,
  };

  return counts[page.value] ?? 0;
});
const workOrderStats = computed(() => {
  const total = platform.workOrders.length;
  const archived = platform.workOrders.filter((order) => order.status === '归档').length;
  const slaRisk = platform.workOrders.filter((order) => isSlaRisk(order)).length;
  const overdue = platform.workOrders.filter((order) => order.status !== '归档' && order.elapsedHours >= order.slaHours).length;

  return {
    total,
    active: total - archived,
    archived,
    closureRate: total ? Math.round((archived / total) * 1000) / 10 : 0,
    slaRisk,
    overdue,
  };
});
const latestEvidenceVerification = computed(() => platform.evidenceBundles.find((bundle) => bundle.lastVerify)?.lastVerify);
const deviceRows = computed(() => [...platform.cameras].sort((a, b) => channelNumber(a.id) - channelNumber(b.id) || a.id.localeCompare(b.id)));
const uavAssetRows = computed(() =>
  [...platform.uavAssets].sort((a, b) => {
    const statusRank = uavAssetStatusOptions.indexOf(a.status) - uavAssetStatusOptions.indexOf(b.status);
    return statusRank || a.dockName.localeCompare(b.dockName, 'zh-CN') || a.id.localeCompare(b.id);
  }),
);
const playbackTypeOptions = computed(() => Array.from(new Set(platform.alarms.map((alarm) => alarm.type))).sort((a, b) => a.localeCompare(b, 'zh-CN')));
const playbackSeverityOptions = ['紧急', '严重', '一般', '提示'] as const;
const playbackStatusOptions = ['待研判', '已确认', '已派单', '误报', '已归档'] as const;
const playbackEvents = computed(() =>
  filterPlaybackEvents(platform.alarms, {
    cameraId: platform.selectedCameraId,
    type: playbackTypeFilter.value,
    severity: playbackSeverityFilter.value,
    status: playbackStatusFilter.value,
  }),
);
const playbackTotalPages = computed(() => Math.max(1, Math.ceil(playbackEvents.value.length / playbackPageSize)));
const pagedPlaybackEvents = computed(() => {
  const start = (playbackPage.value - 1) * playbackPageSize;
  return playbackEvents.value.slice(start, start + playbackPageSize);
});
const playbackCurrentTime = computed(() => progressToTime(playbackProgress.value));
const selectedAlarmWorkOrder = computed(() => {
  const alarm = selectedAlarm.value;
  return alarm ? platform.workOrders.find((order) => order.alarmId === alarm.id) : undefined;
});
const selectedAlarmCamera = computed(() => {
  const alarm = selectedAlarm.value;
  return alarm ? platform.cameras.find((camera) => camera.id === alarm.cameraId) : undefined;
});
const selectedAlarmEvidenceEvent = computed(() => {
  const alarm = selectedAlarm.value;
  if (!alarm) return undefined;

  return (platform.aiEvents || []).find((event) => {
    const result = event.result || event.payload?.result || {};
    const eventAlarmId = event.alarmId || result?.alarm?.id || event.payload?.alarmId;
    return eventAlarmId === alarm.id;
  });
});
const selectedAlarmEvidenceMedia = computed(() => {
  const alarm = selectedAlarm.value as any;
  if (!alarm) return undefined;

  const event = selectedAlarmEvidenceEvent.value as any;
  const request = event?.request || event?.payload?.request || event?.payload || {};
  const result = event?.result || event?.payload?.result || {};
  const metadata = result?.alarm?.metadata || alarm.metadata || {};
  const bundle = (platform.evidenceBundles || []).find((item: any) => item.alarmId === alarm.id) as any;
  const playbackClip = ((platform as any).playbackClips || []).find((item: any) => item.alarmId === alarm.id);
  const candidates = [
    { url: capturedAlarmEvidenceUrl.value, type: 'image' },
    { url: metadata.annotatedClipUrl, type: 'video' },
    { url: metadata.evidenceClipUrl, type: 'video' },
    { url: request.annotatedClipUrl, type: 'video' },
    { url: request.evidenceClipUrl, type: 'video' },
    { url: request.clipUrl, type: 'video' },
    { url: playbackClip?.annotatedClipUrl || playbackClip?.playbackUrl || playbackClip?.clipUrl || playbackClip?.mediaUrl, type: 'video' },
    { url: bundle?.annotatedClipUrl || bundle?.clipUrl || bundle?.mediaUrl, type: 'video' },
    { url: metadata.annotatedFrameUrl, type: 'image' },
    { url: metadata.evidenceImageUrl, type: 'image' },
    { url: metadata.snapshotUrl, type: 'image' },
    { url: request.annotatedFrameUrl, type: 'image' },
    { url: request.evidenceImageUrl, type: 'image' },
    { url: request.snapshotUrl || request.frameUrl || request.imageUrl, type: 'image' },
    { url: bundle?.annotatedFrameUrl || bundle?.snapshotUrl || bundle?.imageUrl, type: 'image' },
    { url: alarm.snapshot, type: 'image' },
  ];

  const media = candidates.find((candidate) => isPersistedEvidenceUrl(candidate.url));
  return media ? { url: String(media.url), type: media.type as 'image' | 'video' } : undefined;
});
const selectedAlarmEvidenceBoxes = computed<AlarmEvidenceBox[]>(() => {
  const alarm = selectedAlarm.value;
  const event = selectedAlarmEvidenceEvent.value;
  if (!alarm) return [];

  const request = (event as any)?.request || event?.payload?.request || event?.payload || {};
  const persistedBoxes = capturedAlarmEvidenceMetadata.value?.boxes;
  const boxes = Array.isArray(persistedBoxes) && persistedBoxes.length
    ? persistedBoxes
    : Array.isArray(request.boxes)
      ? request.boxes
      : Array.isArray(request.detections)
        ? request.detections
        : [];

  const normalized = boxes
    .map((box: any, index: number) => {
      const label = String(box.cls || box.label || box.name || alarm.type);
      return {
        id: String(box.id || `${alarm.id}-evidence-${index + 1}`),
        label,
        confidence: normalizeEvidenceConfidence(box.score ?? box.confidence ?? alarm.confidence),
        severity: alarm.severity,
        x: normalizeEvidenceCoordinate(box.x),
        y: normalizeEvidenceCoordinate(box.y),
        w: normalizeEvidenceCoordinate(box.w ?? box.width),
        h: normalizeEvidenceCoordinate(box.h ?? box.height),
      };
    });
  const matching = normalized.filter((box: AlarmEvidenceBox) => box.label === alarm.type || box.label.includes(alarm.type) || alarm.type.includes(box.label));
  return matching.length ? matching : normalized;
});
const selectedAlarmEvidenceTime = computed(() => {
  const alarm = selectedAlarm.value;
  const event = selectedAlarmEvidenceEvent.value;
  const request = (event as any)?.request || event?.payload?.request || event?.payload || {};
  const result = event?.result || event?.payload?.result || {};
  const metadata = result?.alarm?.metadata || (alarm as any)?.metadata || {};
  return capturedAlarmEvidenceMetadata.value?.capturedAt || metadata.generatedAt || metadata.receivedAt || request.generatedAt || event?.receivedAt || alarm?.createdAt || alarm?.time || '';
});
const selectedAlarmEvidenceSource = computed(() => capturedAlarmEvidenceMetadata.value?.boxes?.length ? '历史AI标注' : selectedAlarmEvidenceEvent.value ? 'AI元数据回传' : '告警记录');
const selectedAlarmDeviceName = computed(() => selectedAlarmCamera.value?.name || selectedAlarm.value?.cameraName || '');
const selectedAlarmUavTask = computed(() => {
  const alarm = selectedAlarm.value;
  return alarm ? platform.uavTasks.find((task) => task.relatedAlarm === alarm.id) : undefined;
});
const selectedAlarmEvidence = computed(() => {
  const alarm = selectedAlarm.value;
  if (!alarm) return undefined;
  const workOrder = selectedAlarmWorkOrder.value;
  return platform.evidenceBundles.find((bundle) => bundle.alarmId === alarm.id || bundle.workOrderId === workOrder?.id);
});
const previewCamera = computed(() => platform.cameras.find((camera) => camera.id === cameraPreviewId.value));
const cameraPreviewTitle = computed(() => {
  const camera = previewCamera.value;
  if (!camera) return '通道预览';
  return `${camera.name} · 通道预览`;
});
const cameraNameById = computed(() => new Map(platform.cameras.map((camera) => [camera.id, camera.name])));

function openAlarm(id: string) {
  platform.selectAlarm(id);
  selectedAlarmSnapshot.value = platform.selectedAlarm ? { ...platform.selectedAlarm } : null;
  alarmDrawer.value = true;
}

function openPlaybackAlarm(alarm: Alarm) {
  platform.selectCamera(alarm.cameraId);
  playbackProgress.value = ptsToProgress(alarm.pts);
  playbackNotice.value = `已定位 ${alarmDeviceName(alarm)} ${alarm.type}`;
  openAlarm(alarm.id);
}

function alarmDeviceName(alarm: Alarm) {
  return cameraNameById.value.get(alarm.cameraId) || alarm.cameraName;
}

function alarmReviewTitle(alarm: Alarm) {
  return `${alarmDeviceName(alarm)} · ${alarm.type}`;
}

function deviceNameById(cameraId: string, fallback = cameraId) {
  return cameraNameById.value.get(cameraId) || fallback;
}

function workOrderDisplayTitle(order: WorkOrder) {
  const alarm = platform.alarms.find((item) => item.id === order.alarmId);
  const cleanTitle = cleanWorkOrderTitle(order.title);
  if (!alarm) return cleanTitle;
  const deviceName = alarmDeviceName(alarm);
  if (cleanTitle.includes(deviceName)) return cleanTitle;
  return `${deviceName} ${alarm.type}`;
}

function cleanWorkOrderTitle(title = '') {
  return String(title || '').replace(/\s*处置闭环\s*$/u, '').trim();
}

function uavTaskDisplayTitle(task: { name: string; relatedAlarm?: string }) {
  if (!task.relatedAlarm) return task.name;
  const alarm = platform.alarms.find((item) => item.id === task.relatedAlarm);
  if (!alarm) return task.name;
  const deviceName = alarmDeviceName(alarm);
  return task.name.includes(deviceName) ? task.name : `${deviceName} ${alarm.type}复查`;
}

function evidenceBundleDisplayName(bundle: { alarmId: string; name: string }) {
  const alarm = platform.alarms.find((item) => item.id === bundle.alarmId);
  if (!alarm) return bundle.name;
  const deviceName = alarmDeviceName(alarm);
  return bundle.name.includes(deviceName) ? bundle.name : `${deviceName} ${alarm.type}证据包`;
}

function openOperation(action: typeof operationAction.value) {
  operationAction.value = action;
  operationDialog.value = true;
}

async function handleOperationDone(message: string) {
  ElMessage.success(message);
  await platform.refresh();
}

function openCreateDevice() {
  deviceDialogMode.value = 'create';
  resetDeviceForm();
  deviceDialog.value = true;
}

function openEditDevice(camera: Camera) {
  deviceDialogMode.value = 'edit';
  resetDeviceForm(camera);
  deviceDialog.value = true;
}

function resetDeviceForm(camera?: Camera) {
  const coordinate = camera ? cameraToTencentCoordinate(camera) : { lng: 121.4737, lat: 31.2304 };

  Object.assign(deviceForm, {
    id: camera?.id || '',
    name: camera?.name || '排水口-10 摄像机',
    cameraType: cameraTypeOf(camera),
    protocol: camera?.protocol || 'GB28181',
    longitude: String(camera?.longitude ?? coordinate.lng),
    latitude: String(camera?.latitude ?? coordinate.lat),
    ip: camera?.ip || '10.20.1.20',
    node: camera?.node || 'C9-EDGE-02',
    streamUrl: camera?.streamUrl || '',
    status: camera?.status || '在线',
    ptz: camera?.ptz ?? true,
  });
}

async function submitDeviceForm() {
  deviceSubmitting.value = true;

  try {
    const payload = devicePayloadFromForm();
    const camera =
      deviceDialogMode.value === 'edit' && deviceForm.id
        ? await platform.updateDevice(deviceForm.id, payload)
        : await platform.createDevice(payload);
    deviceDialog.value = false;
    ElMessage.success(`${camera.name} 已${deviceDialogMode.value === 'edit' ? '修改' : '新增'}，通道 ${camera.id}`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '设备保存失败');
  } finally {
    deviceSubmitting.value = false;
  }
}

async function deleteDevice(camera: Camera) {
  try {
    await ElMessageBox.confirm(`确认删除 ${camera.name}？删除后将从设备列表和地图点位移除。`, '删除设备', {
      confirmButtonText: '删除',
      cancelButtonText: '取消',
      type: 'warning',
    });
    await platform.deleteDevice(camera.id);
    ElMessage.success(`${camera.name} 已删除`);
  } catch (error) {
    if (error !== 'cancel' && error !== 'close') {
      ElMessage.error(error instanceof Error ? error.message : '设备删除失败');
    }
  }
}

function openCreateUavAsset() {
  uavAssetDialogMode.value = 'create';
  resetUavAssetForm();
  uavAssetDialog.value = true;
}

function openEditUavAsset(asset: UavAsset) {
  uavAssetDialogMode.value = 'edit';
  resetUavAssetForm(asset);
  uavAssetDialog.value = true;
}

function resetUavAssetForm(asset?: UavAsset) {
  Object.assign(uavAssetForm, {
    id: asset?.id || '',
    name: asset?.name || '大疆机场2-M3TD 巡检组',
    assetType: asset?.assetType || '无人机+机巢',
    vendor: asset?.vendor || 'DJI',
    model: asset?.model || 'DJI Dock 2 + Matrice 3TD',
    dockName: asset?.dockName || '东岸机巢',
    dockSn: asset?.dockSn || '',
    droneSn: asset?.droneSn || '',
    status: asset?.status || '待命',
    mode: asset?.mode || 'auto',
    longitude: String(asset?.longitude ?? 121.4737),
    latitude: String(asset?.latitude ?? 31.2304),
    battery: asset?.battery ?? 100,
    signal: asset?.signal ?? 100,
    altitude: asset?.altitude ?? 0,
    speed: asset?.speed ?? 0,
    dockStatus: asset?.dockStatus || '在线待命',
    dockWeather: asset?.dockWeather || '气象待同步',
    rtkStatus: asset?.rtkStatus || 'RTK 待同步',
    firmware: asset?.firmware || '',
    payload: asset?.payload || '',
    videoReturn: asset?.videoReturn || '视频回传待建立',
    activeTaskId: asset?.activeTaskId || '',
    relatedAlarm: asset?.relatedAlarm || '',
  });
}

async function submitUavAssetForm() {
  uavAssetSubmitting.value = true;

  try {
    const payload = uavAssetPayloadFromForm();
    const asset =
      uavAssetDialogMode.value === 'edit' && uavAssetForm.id
        ? await platform.updateUavAsset(uavAssetForm.id, payload)
        : await platform.createUavAsset(payload);
    uavAssetDialog.value = false;
    ElMessage.success(`${asset.name} 已${uavAssetDialogMode.value === 'edit' ? '修改' : '新增'}，资产 ${asset.id}`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '无人机资产保存失败');
  } finally {
    uavAssetSubmitting.value = false;
  }
}

async function deleteUavAsset(asset: UavAsset) {
  try {
    await ElMessageBox.confirm(`确认删除 ${asset.name}？删除后将从无人机调度和设备管理中移除。`, '删除无人机资产', {
      confirmButtonText: '删除',
      cancelButtonText: '取消',
      type: 'warning',
    });
    await platform.deleteUavAsset(asset.id);
    ElMessage.success(`${asset.name} 已删除`);
  } catch (error) {
    if (error !== 'cancel' && error !== 'close') {
      ElMessage.error(error instanceof Error ? error.message : '无人机资产删除失败');
    }
  }
}

function uavAssetPayloadFromForm(): UavAssetPayload {
  const name = uavAssetForm.name.trim();
  const dockName = uavAssetForm.dockName.trim();
  const model = uavAssetForm.model.trim();
  const longitude = parseCoordinate(uavAssetForm.longitude, '经度');
  const latitude = parseCoordinate(uavAssetForm.latitude, '纬度');

  if (!name) throw new Error('请填写无人机名称');
  if (!dockName) throw new Error('请填写机巢名称');
  if (!model) throw new Error('请填写产品型号');

  return {
    id: uavAssetDialogMode.value === 'edit' ? uavAssetForm.id : undefined,
    name,
    assetType: uavAssetForm.assetType,
    vendor: uavAssetForm.vendor,
    model,
    dockName,
    dockSn: uavAssetForm.dockSn.trim(),
    droneSn: uavAssetForm.droneSn.trim(),
    status: uavAssetForm.status,
    mode: uavAssetForm.mode,
    longitude,
    latitude,
    battery: Number(uavAssetForm.battery || 0),
    signal: Number(uavAssetForm.signal || 0),
    altitude: Number(uavAssetForm.altitude || 0),
    speed: Number(uavAssetForm.speed || 0),
    dockStatus: uavAssetForm.dockStatus.trim(),
    dockWeather: uavAssetForm.dockWeather.trim(),
    rtkStatus: uavAssetForm.rtkStatus.trim(),
    firmware: uavAssetForm.firmware.trim(),
    payload: uavAssetForm.payload.trim(),
    videoReturn: uavAssetForm.videoReturn.trim(),
    activeTaskId: uavAssetForm.activeTaskId.trim(),
    relatedAlarm: uavAssetForm.relatedAlarm.trim(),
  };
}

function devicePayloadFromForm(): DevicePayload {
  const name = deviceForm.name.trim();
  const ip = deviceForm.ip.trim();
  const longitude = parseCoordinate(deviceForm.longitude, '经度');
  const latitude = parseCoordinate(deviceForm.latitude, '纬度');

  if (!name) throw new Error('请填写设备名称');
  if (!ip) throw new Error('请填写 IP 地址');

  return {
    id: deviceDialogMode.value === 'edit' ? deviceForm.id : undefined,
    name,
    cameraType: deviceForm.cameraType,
    protocol: deviceForm.protocol,
    longitude,
    latitude,
    ip,
    node: deviceForm.node,
    streamUrl: deviceForm.streamUrl.trim() || undefined,
    ptz: deviceForm.cameraType !== '固定枪机',
    status: deviceForm.status,
  };
}

function parseCoordinate(value: string, label: string) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) throw new Error(`${label}必须是有效数字`);
  return parsed;
}

function cameraTypeOf(camera?: Camera): CameraType {
  return camera?.cameraType || (camera?.ptz === false ? '固定枪机' : '云台球机');
}

function cameraCoordinate(camera: Camera) {
  const coordinate = cameraToTencentCoordinate(camera);
  return `${coordinate.lng.toFixed(6)}, ${coordinate.lat.toFixed(6)}`;
}

function streamUrlOf(camera: Camera) {
  return displayStreamUrl(camera);
}

function normalizeEvidenceConfidence(value: unknown) {
  const numeric = Number(value || 0);
  if (!Number.isFinite(numeric)) return 0;
  const percent = numeric <= 1 ? numeric * 100 : numeric;
  return Math.max(0, Math.min(100, Math.round(percent * 10) / 10));
}

function normalizeEvidenceCoordinate(value: unknown) {
  const numeric = Number(value || 0);
  if (!Number.isFinite(numeric)) return 0;
  return numeric <= 1 ? numeric * 100 : numeric;
}

function evidenceBoxPercent(value: number) {
  return `${Math.max(0, Math.min(100, Number(value) || 0))}%`;
}

function evidenceBoxStyle(box: AlarmEvidenceBox) {
  return {
    left: evidenceBoxPercent(box.x),
    top: evidenceBoxPercent(box.y),
    width: evidenceBoxPercent(box.w),
    height: evidenceBoxPercent(box.h),
  };
}

function isPersistedEvidenceUrl(value: unknown) {
  const url = String(value || '').trim();
  if (!url) return false;
  if (/^(?:data:image\/|blob:|https?:\/\/|\/)/i.test(url)) return true;
  return /\.(?:jpe?g|png|webp|mp4|webm|m3u8)(?:[?#].*)?$/i.test(url);
}

function uavCoordinate(asset: UavAsset) {
  if (asset.longitude === undefined || asset.latitude === undefined) return '未同步坐标';
  return `${Number(asset.longitude).toFixed(6)}, ${Number(asset.latitude).toFixed(6)}`;
}

function uavAssetStatusTone(status: UavAssetStatus): 'green' | 'blue' | 'amber' | 'red' | 'gray' {
  if (status === '待命' || status === '充电中') return 'green';
  if (status === '执行中') return 'blue';
  if (status === '维护中') return 'amber';
  if (status === '故障') return 'red';
  return 'gray';
}

function channelNumber(id: string) {
  const match = id.match(/^CH(\d+)$/i);
  return match ? Number(match[1]) : Number.MAX_SAFE_INTEGER;
}

async function reviewSelectedAlarm(status: AlarmReviewAction) {
  if (!selectedAlarm.value) return;
  try {
    const alarmId = selectedAlarm.value.id;
    await platform.reviewAlarm(alarmId, status);
    alarmDrawer.value = false;
    selectedAlarmSnapshot.value = null;
    const workOrder = platform.workOrders.find((order) => order.alarmId === alarmId);
    if (status === '忽略') {
      ElMessage.success(`告警已忽略，并进入工单闭环待归档${workOrder ? `：${workOrder.id}` : ''}`);
      return;
    }
    if (status === '已处理') {
      ElMessage.success(`告警已处理，并进入工单闭环待归档${workOrder ? `：${workOrder.id}` : ''}`);
      return;
    }
    ElMessage.success(`告警已确认并派单${workOrder ? `：${workOrder.id}` : ''}`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '告警研判失败');
  }
}

async function ignoreRealtimeAlarm(alarm: Alarm) {
  try {
    await platform.reviewAlarm(alarm.id, '忽略');
    const workOrder = platform.workOrders.find((order) => order.alarmId === alarm.id);
    ElMessage.success(`实时异常已忽略，并进入工单闭环待归档${workOrder ? `：${workOrder.id}` : ''}`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '实时异常忽略失败');
  }
}

async function dispatchRealtimeAlarm(alarm: Alarm) {
  try {
    const dispatched = await platform.dispatchRealtimeAlarmToAlarmCenter(alarm.id);
    if (!dispatched) {
      ElMessage.warning('未找到对应实时异常，未派入告警中心');
      return;
    }
    ElMessage.success(`${alarmDeviceName(dispatched)} ${dispatched.type} 已进入告警中心待研判`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '实时异常派单失败');
  }
}

function findCameraAlarm(cameraId: string) {
  const related = platform.alarms.filter((alarm) => alarm.cameraId === cameraId);
  return related.find((alarm) => alarm.status === '待研判') || related.find((alarm) => alarm.status !== '已归档') || related[0];
}

function openCameraAlarm(cameraId: string) {
  platform.selectCamera(cameraId);
  const alarm = findCameraAlarm(cameraId);
  const camera = platform.cameras.find((item) => item.id === cameraId);

  if (!alarm) {
    ElMessage.info(`${camera?.name || cameraId} 当前无关联告警，未打开研判弹窗`);
    return;
  }

  openPlaybackAlarm(alarm);
}

function openCameraMap(cameraId: string) {
  const camera = platform.cameras.find((item) => item.id === cameraId);
  if (!camera) {
    ElMessage.warning('未找到对应设备');
    return;
  }

  platform.selectCamera(cameraId);
  void router.push('/map');
  ElMessage.success(`${camera.name} 已定位到电子地图`);
}

function openCameraPreview(cameraId: string, mode: 'zoom' | 'fullscreen') {
  const camera = platform.cameras.find((item) => item.id === cameraId);
  if (!camera) {
    ElMessage.warning('未找到对应设备');
    return;
  }

  platform.selectCamera(cameraId);
  cameraPreviewId.value = cameraId;
  cameraPreviewMode.value = mode;
  cameraPreviewDialog.value = true;
}

function handleCameraAction(cameraId: string, action: VideoTileAction) {
  if (action === 'alarm') openCameraAlarm(cameraId);
  if (action === 'map') openCameraMap(cameraId);
  if (action === 'zoom') openCameraPreview(cameraId, 'zoom');
  if (action === 'fullscreen') openCameraPreview(cameraId, 'fullscreen');
}

function openAlarmRow(row: Alarm) {
  openAlarm(row.id);
}

async function reviewAlarmRow(row: Alarm) {
  if (row.status !== '待研判') {
    ElMessage.info('该告警已进入派单环节，请在工单闭环中继续处置，不会直接归档');
    return;
  }

  try {
    await platform.reviewAlarm(row.id, '已确认');
    ElMessage.success('告警已确认，已进入派单环节，未直接归档');
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '告警研判失败');
  }
}

function nextWorkOrderAction(order: WorkOrder) {
  if (order.status === '派单') return '开始处置';
  if (order.status === '处置') return '提交复核';
  if (order.status === '复核') return '复核归档';
  return '已归档';
}

function startWorkOrderAction(order: WorkOrder) {
  return order.status === '派单' ? '开始处置' : '已开始';
}

function archiveWorkOrderAction(order: WorkOrder) {
  return order.status === '归档' ? '已归档' : '确认归档';
}

async function advanceWorkOrder(order: WorkOrder) {
  try {
    const updated = await platform.advanceWorkOrder(order.id);
    ElMessage.success(`${updated.id} 已流转至${updated.status}`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '工单流转失败');
  }
}

async function startWorkOrder(order: WorkOrder) {
  if (order.status !== '派单') {
    ElMessage.info('该工单已开始处置，开始处置按钮不会推进到复核或归档');
    return;
  }

  try {
    const updated = await platform.startWorkOrder(order.id);
    ElMessage.success(`${updated.id} 已开始处置`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '开始处置失败');
  }
}

async function archiveWorkOrder(order: WorkOrder) {
  if (order.status === '归档') {
    ElMessage.info('该工单已归档，可在历史查询中复现');
    return;
  }

  try {
    const updated = await platform.archiveWorkOrder(order.id);
    ElMessage.success(`${updated.id} 工单已确认归档，可在历史查询中复现`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '工单归档失败');
  }
}

async function remindWorkOrder(order: WorkOrder) {
  try {
    const updated = await platform.remindWorkOrder(order.id);
    ElMessage.success(updated.escalated ? `${updated.id} 已超时升级` : `${updated.id} 已催办`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '工单催办失败');
  }
}

async function createEvidenceBundle(alarmId?: string) {
  try {
    const bundle = await platform.createEvidenceBundle(alarmId);
    ElMessage.success(`${bundle.id} 已固化，SHA-256 已生成`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '证据组卷失败');
  }
}

async function verifyEvidenceBundle(bundle: EvidenceBundle) {
  try {
    const result = await platform.verifyEvidenceBundle(bundle.id);
    ElMessage.success(result.ok ? `${bundle.id} 校验通过` : `${bundle.id} 校验失败`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '证据校验失败');
  }
}

async function downloadEvidenceBundle(bundle: EvidenceBundle) {
  try {
    const size = await platform.downloadEvidenceBundle(bundle.id);
    ElMessage.success(`${bundle.id} ZIP 已生成（${Math.round(size / 1024)}KB）`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '证据下载失败');
  }
}

async function createImportJob() {
  try {
    const job = await platform.createImportJob();
    ElMessage.success(`${job.id} 已完成离线分析`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '导入分析任务创建失败');
  }
}

async function reanalyzeImportJob(job: ImportJob) {
  try {
    const updated = await platform.reanalyzeImportJob(job.id);
    ElMessage.success(`${updated.id} 已重新分析，置信度 ${updated.confidence}%`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '重新分析失败');
  }
}

async function convertImportJobToAlarm(job: ImportJob) {
  try {
    const result = await platform.convertImportJobToAlarm(job.id);
    ElMessage.success(`${result.job.id} 已生成告警 ${result.alarm.id} 和工单 ${result.workOrder.id}`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '导入任务转告警失败');
  }
}

async function deleteImportJob(job: ImportJob) {
  try {
    await platform.deleteImportJob(job.id);
    ElMessage.success(`${job.id} 已删除`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '导入任务删除失败');
  }
}

async function createStoragePolicy(payload?: Partial<StorageTier>) {
  try {
    const policy = await platform.createStoragePolicy(payload);
    ElMessage.success(`${policy.name} 已启用`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '存储策略保存失败');
  }
}

async function protectStoragePolicy(policy: StorageTier) {
  try {
    const updated = await platform.updateStoragePolicy(policy);
    ElMessage.success(`${updated.name} 已开启证据保护`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '存储策略更新失败');
  }
}

async function createReportTask() {
  try {
    const task = await platform.createReportTask();
    ElMessage.success(`${task.id} 已生成`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '报表任务生成失败');
  }
}

async function downloadReport() {
  try {
    const size = await platform.downloadReport();
    ElMessage.success(`报表 CSV 已导出（${Math.max(1, Math.round(size / 1024))}KB）`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '报表导出失败');
  }
}

async function createUserAccount() {
  try {
    const user = await platform.createUserAccount();
    ElMessage.success(`${user.name} 已启用`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '新增用户失败');
  }
}

async function toggleUserStatus(user: UserAccount) {
  try {
    const updated = await platform.toggleUserStatus(user);
    ElMessage.success(`${updated.name} 已${updated.status}`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '用户状态更新失败');
  }
}

async function saveRolePermissions() {
  try {
    const permission = await platform.saveRolePermissions();
    ElMessage.success(`${permission.roleName} 权限已保存`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : 'RBAC 保存失败');
  }
}

async function searchAuditLogs() {
  try {
    const job = await platform.searchAuditLogs();
    ElMessage.success(`${job.id} 已完成，命中 ${job.resultCount} 条`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '审计检索失败');
  }
}

async function exportAuditLogs() {
  try {
    const size = await platform.exportAuditLogs();
    ElMessage.success(`审计 CSV 已导出（${Math.max(1, Math.round(size / 1024))}KB）`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '审计导出失败');
  }
}

async function verifyOps(type: OpsRunType) {
  try {
    const run = await platform.verifyOps(type);
    ElMessage.success(`${run.name}：${run.status}，${run.manifestHash.slice(0, 18)}`);
  } catch (error) {
    ElMessage.error(error instanceof Error ? error.message : '运维验收执行失败');
  }
}

function opsTone(passed: boolean): 'green' | 'amber' {
  return passed ? 'green' : 'amber';
}

function resetPlayback() {
  playbackPlaying.value = false;
  playbackProgress.value = 0;
  playbackNotice.value = '已回到录像起点';
}

function selectPlaybackCamera(cameraId: string) {
  platform.selectCamera(cameraId);
  playbackPlaying.value = false;
  playbackProgress.value = 0;
  playbackPage.value = 1;
  const camera = platform.cameras.find((item) => item.id === cameraId);
  playbackNotice.value = `已切换到 ${camera?.name || cameraId} 录像`;
}

function resetPlaybackFilters() {
  playbackTypeFilter.value = '';
  playbackSeverityFilter.value = '';
  playbackStatusFilter.value = '';
  playbackPage.value = 1;
  playbackNotice.value = '已重置回放筛选条件';
}

function startPlayback() {
  playbackPlaying.value = true;
  playbackProgress.value = Math.max(playbackProgress.value, 1);
  playbackNotice.value = `正在播放 ${selectedCamera.value?.name || '当前设备'} 4K 原始录像`;
}

function pausePlayback() {
  playbackPlaying.value = false;
  playbackNotice.value = `已暂停在 ${playbackCurrentTime.value}`;
}

function locateSelectedAlarm() {
  const alarm = selectedAlarm.value || platform.alarms[0];
  if (alarm) openPlaybackAlarm(alarm);
}

function importStatusTone(status: ImportJob['status']) {
  if (status === '已完成' || status === '已转告警') return 'green';
  if (status === '失败') return 'red';
  return 'blue';
}

function goDiagnostics(camera: Camera) {
  platform.setDiagnosticDevice(camera.id);
  router.push('/diag');
  void platform.runDiagnostic();
}

function handleMapCameraSelect(camera: Camera) {
  platform.selectCamera(camera.id);
  openCameraPreview(camera.id, 'zoom');
}

function stepTone(step: DiagnosticStep) {
  if (step.state === 'ok') return 'green';
  if (step.state === 'warning') return 'amber';
  if (step.state === 'error') return 'red';
  return 'gray';
}

function ptsToProgress(pts: string): number {
  const seconds = timecodeToSeconds(pts);
  return Math.min(100, Math.max(0, Math.round((seconds / 3600) * 100)));
}

function progressToTime(progress: number): string {
  const seconds = Math.round((progress / 100) * 3600);
  const hour = Math.floor(seconds / 3600);
  const minute = Math.floor((seconds % 3600) / 60);
  const second = seconds % 60;
  return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}:${second.toString().padStart(2, '0')}`;
}

function timecodeToSeconds(value: string): number {
  const [hour = '0', minute = '0', rest = '0'] = value.split(':');
  return Number(hour) * 3600 + Number(minute) * 60 + Number.parseFloat(rest);
}

watch(page, () => {
  alarmDrawer.value = false;
  selectedAlarmSnapshot.value = null;
});

watch(playbackTotalPages, (total) => {
  if (playbackPage.value > total) playbackPage.value = total;
});

watch([playbackTypeFilter, playbackSeverityFilter, playbackStatusFilter], () => {
  playbackPage.value = 1;
});

  return {
    platform,
    alarmDrawer,
    operationDialog,
    operationAction,
    deviceDialog,
    deviceDialogMode,
    deviceSubmitting,
    uavAssetDialog,
    uavAssetDialogMode,
    uavAssetSubmitting,
    cameraPreviewDialog,
    cameraPreviewMode,
    cameraPreviewId,
    cameraTypeOptions,
    protocolOptions,
    inferenceNodeOptions,
    uavAssetStatusOptions,
    uavAssetModelOptions,
    deviceForm,
    uavAssetForm,
    page,
    pageTitle,
    selectedAlarm,
    selectedAggregateEvent,
    selectedCamera,
    mainTrend,
    playbackPageSize,
    playbackPage,
    playbackPlaying,
    playbackProgress,
    playbackNotice,
    playbackTypeFilter,
    playbackSeverityFilter,
    playbackStatusFilter,
    templateCoverage,
    algorithmAverageLatency,
    eventKpis,
    eventTypeStats,
    eventStatusStats,
    pageRecordCount,
    workOrderStats,
    latestEvidenceVerification,
    deviceRows,
    uavAssetRows,
    playbackTypeOptions,
    playbackSeverityOptions,
    playbackStatusOptions,
    playbackEvents,
    playbackTotalPages,
    pagedPlaybackEvents,
    playbackCurrentTime,
    selectedAlarmWorkOrder,
    selectedAlarmCamera,
    selectedAlarmEvidenceEvent,
    selectedAlarmEvidenceMedia,
    selectedAlarmEvidenceBoxes,
    selectedAlarmEvidenceTime,
    selectedAlarmEvidenceSource,
    selectedAlarmDeviceName,
    selectedAlarmUavTask,
    selectedAlarmEvidence,
    previewCamera,
    cameraPreviewTitle,
    cameraNameById,
    openAlarm,
    openPlaybackAlarm,
    alarmDeviceName,
    alarmReviewTitle,
    deviceNameById,
    workOrderDisplayTitle,
    uavTaskDisplayTitle,
    evidenceBundleDisplayName,
    openOperation,
    handleOperationDone,
    openCreateDevice,
    openEditDevice,
    resetDeviceForm,
    submitDeviceForm,
    deleteDevice,
    openCreateUavAsset,
    openEditUavAsset,
    resetUavAssetForm,
    submitUavAssetForm,
    deleteUavAsset,
    uavAssetPayloadFromForm,
    devicePayloadFromForm,
    parseCoordinate,
    cameraTypeOf,
    cameraCoordinate,
    streamUrlOf,
    evidenceBoxStyle,
    uavCoordinate,
    uavAssetStatusTone,
    channelNumber,
    reviewSelectedAlarm,
    ignoreRealtimeAlarm,
    dispatchRealtimeAlarm,
    findCameraAlarm,
    openCameraAlarm,
    openCameraMap,
    openCameraPreview,
    handleCameraAction,
    openAlarmRow,
    reviewAlarmRow,
    nextWorkOrderAction,
    startWorkOrderAction,
    archiveWorkOrderAction,
    advanceWorkOrder,
    startWorkOrder,
    archiveWorkOrder,
    remindWorkOrder,
    createEvidenceBundle,
    verifyEvidenceBundle,
    downloadEvidenceBundle,
    createImportJob,
    reanalyzeImportJob,
    convertImportJobToAlarm,
    deleteImportJob,
    createStoragePolicy,
    protectStoragePolicy,
    createReportTask,
    downloadReport,
    createUserAccount,
    toggleUserStatus,
    saveRolePermissions,
    searchAuditLogs,
    exportAuditLogs,
    verifyOps,
    opsTone,
    resetPlayback,
    selectPlaybackCamera,
    resetPlaybackFilters,
    startPlayback,
    pausePlayback,
    locateSelectedAlarm,
    importStatusTone,
    goDiagnostics,
    handleMapCameraSelect,
    stepTone,
    ptsToProgress,
    progressToTime,
    timecodeToSeconds,
    severityTone,
    statusTone,
    formatEventDateTime,
    progressOfWorkOrder,
    isSlaRisk,
  };
}

type WorkspaceContext = ReturnType<typeof createWorkspace>;
let instance: WorkspaceContext | null = null;

export function useWorkspace(): WorkspaceContext {
  if (!instance) instance = createWorkspace();
  return instance;
}
