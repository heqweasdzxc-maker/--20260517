import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import {
  eventQueueRows,
  formatEventDateTime,
  formatEventDuration,
  summarizeEventQueue,
} from '../services/eventGroups';
import type { AggregateEvent } from '../types';

describe('event situation queue', () => {
  it('formats complete date and time without losing the day', () => {
    expect(formatEventDateTime('2026-07-17T02:33:24.000Z')).toBe('2026-07-17 10:33:24');
  });

  it('sorts by latest occurrence and maps the latest alarm for review', () => {
    const rows = eventQueueRows([
      event({ id: 'EVT-1', latestAlarmId: 'A-1', latestOccurredAt: '2026-07-17T01:00:00.000Z' }),
      event({ id: 'EVT-2', latestAlarmId: 'A-2', latestOccurredAt: '2026-07-18T01:00:00.000Z' }),
    ], []);

    expect(rows.map((row) => row.id)).toEqual(['EVT-2', 'EVT-1']);
    expect(rows[0].reviewAlarmId).toBe('A-2');
    expect(rows[0].firstOccurredText).toBe('2026-07-17 09:00:00');
    expect(rows[0].latestOccurredText).toBe('2026-07-18 09:00:00');
  });

  it('reports dedupe hits as total occurrences minus open event count', () => {
    const summary = summarizeEventQueue([
      event({ id: 'EVT-1', occurrenceCount: 5 }),
      event({ id: 'EVT-2', occurrenceCount: 2 }),
    ], []);

    expect(summary.openCount).toBe(2);
    expect(summary.pendingCount).toBe(2);
    expect(summary.dedupeHits).toBe(5);
  });

  it('formats a stable elapsed duration', () => {
    expect(formatEventDuration('2026-07-17T01:00:00.000Z', '2026-07-18T03:05:06.000Z')).toBe('1天2小时');
    expect(formatEventDuration('2026-07-17T01:00:00.000Z', '2026-07-17T01:04:06.000Z')).toBe('4分钟');
  });

  it('keeps the operational table single-line with fixed columns and horizontal overflow', () => {
    const page = readFileSync(resolve('src/views/pages/EventsPage.vue'), 'utf8');
    const workspace = readFileSync(resolve('src/composables/useWorkspace.ts'), 'utf8');
    const styles = readFileSync(resolve('src/styles.css'), 'utf8');

    for (const heading of ['首次发生', '最近报警', '次数', '持续时间']) expect(page).toContain(`<th>${heading}</th>`);
    expect(page).toContain('record.reviewAlarmId');
    expect(page).not.toContain('platform.dedupedAlarms');
    expect(workspace).not.toContain('platform.dedupedAlarms');
    expect(workspace).toContain('events: (platform.events || []).length');
    expect(styles).toMatch(/\.event-table\s+table\s*\{[^}]*min-width:\s*1500px/s);
    expect(styles).toMatch(/\.event-table[^}]*overflow-x:\s*auto/s);
    expect(styles).toMatch(/\.event-table\s+(?:th|td)|\.event-table[^}]*white-space:\s*nowrap/s);
  });
});

function event(overrides: Partial<AggregateEvent> = {}): AggregateEvent {
  return {
    id: 'EVT-DEFAULT',
    dedupeKey: 'CH04:漂浮物',
    cameraId: 'CH04',
    cameraName: '4号桥东',
    type: '漂浮物',
    severity: '一般',
    status: '待研判',
    firstAlarmId: 'A-FIRST',
    latestAlarmId: 'A-LATEST',
    firstOccurredAt: '2026-07-17T01:00:00.000Z',
    latestOccurredAt: '2026-07-17T02:00:00.000Z',
    occurrenceCount: 1,
    firstConfidence: 70,
    latestConfidence: 72,
    maxConfidence: 72,
    ...overrides,
  };
}
