﻿import { defineStore } from 'pinia';
import { HttpError, apiUrl, getJson, postJson } from '../api/http';
import { createAlgorithmApiFromEnv, type AlgorithmPayload } from '../api/algorithmApi';
import { createAlarmApiFromEnv } from '../api/alarmApi';
import { createAuthApiFromEnv } from '../api/authApi';
import { createDeviceApiFromEnv, type DevicePayload } from '../api/deviceApi';
import { createEvidenceApiFromEnv } from '../api/evidenceApi';
import { createGovernanceApiFromEnv } from '../api/governanceApi';
import { createImportApiFromEnv, type ImportCreatePayload } from '../api/importApi';
import { createOpsApiFromEnv, type OpsRunType } from '../api/opsApi';
import { createPlatformApiFromEnv } from '../api/platformApi';
import { createTemplateApiFromEnv, type TemplatePayload } from '../api/templateApi';
import { createUavAssetApiFromEnv, type UavAssetPayload } from '../api/uavAssetApi';
import { createWorkorderApiFromEnv } from '../api/workorderApi';
import type { PlatformSnapshot } from '../types';
import type { Alarm, AlarmReviewAction, AlgorithmModel, Camera, DiagnosticStep, EvidenceBundle, ImportJob, OpsRun, OpsStatus, ReportTask, RolePermission, StorageTier, TemplateProfile, UavAsset, UserAccount, WorkOrder } from '../types';
import { closureRate, createClosedWorkOrderFromAlarm, dedupeAlarms, diagnoseDevice } from '../services/business';
import { detectionDerivedPendingAlarms, isRuntimeDetectionAlarmId, normalizeConfidencePercent, type ConfidenceThresholds } from '../services/realtimeAlarms';

const platformApi = createPlatformApiFromEnv();
const algorithmApi = createAlgorithmApiFromEnv();
const authApi = createAuthApiFromEnv();
const alarmApi = createAlarmApiFromEnv();
const deviceApi = createDeviceApiFromEnv();
const workorderApi = createWorkorderApiFromEnv();
const evidenceApi = createEvidenceApiFromEnv();
const importApi = createImportApiFromEnv();
const governanceApi = createGovernanceApiFromEnv();
const opsApi = createOpsApiFromEnv();
const templateApi = createTemplateApiFromEnv();
const uavAssetApi = createUavAssetApiFromEnv();
const useMockApi = import.meta.env.VITE_USE_MOCK_API === 'true';
const REALTIME_REFRESH_INTERVAL_MS = Number(import.meta.env.VITE_REALTIME_REFRESH_MS || 3000);
const REALTIME_ALARM_FEED_LIMIT = 15;
let realtimeRefreshTimer: number | null = null;

type SentinelRuntimeConfig = {
  enabled?: boolean;
  updatedAt?: string | null;
  updatedBy?: string;
  reason?: string;
};

function sanitizeConfidenceThresholds(value: unknown): ConfidenceThresholds {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  return Object.fromEntries(
    Object.entries(value)
      .map(([cameraId, raw]) => [String(cameraId).trim(), normalizeConfidencePercent(raw, 50)] as const)
      .filter(([cameraId]) => Boolean(cameraId)),
  );
}

function runtimeTimestamp(value?: string | null): number {
  if (!value) return 0;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function runtimeConfigValue<T = unknown>(runtimeConfig: PlatformSnapshot['runtimeConfig'], key: string): T | undefined {
  return runtimeConfig.find((item) => item.key === key)?.value as T | undefined;
}

function createDispatchId(seed = Date.now()) {
  return `DP-${String(seed).slice(-10)}`;
}

function nextLocalWorkOrderStatus(status: WorkOrder['status']): WorkOrder['status'] {
  if (status === '派单') return '处置';
  if (status === '处置') return '复核';
  return '归档';
}

function localWorkOrderActionName(status: WorkOrder['status']) {
  if (status === '处置') return '开始处置';
  if (status === '复核') return '提交复核';
  if (status === '归档') return '确认归档';
  return '确认派单';
}

function transitionLocalWorkOrder(order: WorkOrder): WorkOrder {
  const status = nextLocalWorkOrderStatus(order.status);
  const now = new Date().toISOString();
  const actionName = localWorkOrderActionName(status);
  const updated: WorkOrder = {
    ...order,
    status,
    elapsedHours: Number((order.elapsedHours + 1).toFixed(1)),
    lastAction: actionName,
    createdAt: order.createdAt || order.timeline?.[0]?.time || now,
    confirmedAt: order.confirmedAt || order.acceptedAt || (order.status === '派单' ? now : order.createdAt || now),
    updatedAt: now,
    slaState: status === '归档' ? '已闭环' : order.slaState,
    timeline: [
      ...(Array.isArray(order.timeline) ? order.timeline : []),
      {
        time: now,
        from: order.status,
        to: status,
        operator: '监管运营员',
        note: actionName,
      },
    ],
  };
  if (status === '处置') updated.startedAt = now;
  if (status === '复核') updated.reviewSubmittedAt = now;
  if (status === '归档') {
    updated.completedAt = now;
    updated.archivedAt = now;
  }
  return updated;
}

function startLocalWorkOrder(order: WorkOrder): WorkOrder {
  if (order.status !== '派单') throw new Error(`工单 ${order.id} 不能从 ${order.status} 流转到 处置`);
  return transitionLocalWorkOrder(order);
}

function archiveLocalWorkOrder(order: WorkOrder): WorkOrder {
  const now = new Date().toISOString();
  const actionName = '确认归档';
  return {
    ...order,
    status: '归档',
    elapsedHours: Number((order.elapsedHours + 0.1).toFixed(1)),
    lastAction: actionName,
    createdAt: order.createdAt || order.timeline?.[0]?.time || now,
    confirmedAt: order.confirmedAt || order.acceptedAt || order.createdAt || now,
    updatedAt: now,
    completedAt: now,
    archivedAt: now,
    slaState: '已闭环',
    timeline: [
      ...(Array.isArray(order.timeline) ? order.timeline : []),
      {
        time: now,
        from: order.status,
        to: '归档',
        operator: '监管运营员',
        note: '工单闭环确认归档',
      },
    ],
  };
}

function compactOpsRuns(runs: OpsRun[]): OpsRun[] {
  return runs.filter((run): run is OpsRun => Boolean(run?.id));
}

type AlarmFlowState = Pick<PlatformSnapshot, 'cameras' | 'alarms'> & {
  dismissedRuntimeDetectionAlarmIds: string[];
  dispatchedRealtimeAlarmIds: string[];
  realtimeOverflowAlarmRows: Alarm[];
  persistedRealtimeOverflowAlarmIds: string[];
  persistingRealtimeOverflowAlarmIds: string[];
  confidenceThresholds: ConfidenceThresholds;
};

function realtimeFeedSplitForState(state: AlarmFlowState) {
  const dispatched = new Set(state.dispatchedRealtimeAlarmIds);
  const rows = activeAlarmRowsForState(state).filter((alarm) => !dispatched.has(alarm.id));
  return {
    current: rows.slice(0, REALTIME_ALARM_FEED_LIMIT),
    overflow: rows.slice(REALTIME_ALARM_FEED_LIMIT),
  };
}

function currentRealtimeRowsForState(state: AlarmFlowState): Alarm[] {
  return realtimeFeedSplitForState(state).current;
}

function alarmCenterRowsForState(state: AlarmFlowState, includeArchived = false): Alarm[] {
  const rows = uniqueAlarmsById(state.alarms).sort(compareRealtimeAlarmRows);
  return includeArchived ? rows : rows.filter((alarm) => !isArchivedOrFalsePositiveAlarm(alarm));
}

function activeAlarmCenterRowsForState(state: AlarmFlowState): Alarm[] {
  return alarmCenterRowsForState(state);
}

function uniqueAlarmsById(alarms: Alarm[]): Alarm[] {
  const seen = new Set<string>();
  const rows: Alarm[] = [];
  for (const alarm of alarms) {
    if (seen.has(alarm.id)) continue;
    seen.add(alarm.id);
    rows.push(alarm);
  }
  return rows;
}

function activeAlarmRowsForState(state: AlarmFlowState): Alarm[] {
  return alarmCenterRowsForState(state).sort(compareRealtimeAlarmRows);
}

function isArchivedOrFalsePositiveAlarm(alarm: Alarm) {
  const normalized = String(alarm.status || '').trim().toLowerCase();
  return (
    normalized === '已归档' ||
    normalized === '误报' ||
    normalized === 'archived' ||
    normalized === 'false-positive' ||
    normalized.includes('归档') ||
    normalized.includes('误报') ||
    normalized.includes('archive') ||
    normalized.includes('false')
  );
}

function compareRealtimeAlarmRows(a: Alarm, b: Alarm) {
  const timeDiff = alarmSortTimestamp(b) - alarmSortTimestamp(a);
  if (timeDiff !== 0) return timeDiff;
  return b.id.localeCompare(a.id, 'zh-CN', { numeric: true });
}

function alarmSortTimestamp(alarm: Alarm) {
  const parsed = Date.parse(String(alarm.updatedAt || alarm.createdAt || ''));
  if (Number.isFinite(parsed)) return parsed;
  const parts = String(alarm.time || '').match(/\d+/g)?.map(Number) || [];
  const [hh = 0, mm = 0, ss = 0] = parts.slice(-3);
  return hh * 3600 + mm * 60 + ss;
}

const emptySnapshot: PlatformSnapshot = {
  cameras: [],
  alarms: [],
  events: [],
  workOrders: [],
  templates: [],
  algorithms: [],
  uavTasks: [],
  uavAssets: [],
  evidenceBundles: [],
  importJobs: [],
  storageTiers: [],
  reportMetrics: [],
  reportTasks: [],
  users: [],
  rolePermissions: [],
  exportTasks: [],
  logs: [],
  logSearchJobs: [],
  opsRuns: [],
  operationTasks: [],
  aiEvents: [],
  navItems: [],
  diagnostics: { healthy: [], failed: [] },
  aiWorkers: [],
  operationRoutes: [],
  operationProfiles: {},
  operationSpecialSpecs: {},
  runtimeConfig: [],
};

export const usePlatformStore = defineStore('platform', {
  state: () => {
    const storedToken = readStoredToken();

    return {
    isAuthenticated: Boolean(storedToken),
    isLoading: false,
    loadError: '',
    authToken: storedToken,
    currentUser: '监管运营员',
    userRole: '监管运营员',
    userPermissions: [] as string[],
    tenant: '市生态环境局 / 河道监管中心',
    sentinelEnabled: true,
    sentinelUpdatedAt: '',
    confidenceThresholds: {} as ConfidenceThresholds,
    gridMode: 4 as 1 | 4 | 9,
    videoPage: 1,
    selectedAlarmId: 'A-20652',
    selectedCameraId: 'CH03',
    dismissedRuntimeDetectionAlarmIds: [] as string[],
    dispatchedRealtimeAlarmIds: [] as string[],
    realtimeOverflowAlarmRows: [] as Alarm[],
    persistedRealtimeOverflowAlarmIds: [] as string[],
    persistingRealtimeOverflowAlarmIds: [] as string[],
    diagnosticDeviceId: 'CH11',
    diagnosticRunning: false,
    diagnosticResultDeviceId: '',
    diagnosticResultSteps: [] as DiagnosticStep[],
    opsStatus: null as OpsStatus | null,
    opsRunningAction: '' as OpsRunType | '',
    ...emptySnapshot,
  };
  },
  getters: {
    // 按钮级 RBAC：后端返回权限码时按码校验；未加载（演示/未登录）时放行，避免演示态全锁。
    hasPermission(state) {
      return (code: string): boolean => {
        const perms = state.userPermissions;
        if (!perms.length) return true;
        return perms.includes('*') || perms.includes(code);
      };
    },
    activeCamera(state): Camera | undefined {
      return state.cameras.find((camera) => camera.id === state.selectedCameraId) ?? state.cameras[0];
    },
    visibleCameras(state): Camera[] {
      const totalPages = Math.max(1, Math.ceil(state.cameras.length / state.gridMode));
      const page = Math.min(Math.max(1, state.videoPage), totalPages);
      const start = (page - 1) * state.gridMode;
      return state.cameras.slice(start, start + state.gridMode);
    },
    videoTotalPages(state): number {
      return Math.max(1, Math.ceil(state.cameras.length / state.gridMode));
    },
    effectiveVideoPage(state): number {
      const totalPages = Math.max(1, Math.ceil(state.cameras.length / state.gridMode));
      return Math.min(Math.max(1, state.videoPage), totalPages);
    },
    videoWindowStart(state): number {
      if (state.cameras.length === 0) return 0;
      const totalPages = Math.max(1, Math.ceil(state.cameras.length / state.gridMode));
      const page = Math.min(Math.max(1, state.videoPage), totalPages);
      return (page - 1) * state.gridMode + 1;
    },
    videoWindowEnd(state): number {
      if (state.cameras.length === 0) return 0;
      const totalPages = Math.max(1, Math.ceil(state.cameras.length / state.gridMode));
      const page = Math.min(Math.max(1, state.videoPage), totalPages);
      return Math.min(state.cameras.length, page * state.gridMode);
    },
    cameraStatusSource(): string {
      return useMockApi ? '演示快照 status' : '数据库 rw_camera.status';
    },
    abnormalCameras(state): Camera[] {
      return state.cameras.filter((camera) => camera.detections.length > 0 || camera.status === '链路异常');
    },
    selectedAlarm(state): Alarm | undefined {
      return (
        state.alarms.find((alarm) => alarm.id === state.selectedAlarmId) ||
        detectionDerivedPendingAlarms(state.cameras, state.alarms, state.dismissedRuntimeDetectionAlarmIds, state.confidenceThresholds).find((alarm) => alarm.id === state.selectedAlarmId)
      );
    },
    dedupedAlarms(state): Alarm[] {
      return dedupeAlarms(activeAlarmCenterRowsForState(state));
    },
    alarmRows(state): Alarm[] {
      return alarmCenterRowsForState(state);
    },
    alarmHistoryRows(state): Alarm[] {
      return alarmCenterRowsForState(state, true);
    },
    pendingAlarms(state): Alarm[] {
      return currentRealtimeRowsForState(state);
    },
    navBadgeByKey(state): Record<string, string> {
      const pendingAlarmCount = currentRealtimeRowsForState(state).length;
      const alarmCenterCount = activeAlarmCenterRowsForState(state).length;

      return {
        monitor: formatNavBadge(pendingAlarmCount),
        alarms: formatNavBadge(alarmCenterCount),
      };
    },
    diagnosticSteps(state) {
      if (state.diagnosticResultDeviceId === state.diagnosticDeviceId && state.diagnosticResultSteps.length > 0) {
        return state.diagnosticResultSteps;
      }
      const camera = state.cameras.find((item) => item.id === state.diagnosticDeviceId);
      return diagnoseDevice(camera?.status ?? '在线', state.diagnostics);
    },
    kpis(state) {
      const online = state.cameras.filter((camera) => camera.status === '在线').length;
      const urgent = state.alarms.filter((alarm) => alarm.severity === '紧急' && alarm.status !== '已归档').length;
      const activeOrders = state.workOrders.filter((order) => order.status !== '归档').length;
      const load = state.algorithms.length
        ? Math.round(state.algorithms.reduce((sum, model) => sum + model.utilization, 0) / state.algorithms.length)
        : 0;

      return [
        { label: '在线通道', value: `${online}/${state.cameras.length}`, hint: 'GB28181/RTSP 混合接入', tone: 'blue' },
        { label: '实时告警', value: `${state.alarms.length}`, hint: `紧急 ${urgent} 条`, tone: 'red' },
        { label: '闭环率', value: `${closureRate(state.workOrders)}%`, hint: '工单归档口径', tone: 'green' },
        { label: 'C9 平均负载', value: `${load}%`, hint: '边缘推理池', tone: 'amber' },
        { label: '今日复查', value: `${state.uavTasks.length}`, hint: '无人机任务', tone: 'violet' },
        { label: '证据包', value: `${state.evidenceBundles.length}`, hint: '哈希固化', tone: 'slate' },
      ];
    },
  },
  actions: {
    async bootstrap() {
      if (this.cameras.length > 0 || this.isLoading) return;
      await this.refresh();
    },
    async refresh() {
      this.isLoading = true;
      this.loadError = '';

      try {
        const response = await platformApi.getSnapshot();
        this.$patch(response.data);
        this.syncSentinelModeFromRuntimeConfig();
        this.syncConfidenceThresholdsFromRuntimeConfig();
        await this.refreshOpsStatus();
      } catch (error) {
        if (isUnauthorizedError(error)) {
          this.logout();
          this.$patch(emptySnapshot);
          this.loadError = '登录已过期，请重新登录';
        } else {
          this.loadError = error instanceof Error ? error.message : '平台数据加载失败';
        }
      } finally {
        this.isLoading = false;
      }
    },
    async refreshRuntimeSnapshot() {
      if (!this.isAuthenticated) return;

      try {
        const response = await platformApi.getSnapshot();
        this.$patch(response.data);
        this.syncSentinelModeFromRuntimeConfig();
        this.syncConfidenceThresholdsFromRuntimeConfig();
        this.loadError = '';
      } catch (error) {
        if (isUnauthorizedError(error)) {
          this.logout();
          this.$patch(emptySnapshot);
          this.loadError = '登录已过期，请重新登录';
        }
      }
    },
    startRealtimeRefresh() {
      if (useMockApi || typeof window === 'undefined' || realtimeRefreshTimer !== null) return;
      realtimeRefreshTimer = window.setInterval(() => {
        void this.refreshRuntimeSnapshot();
      }, REALTIME_REFRESH_INTERVAL_MS);
    },
    stopRealtimeRefresh() {
      if (typeof window === 'undefined' || realtimeRefreshTimer === null) return;
      window.clearInterval(realtimeRefreshTimer);
      realtimeRefreshTimer = null;
    },
    syncSentinelModeFromRuntimeConfig() {
      const config = runtimeConfigValue<SentinelRuntimeConfig>(this.runtimeConfig || [], 'sentinelMode');
      this.applySentinelMode(config);
    },
    syncConfidenceThresholdsFromRuntimeConfig() {
      const config = runtimeConfigValue<ConfidenceThresholds>(this.runtimeConfig || [], 'confidenceThresholds');
      this.confidenceThresholds = sanitizeConfidenceThresholds(config);
    },
    confidenceThresholdFor(cameraId: string) {
      return normalizeConfidencePercent(this.confidenceThresholds[cameraId], 50);
    },
    async saveConfidenceThreshold(cameraId: string, value: number) {
      const nextValue = normalizeConfidencePercent(value, 50);
      this.confidenceThresholds = {
        ...this.confidenceThresholds,
        [cameraId]: nextValue,
      };
      if (useMockApi) return this.confidenceThresholds;

      const response = await postJson<ConfidenceThresholds>(apiUrl('/runtime/confidence-thresholds'), {
        cameraId,
        value: nextValue,
      });
      this.confidenceThresholds = sanitizeConfidenceThresholds(response.data);
      return this.confidenceThresholds;
    },
    applySentinelMode(config?: SentinelRuntimeConfig, force = false) {
      if (typeof config?.enabled !== 'boolean') return;
      const incomingUpdatedAt = config.updatedAt || '';
      const incomingTime = runtimeTimestamp(incomingUpdatedAt);
      const currentTime = runtimeTimestamp(this.sentinelUpdatedAt);
      if (!force && currentTime > 0 && incomingTime > 0 && incomingTime < currentTime) return;
      this.sentinelEnabled = config.enabled;
      if (incomingUpdatedAt) this.sentinelUpdatedAt = incomingUpdatedAt;
    },
    async refreshSentinelMode() {
      if (useMockApi) return this.sentinelEnabled;
      const response = await getJson<SentinelRuntimeConfig>(apiUrl('/runtime/sentinel'));
      this.applySentinelMode(response.data, true);
      return this.sentinelEnabled;
    },
    async setSentinelEnabled(enabled: boolean) {
      const previous = this.sentinelEnabled;
      this.sentinelEnabled = enabled;
      if (useMockApi) return;

      try {
        const response = await postJson<SentinelRuntimeConfig>(apiUrl('/runtime/sentinel'), {
          enabled,
          updatedBy: this.currentUser,
        });
        this.applySentinelMode(response.data, true);
        await this.refreshRuntimeSnapshot();
        this.applySentinelMode(response.data, true);
      } catch (error) {
        this.sentinelEnabled = previous;
        throw error;
      }
    },
    async login(username: string, password = '123456') {
      const loginName = username || 'admin';
      const loginPassword = password.trim() || '123456';

      try {
        const response = await authApi.login(loginName, loginPassword);
        this.authToken = response.data.token;
        this.currentUser = response.data.user.name || loginName;
        this.userRole = response.data.user.role || this.userRole;
        this.userPermissions = Array.isArray(response.data.user.permissions) ? response.data.user.permissions : [];
        this.tenant = response.data.user.tenant || this.tenant;
        this.isAuthenticated = true;
        writeStoredToken(this.authToken);
        await this.bootstrap();
      } catch (error) {
        this.loadError = error instanceof Error ? error.message : '登录失败';
        throw error;
      }
    },
    logout() {
      this.isAuthenticated = false;
      this.authToken = '';
      this.userPermissions = [];
      this.realtimeOverflowAlarmRows = [];
      this.persistedRealtimeOverflowAlarmIds = [];
      this.persistingRealtimeOverflowAlarmIds = [];
      this.stopRealtimeRefresh();
      writeStoredToken('');
    },
    syncRealtimeOverflowAlarmRows() {
      this.realtimeOverflowAlarmRows = [];
      return this.realtimeOverflowAlarmRows;
    },
    async persistRealtimeOverflowAlarmRows() {
      this.syncRealtimeOverflowAlarmRows();
      this.persistedRealtimeOverflowAlarmIds = [];
      this.persistingRealtimeOverflowAlarmIds = [];
      return [];
    },
    ensureRealtimeDetectionAlarm(id: string): Alarm | undefined {
      const existing = this.alarms.find((item) => item.id === id);
      if (existing) return existing;

      const runtimeAlarm = detectionDerivedPendingAlarms(this.cameras, this.alarms, this.dismissedRuntimeDetectionAlarmIds, this.confidenceThresholds).find((item) => item.id === id);
      if (!runtimeAlarm) return undefined;
      this.alarms.unshift(runtimeAlarm);
      return runtimeAlarm;
    },
    selectAlarm(id: string) {
      this.selectedAlarmId = id;
      const alarm = this.ensureRealtimeDetectionAlarm(id);
      if (alarm) this.selectedCameraId = alarm.cameraId;
    },
    markRealtimeAlarmDispatched(id: string) {
      if (id && !this.dispatchedRealtimeAlarmIds.includes(id)) {
        this.dispatchedRealtimeAlarmIds.push(id);
      }
    },
    async dispatchRealtimeAlarmToAlarmCenter(id: string) {
      const alarm = this.ensureRealtimeDetectionAlarm(id);
      if (!alarm) return undefined;

      const now = new Date().toISOString();
      alarm.status = '已派单';
      alarm.dispatchId ||= createDispatchId();
      alarm.dispatchedAt ||= now;
      delete alarm.reviewResult;

      this.markRealtimeAlarmDispatched(alarm.id);

      if (!useMockApi) {
        const response = await alarmApi.createAlarm({ ...alarm, source: 'realtime-dispatch' } as Alarm & { source: string });
        Object.assign(alarm, response.data);
        this.markRealtimeAlarmDispatched(response.data.id);
        await this.refresh();
      }

      this.selectedAlarmId = alarm.id;
      this.selectedCameraId = alarm.cameraId;
      return alarm;
    },
    selectCamera(id: string) {
      this.selectedCameraId = id;
    },
    setGridMode(mode: 1 | 4 | 9) {
      this.gridMode = mode;
      this.setVideoPage(1);
    },
    setVideoPage(page: number) {
      const totalPages = Math.max(1, Math.ceil(this.cameras.length / this.gridMode));
      this.videoPage = Math.min(Math.max(1, page), totalPages);
    },
    async reviewAlarm(id: string, status: AlarmReviewAction) {
      const alarm = this.ensureRealtimeDetectionAlarm(id);
      if (!alarm) return;
      const archived = status === '忽略' || status === '已处理';
      let responseData: Alarm;

      if (isRuntimeDetectionAlarmId(id)) {
        if (!useMockApi) {
          await alarmApi.createAlarm({ ...alarm, source: 'realtime-review' } as Alarm & { source: string });
          responseData = (await alarmApi.reviewAlarm(id, status)).data;
        } else {
          responseData = { ...alarm, status: archived ? '已归档' : status, reviewResult: status };
        }
      } else {
        responseData = (await alarmApi.reviewAlarm(id, status)).data;
      }
      Object.assign(alarm, responseData);

      if (archived) {
        if (isRuntimeDetectionAlarmId(id) && !this.dismissedRuntimeDetectionAlarmIds.includes(id)) {
          this.dismissedRuntimeDetectionAlarmIds.push(id);
        }
        const camera = this.cameras.find((item) => item.id === alarm.cameraId);
        const normalizedAlarm = { ...alarm, cameraName: camera?.name || alarm.cameraName };
        const closedOrder = createClosedWorkOrderFromAlarm(normalizedAlarm, 9130 + this.workOrders.length, status);
        this.workOrders = this.workOrders.filter((order) => order.alarmId !== id);
        this.replaceWorkOrder(closedOrder);
        alarm.status = '已归档';
        alarm.reviewResult = status;
      }

      if (responseData.status === '已确认' || responseData.status === '已派单') alarm.status = '已派单';
      if (!useMockApi) await this.refresh();
    },
    async advanceWorkOrder(id: string) {
      try {
        const response = await workorderApi.transitionWorkorder(id, {
          action: 'next',
          operator: this.currentUser,
        });
        this.replaceWorkOrder(response.data);
        if (!useMockApi) await this.refresh();
        return response.data;
      } catch (error) {
        if (!useMockApi) throw error;
        const order = this.workOrders.find((item) => item.id === id);
        if (!order) throw error;
        const updated = transitionLocalWorkOrder(order);
        this.replaceWorkOrder(updated);
        return updated;
      }
    },
    async startWorkOrder(id: string) {
      try {
        const response = await workorderApi.transitionWorkorder(id, {
          action: 'start',
          operator: this.currentUser,
        });
        this.replaceWorkOrder(response.data);
        if (!useMockApi) await this.refresh();
        return response.data;
      } catch (error) {
        if (!useMockApi) throw error;
        const order = this.workOrders.find((item) => item.id === id);
        if (!order) throw error;
        const updated = startLocalWorkOrder(order);
        this.replaceWorkOrder(updated);
        return updated;
      }
    },
    async archiveWorkOrder(id: string) {
      try {
        const response = await workorderApi.transitionWorkorder(id, {
          action: 'close',
          operator: this.currentUser,
          note: '工单闭环确认归档',
        });
        this.replaceWorkOrder(response.data);
        if (!useMockApi) await this.refresh();
        return response.data;
      } catch (error) {
        if (!useMockApi) throw error;
        const order = this.workOrders.find((item) => item.id === id);
        if (!order) throw error;
        const updated = archiveLocalWorkOrder(order);
        this.replaceWorkOrder(updated);
        return updated;
      }
    },
    async remindWorkOrder(id: string) {
      const response = await workorderApi.remindWorkorder(id, {
        operator: this.currentUser,
        note: '现场处置 SLA 催办',
      });
      this.replaceWorkOrder(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    replaceWorkOrder(order: WorkOrder) {
      const index = this.workOrders.findIndex((item) => item.id === order.id);
      if (index >= 0) this.workOrders.splice(index, 1, order);
      else this.workOrders.unshift(order);
    },
    async createDevice(payload: DevicePayload) {
      const response = await deviceApi.createDevice(payload);
      this.replaceCamera(response.data);
      this.selectedCameraId = response.data.id;
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async updateDevice(id: string, payload: DevicePayload) {
      const response = await deviceApi.updateDevice(id, payload);
      this.replaceCamera(response.data);
      this.selectedCameraId = response.data.id;
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async deleteDevice(id: string) {
      const response = await deviceApi.deleteDevice(id);
      this.cameras = this.cameras.filter((camera) => camera.id !== id);
      if (this.selectedCameraId === id) this.selectedCameraId = this.cameras[0]?.id || '';
      if (this.diagnosticDeviceId === id) this.diagnosticDeviceId = this.cameras[0]?.id || '';
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    replaceCamera(camera: Camera) {
      const index = this.cameras.findIndex((item) => item.id === camera.id);
      if (index >= 0) this.cameras.splice(index, 1, camera);
      else this.cameras.unshift(camera);
    },
    async createUavAsset(payload: UavAssetPayload) {
      const response = await uavAssetApi.createAsset(payload);
      this.replaceUavAsset(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async updateUavAsset(id: string, payload: UavAssetPayload) {
      const response = await uavAssetApi.updateAsset(id, payload);
      this.replaceUavAsset(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async deleteUavAsset(id: string) {
      const response = await uavAssetApi.deleteAsset(id);
      this.uavAssets = this.uavAssets.filter((asset) => asset.id !== id);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    replaceUavAsset(asset: UavAsset) {
      const index = this.uavAssets.findIndex((item) => item.id === asset.id);
      if (index >= 0) this.uavAssets.splice(index, 1, asset);
      else this.uavAssets.unshift(asset);
    },
    async createAlgorithmModel(payload: AlgorithmPayload) {
      const response = await algorithmApi.createModel(payload);
      this.replaceAlgorithm(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async updateAlgorithmModel(id: string, payload: AlgorithmPayload) {
      const response = await algorithmApi.updateModel(id, payload);
      this.replaceAlgorithm(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    replaceAlgorithm(model: AlgorithmModel) {
      const index = this.algorithms.findIndex((item) => item.id === model.id);
      if (index >= 0) this.algorithms.splice(index, 1, model);
      else this.algorithms.unshift(model);
    },
    async createTemplateProfile(payload: TemplatePayload) {
      const response = await templateApi.createTemplate(payload);
      this.replaceTemplate(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async updateTemplateProfile(id: string, payload: TemplatePayload) {
      const response = await templateApi.updateTemplate(id, payload);
      this.replaceTemplate(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async deleteTemplateProfile(id: string) {
      const response = await templateApi.deleteTemplate(id);
      this.templates = this.templates.filter((item) => item.id !== id);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    replaceTemplate(template: TemplateProfile) {
      const index = this.templates.findIndex((item) => item.id === template.id);
      if (index >= 0) this.templates.splice(index, 1, template);
      else this.templates.unshift(template);
    },
    async createEvidenceBundle(alarmId?: string) {
      const candidateAlarms = alarmCenterRowsForState(this, true);
      const alarm = alarmId
        ? candidateAlarms.find((item) => item.id === alarmId)
        : this.selectedAlarm;
      if (!alarm) throw new Error('请先选择要组卷的告警消息');
      const workOrder = this.workOrders.find((order) => order.alarmId === alarm?.id) || this.workOrders[0];
      const camera = alarm ? this.cameras.find((item) => item.id === alarm.cameraId) : undefined;
      const deviceName = camera?.name || alarm?.cameraName || '现场设备';
      const response = await evidenceApi.createBundle({
        alarmId: alarm?.id,
        workOrderId: workOrder?.id,
        name: `${deviceName} ${alarm?.type || '异常'}证据包`,
        materials: ['原始视频', 'AI 抓拍', 'PTS 元数据', '研判记录', '工单记录'],
      });
      this.replaceEvidenceBundle(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async verifyEvidenceBundle(id: string) {
      const response = await evidenceApi.verifyBundle(id);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async downloadEvidenceBundle(id: string) {
      const blob = await evidenceApi.downloadBundle(id);
      if (typeof window !== 'undefined') {
        const url = window.URL.createObjectURL(blob);
        const anchor = window.document.createElement('a');
        anchor.href = url;
        anchor.download = `${id}.zip`;
        anchor.click();
        window.URL.revokeObjectURL(url);
      }
      if (!useMockApi) await this.refresh();
      return blob.size;
    },
    replaceEvidenceBundle(bundle: EvidenceBundle) {
      const index = this.evidenceBundles.findIndex((item) => item.id === bundle.id);
      if (index >= 0) this.evidenceBundles.splice(index, 1, bundle);
      else this.evidenceBundles.unshift(bundle);
    },
    async createImportJob(payload: ImportCreatePayload = {}) {
      const response = await importApi.createJob({
        source: payload.source || `第三方巡河视频-${new Date().toISOString().slice(5, 10)}.mp4`,
        sourceLocation: payload.sourceLocation || '本地磁盘',
        sourcePath: payload.sourcePath || payload.source,
        fileCount: payload.fileCount || 1,
        totalSize: payload.totalSize || 0,
        type: payload.type || '视频',
        algorithm: payload.algorithm || 'YOLO26 导入/无人机',
        cameraId: payload.cameraId || this.selectedCameraId || 'CH03',
        confidence: payload.confidence,
        result: payload.result,
      });
      this.replaceImportJob(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async reanalyzeImportJob(id: string) {
      const response = await importApi.reanalyzeJob(id, { algorithm: 'YOLO26 导入/无人机' });
      this.replaceImportJob(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async convertImportJobToAlarm(id: string) {
      const response = await importApi.convertToAlarm(id);
      this.replaceImportJob(response.data.job);
      if (response.data.alarm) {
        const alarmIndex = this.alarms.findIndex((item) => item.id === response.data.alarm.id);
        if (alarmIndex >= 0) this.alarms.splice(alarmIndex, 1, response.data.alarm);
        else this.alarms.unshift(response.data.alarm);
      }
      if (response.data.workOrder) this.replaceWorkOrder(response.data.workOrder);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async deleteImportJob(id: string) {
      const response = await importApi.deleteJob(id);
      this.importJobs = this.importJobs.filter((item) => item.id !== id);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    replaceImportJob(job: ImportJob) {
      const index = this.importJobs.findIndex((item) => item.id === job.id);
      if (index >= 0) this.importJobs.splice(index, 1, job);
      else this.importJobs.unshift(job);
    },
    async createStoragePolicy(payload: Partial<StorageTier> = {}) {
      const retentionDays = Number(payload.retentionDays ?? (payload.protectedEvidence ? 3650 : 0));
      const alertThreshold = Number(payload.alertThreshold ?? 75);
      const tier = payload.tier || 'message';
      const response = await governanceApi.createStoragePolicy({
        name: payload.name || (payload.rawVideoStoredHere === false ? '硬盘录像机录像引用' : '异常消息存储'),
        tier,
        usage: Number(payload.usage ?? 0),
        quota: payload.quota || (payload.rawVideoStoredHere === false ? '由NVR/DVR管理' : '1TB'),
        policy:
          payload.policy ||
          (payload.rawVideoStoredHere === false
            ? '系统只保存录像路径、片段时间戳和证据索引；不管理原始录像容量'
            : '仅保存异常判断、AI 元数据、告警、通知、工单、证据索引和回放片段引用；达到 1TB 后按先入先出覆盖最早消息'),
        protectedEvidence: Boolean(payload.protectedEvidence),
        retentionDays,
        alertThreshold,
        retentionMode: payload.retentionMode || (payload.rawVideoStoredHere === false ? undefined : 'fifo'),
        recordingOwner: payload.recordingOwner || (payload.rawVideoStoredHere === false ? 'NVR/DVR' : undefined),
        rawVideoStoredHere: payload.rawVideoStoredHere,
        quotaBytes: payload.quotaBytes,
        lifecycle: payload.lifecycle || (payload.rawVideoStoredHere === false ? 'NVR managed recording path reference' : '1TB FIFO message metadata retention'),
      });
      this.replaceStoragePolicy(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async updateStoragePolicy(policy: StorageTier) {
      const id = policy.id || policy.name;
      const response = await governanceApi.updateStoragePolicy(id, {
        ...policy,
        protectedEvidence: true,
        retentionDays: policy.protectedEvidence ? policy.retentionDays || 3650 : 3650,
        alertThreshold: policy.alertThreshold || 75,
      });
      this.replaceStoragePolicy(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    replaceStoragePolicy(policy: StorageTier) {
      const index = this.storageTiers.findIndex((item) => item.id === policy.id || item.name === policy.name);
      if (index >= 0) this.storageTiers.splice(index, 1, policy);
      else this.storageTiers.unshift(policy);
    },
    async createReportTask() {
      const response = await governanceApi.createReportTask({
        name: '河道监管闭环周报',
        type: '闭环周报',
        format: 'PDF+Excel',
        schedule: '每周一 09:00',
      });
      this.replaceReportTask(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async downloadReport() {
      const blob = await governanceApi.downloadReport('闭环周报');
      downloadBlob(blob, `river-watch-report-${Date.now()}.csv`);
      return blob.size;
    },
    replaceReportTask(task: ReportTask) {
      this.reportTasks ||= [];
      const index = this.reportTasks.findIndex((item) => item.id === task.id);
      if (index >= 0) this.reportTasks.splice(index, 1, task);
      else this.reportTasks.unshift(task);
    },
    async createUserAccount(payload: Partial<UserAccount> = {}) {
      const response = await governanceApi.createUser({
        name: '现场审计账号',
        role: '审计访客',
        org: '审计单位',
        scope: '只读审计',
        ...payload,
      });
      this.replaceUser(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async updateUserAccount(id: string, payload: Partial<UserAccount>) {
      const response = await governanceApi.updateUser(id, payload);
      this.replaceUser(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async toggleUserStatus(user: UserAccount) {
      const nextStatus = user.status === '启用' ? '停用' : '启用';
      const response = await governanceApi.toggleUserStatus(user.id, nextStatus);
      this.replaceUser(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async deleteUserAccount(id: string) {
      const response = await governanceApi.deleteUser(id);
      this.users = this.users.filter((item) => item.id !== id);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    replaceUser(user: UserAccount) {
      const index = this.users.findIndex((item) => item.id === user.id);
      if (index >= 0) this.users.splice(index, 1, user);
      else this.users.unshift(user);
    },
    async saveRolePermissions(roleId = 'operator', payload: Partial<RolePermission> = {}) {
      const response = await governanceApi.saveRolePermissions(roleId, {
        roleName: '监管运营员',
        dataScope: '所属片区',
        permissions: ['实时视频墙', '告警研判', '工单闭环', '证据下载', '报表查看'],
        ...payload,
      });
      this.replaceRolePermission(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    replaceRolePermission(permission: RolePermission) {
      this.rolePermissions ||= [];
      const index = this.rolePermissions.findIndex((item) => item.roleId === permission.roleId);
      if (index >= 0) this.rolePermissions.splice(index, 1, permission);
      else this.rolePermissions.unshift(permission);
    },
    async searchAuditLogs() {
      const response = await governanceApi.searchLogs({ query: '成功', retentionMonths: 6, archiveMonths: 24 });
      this.logSearchJobs ||= [];
      this.logSearchJobs.unshift(response.data);
      if (!useMockApi) await this.refresh();
      return response.data;
    },
    async exportAuditLogs() {
      const blob = await governanceApi.downloadAuditLogs('成功');
      downloadBlob(blob, `river-watch-audit-${Date.now()}.csv`);
      return blob.size;
    },
    async refreshOpsStatus() {
      const response = await opsApi.getStatus();
      this.opsStatus = response.data;
      this.opsRuns = compactOpsRuns(response.data.runs || this.opsRuns || []);
      return response.data;
    },
    async verifyOps(type: OpsRunType) {
      this.opsRunningAction = type;
      try {
        const response = await opsApi.verify(type, { operator: this.currentUser, source: 'frontend-ops-panel' });
        this.replaceOpsRun(response.data);
        await this.refreshOpsStatus();
        return response.data;
      } finally {
        this.opsRunningAction = '';
      }
    },
    replaceOpsRun(run: OpsRun) {
      const current = compactOpsRuns(this.opsRuns || []);
      this.opsRuns = [run, ...current.filter((item) => item.id !== run.id)];
    },
    setDiagnosticDevice(id: string) {
      this.diagnosticDeviceId = id;
      this.diagnosticResultDeviceId = '';
      this.diagnosticResultSteps = [];
    },
    async runDiagnostic() {
      this.diagnosticRunning = true;
      try {
        const response = await deviceApi.diagnoseDevice(this.diagnosticDeviceId);
        this.diagnosticResultDeviceId = this.diagnosticDeviceId;
        this.diagnosticResultSteps = response.data;
      } finally {
        this.diagnosticRunning = false;
      }
    },
    applyCameraStatusHeartbeat(record: Partial<Camera> & { cameraId?: string; id?: string; status?: unknown; source?: string; detail?: string; heartbeatAt?: string; timestamp?: string }) {
      const id = String(record.cameraId || record.id || '').toUpperCase();
      if (!id) return;
      const camera = this.cameras.find((item) => item.id === id);
      if (!camera) return;
      const source = String(record.statusSource || record.source || '').trim();
      if (!isAuthoritativeRuntimeStatusSource(source)) return;

      camera.status = normalizeRuntimeDeviceStatus(record.status);
      camera.statusSource = source || 'stream-heartbeat';
      camera.statusDetail = String(record.statusDetail || record.detail || '');
      camera.lastHeartbeatAt = String(record.lastHeartbeatAt || record.heartbeatAt || record.timestamp || new Date().toISOString());
      if (record.bitrate) camera.bitrate = String(record.bitrate);
      if (record.latency !== undefined) camera.latency = Number(record.latency || 0);
    },
  },
});

function normalizeRuntimeDeviceStatus(value: unknown): Camera['status'] {
  const text = String(value || '').trim().toLowerCase();
  if (['online', 'up', 'ok', 'ready', 'true', '1', '在线'].includes(text)) return '在线';
  if (['maintenance', 'maintaining', '维护中'].includes(text)) return '维护中';
  if (['offline', 'down', 'false', '0', '离线'].includes(text)) return '离线';
  if (['error', 'failed', 'fault', 'degraded', '链路异常'].includes(text)) return '链路异常';
  return '未接入';
}

function isAuthoritativeRuntimeStatusSource(source: string) {
  if (!source) return true;
  return !['frontend-playback', 'ui-playback'].includes(source.toLowerCase());
}

function readStoredToken() {
  if (typeof window === 'undefined') return '';
  return window.localStorage.getItem('river-watch-token') || '';
}

function writeStoredToken(token: string) {
  if (typeof window === 'undefined') return;
  if (token) window.localStorage.setItem('river-watch-token', token);
  else window.localStorage.removeItem('river-watch-token');
}

function isUnauthorizedError(error: unknown) {
  if (error instanceof HttpError) return error.status === 401;
  return error instanceof Error && /(?:^|[：:\s])401(?:\D|$)/.test(error.message);
}

function formatNavBadge(count: number) {
  return count > 0 ? String(count) : '';
}

function downloadBlob(blob: Blob, filename: string) {
  if (typeof window === 'undefined') return;
  const url = window.URL.createObjectURL(blob);
  const anchor = window.document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.URL.revokeObjectURL(url);
}
