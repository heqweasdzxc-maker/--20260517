import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { createMemoryStore } from '../src/store.mjs';
import { createApp } from '../src/server.mjs';

describe('aggregate event store contract', () => {
  it('preserves raw alarms while one open event spans multiple aggregation windows', async () => {
    const store = createMemoryStore(emptyState());
    await store.createAlarm(alarm('A-1', '2026-07-16T01:00:00.000Z', 62));
    await store.createAlarm(alarm('A-2', '2026-07-17T04:00:00.000Z', 81));

    const alarms = await store.listAlarms();
    const events = await store.listEventGroups();
    const snapshot = await store.snapshot();

    assert.equal(alarms.length, 2);
    assert.equal(events.length, 1);
    assert.equal(events[0].firstAlarmId, 'A-1');
    assert.equal(events[0].latestAlarmId, 'A-2');
    assert.equal(events[0].firstOccurredAt, '2026-07-16T01:00:00.000Z');
    assert.equal(events[0].latestOccurredAt, '2026-07-17T04:00:00.000Z');
    assert.equal(events[0].occurrenceCount, 2);
    assert.equal(events[0].maxConfidence, 81);
    assert.deepEqual(snapshot.events, events);
  });

  it('does not inflate the event count when the same alarm id is retried', async () => {
    const store = createMemoryStore(emptyState());
    const repeated = alarm('A-1', '2026-07-17T01:00:00.000Z', 72);

    await store.createAlarm(repeated);
    await store.createAlarm(repeated);

    assert.equal((await store.listAlarms()).length, 1);
    assert.equal((await store.listEventGroups())[0].occurrenceCount, 1);
  });

  it('closes the current lifecycle and creates a new event for a later matching alarm', async () => {
    const store = createMemoryStore(emptyState());
    await store.createAlarm(alarm('A-1', '2026-07-17T01:00:00.000Z', 72));
    await store.createAlarm(alarm('A-2', '2026-07-17T02:00:00.000Z', 76));

    await store.reviewAlarm('A-2', '已处理', makeWorkOrder);
    await store.reviewAlarm('A-2', '已处理', makeWorkOrder);

    const closed = await store.listEventGroups({ history: 'true' });
    assert.equal(closed.length, 1);
    assert.equal(closed[0].status, '已处理');
    assert.equal(closed[0].occurrenceCount, 2);

    await store.createAlarm(alarm('A-3', '2026-07-17T03:00:00.000Z', 79));

    const open = await store.listEventGroups();
    const history = await store.listEventGroups({ history: 'true' });
    assert.equal(open.length, 1);
    assert.equal(open[0].firstAlarmId, 'A-3');
    assert.equal(history.length, 2);
    assert.equal(history.filter((event) => event.status === '已处理').length, 1);
  });

  it('keeps different devices and anomaly types in separate events', async () => {
    const store = createMemoryStore(emptyState());
    await store.createAlarm(alarm('A-1', '2026-07-17T01:00:00.000Z', 70));
    await store.createAlarm({ ...alarm('A-2', '2026-07-17T01:01:00.000Z', 70), cameraId: 'CH05' });
    await store.createAlarm({ ...alarm('A-3', '2026-07-17T01:02:00.000Z', 70), type: '水色异常' });

    assert.equal((await store.listEventGroups()).length, 3);
  });

  it('serves open events newest first and exposes closed history on request', async () => {
    const store = createMemoryStore(emptyState());
    await store.createAlarm(alarm('A-1', '2026-07-17T01:00:00.000Z', 70));
    await store.reviewAlarm('A-1', '忽略', makeWorkOrder);
    await store.createAlarm(alarm('A-2', '2026-07-17T02:00:00.000Z', 75));
    await store.createAlarm({ ...alarm('A-3', '2026-07-17T03:00:00.000Z', 80), cameraId: 'CH05' });

    const server = createApp({ store });
    await new Promise((resolve) => server.listen(0, resolve));
    const baseUrl = `http://127.0.0.1:${server.address().port}`;
    try {
      const open = await fetch(`${baseUrl}/api/events`).then((response) => response.json());
      const history = await fetch(`${baseUrl}/api/events?history=true`).then((response) => response.json());

      assert.equal(open.code, 0);
      assert.deepEqual(open.data.map((event) => event.latestAlarmId), ['A-3', 'A-2']);
      assert.equal(history.data.length, 3);
      assert.equal(history.data.some((event) => event.status === '已忽略'), true);
    } finally {
      await new Promise((resolve) => server.close(resolve));
    }
  });
});

function alarm(id, createdAt, confidence) {
  return {
    id,
    cameraId: 'CH04',
    cameraName: '4号桥东',
    type: '漂浮物',
    severity: confidence >= 80 ? '严重' : '一般',
    confidence,
    status: '待研判',
    time: createdAt.slice(11, 19),
    pts: '00:00:01.000',
    owner: 'AI 推理服务',
    dedupeCount: 1,
    snapshot: '',
    createdAt,
  };
}

function makeWorkOrder(alarm, nextIndex) {
  return {
    id: `WO-${nextIndex}`,
    alarmId: alarm.id,
    title: `${alarm.cameraName} ${alarm.type}`,
    assignee: '现场处置组',
    status: '归档',
    slaHours: 8,
    elapsedHours: 0,
    priority: alarm.severity,
    createdAt: alarm.createdAt,
  };
}

function emptyState() {
  return {
    cameras: [{ id: 'CH04', name: '4号桥东', status: '在线', protocol: 'RTSP', detections: [] }],
    alarms: [],
    events: [],
    eventGroupAlarmLinks: [],
    workOrders: [],
    aiEvents: [],
    notifications: [],
    evidenceBundles: [],
    playbackClips: [],
    exportTasks: [],
    operationTasks: [],
    algorithms: [],
    templates: [],
    uavTasks: [],
    uavAssets: [],
    importJobs: [],
    storageTiers: [],
    reportMetrics: [],
    reportTasks: [],
    users: [],
    rolePermissions: [],
    logs: [],
    notifyRules: [],
    runtimeConfig: [],
    cameraStatuses: [],
    aiWorkerStatuses: [],
  };
}
