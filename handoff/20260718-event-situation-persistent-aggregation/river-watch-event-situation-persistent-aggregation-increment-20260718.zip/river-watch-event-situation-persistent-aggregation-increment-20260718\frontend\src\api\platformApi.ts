﻿import {
  alarms,
  algorithms,
  cameras,
  evidenceBundles,
  failedDiagnostic,
  healthyDiagnostic,
  importJobs,
  logs,
  navItems,
  reportMetrics,
  storageTiers,
  templates,
  uavAssets,
  uavTasks,
  users,
  workOrders,
} from '../data/platform';
import type { ApiResponse, PlatformSnapshot } from '../types';
import { ensureOk } from './http';

const snapshot: PlatformSnapshot = {
  cameras,
  alarms,
  events: [],
  workOrders,
  templates,
  algorithms,
  uavTasks,
  uavAssets,
  evidenceBundles,
  importJobs,
  storageTiers,
  reportMetrics,
  users,
  logs,
  navItems,
  diagnostics: {
    healthy: healthyDiagnostic,
    failed: failedDiagnostic,
  },
  aiWorkers: [],
  operationRoutes: [],
  operationProfiles: {},
  operationSpecialSpecs: {},
  runtimeConfig: [],
};

export interface PlatformApi {
  getSnapshot(): Promise<ApiResponse<PlatformSnapshot>>;
}

export const mockPlatformApi: PlatformApi = {
  async getSnapshot() {
    return {
      code: 0,
      msg: 'ok',
      data: cloneSnapshot(snapshot),
    };
  },
};

export function createPlatformHttpApi(baseUrl = '/api'): PlatformApi {
  return {
    async getSnapshot() {
      const response = await fetch(`${baseUrl}/platform/snapshot`, {
        headers: { Accept: 'application/json', ...authHeaders() },
      });

      ensureOk(response, '平台快照接口异常');

      return (await response.json()) as ApiResponse<PlatformSnapshot>;
    },
  };
}

export function createPlatformApiFromEnv(): PlatformApi {
  const useMock = import.meta.env.VITE_USE_MOCK_API === 'true';
  const baseUrl = import.meta.env.VITE_API_BASE_URL || '/api';

  return useMock ? mockPlatformApi : createPlatformHttpApi(baseUrl);
}

function authHeaders(): Record<string, string> {
  if (typeof window === 'undefined') return {};
  const token = window.localStorage.getItem('river-watch-token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function cloneSnapshot(source: PlatformSnapshot): PlatformSnapshot {
  return JSON.parse(JSON.stringify(source)) as PlatformSnapshot;
}
