# Event Situation Persistent Aggregation Design

## Objective

Replace the Event Situation page's browser-side time-window grouping with a backend-owned, persistent event lifecycle. Every raw alarm remains in the Alarm Center, while Event Situation shows one open aggregate event per device and normalized anomaly type until an operator chooses `忽略` or `已处理`.

## Confirmed Product Rules

1. `rw_alarm` remains the source of every individual alarm and is not collapsed or deleted by event aggregation.
2. The deduplication key is `camera_id + normalized anomaly type`.
3. A new alarm matching an open event updates that event's latest alarm, latest occurrence, count, severity, confidence summary, and evidence reference.
4. An event remains open across severity aggregation windows. The windows (`提示 6h`, `一般 3h`, `严重 1h`, `紧急 30m`) describe notification cadence and do not close an event.
5. Only the review actions `忽略` and `已处理` close an event.
6. A later matching alarm after closure creates a new event. Closed events are never reopened.
7. Review actions are idempotent: repeating the same action does not create duplicate work orders or alter occurrence counts.
8. Existing Alarm Center, evidence, work-order, navigation, and monitoring behavior must remain available.

## Data Model

Create `rw_event_group` with one row per aggregate lifecycle:

- `id`: stable event identifier.
- `dedupe_key`: normalized `camera_id:type` key.
- `camera_id`, `type`, `severity`, `status`.
- `first_alarm_id`, `latest_alarm_id`.
- `first_occurred_at`, `latest_occurred_at`.
- `occurrence_count`.
- `first_confidence`, `latest_confidence`, `max_confidence`.
- `review_action`, `closed_at`, `work_order_id`.
- `payload`, `created_at`, `updated_at`.
- `open_dedupe_key`: nullable generated or maintained key with a unique index, ensuring at most one open event for a dedupe key.

Create `rw_event_group_alarm` as an append-only relationship between each aggregate event and every raw alarm. This preserves traceability without adding a required foreign key to existing alarm records.

Both tables use `ON DELETE CASCADE` only from an event group to its relation rows. Raw alarms are not deleted when an event is closed.

## Aggregation Transaction

All alarm creation paths, including API creation and AI metadata ingestion, call one store operation after the raw alarm is persisted:

1. Normalize device and anomaly type into a dedupe key.
2. Lock the open event for that key.
3. If one exists, update latest fields and occurrence count and append the relation row.
4. Otherwise create a new open event and append the relation row.
5. Commit atomically with the raw alarm persistence where the store supports transactions.

The operation must tolerate repeated delivery of the same alarm ID. The relation primary key prevents count inflation during retries.

## Review And Closure

The existing alarm review endpoint remains compatible. When `忽略` or `已处理` is applied to an alarm belonging to an open aggregate event:

- close the aggregate event;
- store the action and close timestamp;
- preserve first/latest occurrence values and all alarm relationships;
- reuse the existing work-order closure path and keep it idempotent;
- return the closed aggregate event with the reviewed alarm response when practical.

Reviewing any alarm in the open event closes that whole lifecycle. The UI opens the latest alarm for evidence by default and retains first-alarm references for timeline inspection.

## API Contract

Add `GET /api/events` and alias `GET /api/v1/events`.

Default response contains open events sorted by `latestOccurredAt DESC`, with optional `status`, `cameraId`, `type`, and history filters. Each event includes:

```ts
interface AggregateEvent {
  id: string;
  dedupeKey: string;
  cameraId: string;
  cameraName: string;
  type: string;
  severity: Severity;
  status: '待研判' | '已忽略' | '已处理';
  firstAlarmId: string;
  latestAlarmId: string;
  firstOccurredAt: string;
  latestOccurredAt: string;
  occurrenceCount: number;
  firstConfidence: number;
  latestConfidence: number;
  maxConfidence: number;
  reviewAction?: '忽略' | '已处理';
  closedAt?: string;
  workOrderId?: string;
}
```

Include `events` in the platform snapshot so the current single-refresh store architecture remains intact. Older backends without `events` continue to render using a compatibility projection, but the deployment verification must prove the new backend supplies it.

## Existing Data Backfill

The migration backfills only active alarm statuses (`待研判`, `已确认`, `已派单`) into open events. Archived and false-alarm history stays queryable in Alarm Center and is not reopened. Backfill is deterministic, idempotent, and uses complete timestamps from `created_at`, `createdAt`, `updatedAt`, or alarm ID epoch in that order.

## Event Situation UI

The queue consumes `platform.events`, not `platform.dedupedAlarms`, and sorts by `latestOccurredAt` descending.

Columns:

| Column | Width | Behavior |
| --- | ---: | --- |
| Event | 220px | Type plus compact event ID; single line with tooltip |
| Device | 150px | Single line with tooltip |
| Level | 82px | Status badge |
| First occurrence | 168px | `YYYY-MM-DD HH:mm:ss`, tabular numerals |
| Latest alarm | 168px | `YYYY-MM-DD HH:mm:ss`, tabular numerals |
| Count | 76px | Right-aligned integer |
| Duration | 96px | Human-readable elapsed span |
| Status | 96px | Status badge |
| Work order | 170px | Single line with tooltip |
| Action | 76px | Fixed command button |

The table has a minimum width of 1500px and horizontal scrolling below that width. Header and rows have stable heights. Cells use `white-space: nowrap`, `overflow: hidden`, and `text-overflow: ellipsis`; no wrapped or stacked columns are permitted. Event and Action columns remain sticky at the left and right edges. Truncated values expose the full value via native title or tooltip.

KPI cards report open queue count, pending review count, dedupe hits (`sum(occurrenceCount - 1)`), and active work-order count.

## Review Dialog

Opening an event selects its `latestAlarmId`, ensuring the latest captured evidence and annotation are shown. The detail area additionally displays first occurrence, latest occurrence, occurrence count, and maximum confidence. Existing three-column review detail layout remains unchanged and must continue to pass its regression tests.

## Failure Handling And Rollback

- Migration uses `CREATE TABLE IF NOT EXISTS` and idempotent backfill.
- Deployment verifies exact source hashes before replacement.
- Only changed backend/frontend files and built assets are backed up.
- Backend starts and initializes schema before frontend assets are switched.
- Failed health, API, database, or page smoke checks trigger automatic file and service rollback.
- Rollback does not drop aggregation tables; additive tables are harmless to the previous runtime and preserve captured data.

## Acceptance Criteria

1. Two matching alarms update one open event with correct first/latest timestamps and count.
2. Matching alarms on different devices or with different types create separate events.
3. `忽略` and `已处理` close the event; a later matching alarm creates a new event.
4. Retry of the same raw alarm does not increment the event twice.
5. Event list defaults to latest occurrence descending and shows both full date/time values.
6. Every table cell stays on one line at the supported desktop viewport; narrower layouts scroll horizontally.
7. Review opens the latest alarm evidence and closing is idempotent.
8. Alarm Center, navigation menus, work orders, evidence, and platform snapshot regression tests pass.
9. Increment package contains source, prebuilt frontend assets, migration/apply/verify/rollback scripts, checksums, and deployment notes.
