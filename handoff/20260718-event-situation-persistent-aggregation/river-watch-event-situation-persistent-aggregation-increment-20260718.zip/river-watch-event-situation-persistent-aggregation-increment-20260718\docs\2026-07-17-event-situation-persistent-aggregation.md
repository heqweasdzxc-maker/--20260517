# Event Situation Persistent Aggregation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Persist Event Situation aggregation in the backend so each open device/type event shows its first and latest full timestamps, remains active until reviewed, and starts a new lifecycle after closure.

**Architecture:** Add additive MySQL event-group and relation tables, expose aggregate events through the existing store/server/snapshot contracts, and replace the frontend's transient `dedupedAlarms` projection with those records. Preserve all raw alarms, existing review/work-order behavior, evidence endpoints, navigation, and deployment topology.

**Tech Stack:** Node.js 22 ESM, `mysql2`, Node test runner, Vue 3, Pinia, TypeScript, Vitest, Vite, Docker Compose runtime, MySQL 8, Bash deployment scripts.

## Global Constraints

- Deduplication key is device plus normalized anomaly type.
- Severity windows do not close events.
- Only `忽略` and `已处理` close an event.
- A matching alarm after closure creates a new event.
- Raw alarm records remain unchanged and queryable.
- Event list defaults to latest occurrence descending and renders `YYYY-MM-DD HH:mm:ss` for first and latest times.
- Table cells remain single line; the table scrolls horizontally below 1500px.
- Deployment is incremental, hash-gated, health-checked, and automatically reversible.
- No new runtime dependency or internet download is allowed.

---

### Task 1: Backend Aggregate Event Domain

**Files:**
- Create: `codex-handoff/backend/src/event-groups.mjs`
- Create: `codex-handoff/backend/test/event-groups.test.mjs`

**Interfaces:**
- Produces: `normalizeEventDedupeKey(alarm)`, `eventOccurredAt(alarm, fallback)`, `createAggregateEvent(alarm, options)`, `mergeAggregateEvent(event, alarm, options)`, and `closeAggregateEvent(event, action, options)`.
- Consumes: Alarm-shaped plain objects and ISO timestamp options; no database dependency.

- [ ] **Step 1: Write failing domain tests**

Cover normalization, first/latest preservation, severity escalation, max confidence, duplicate alarm ID idempotency marker, closure, and closed-event rejection.

- [ ] **Step 2: Run the focused tests and confirm RED**

Run: `node --test test/event-groups.test.mjs`

Expected: failure because `src/event-groups.mjs` does not exist.

- [ ] **Step 3: Implement the minimal pure domain module**

Use deterministic IDs supplied by the caller, normalize whitespace/case, prefer `createdAt` over time-only fields, and never mutate input objects.

- [ ] **Step 4: Run the focused tests and confirm GREEN**

Run: `node --test test/event-groups.test.mjs`

Expected: all event-group domain tests pass.

### Task 2: Store Schema, Persistence, Backfill, And Review Closure

**Files:**
- Modify: `codex-handoff/backend/src/store.mjs`
- Modify: `codex-handoff/backend/test/api.test.mjs`
- Create: `codex-handoff/backend/test/event-group-store-contract.test.mjs`

**Interfaces:**
- Produces store methods `listEventGroups(filters = {})`, `getEventGroup(id)`, `aggregateAlarm(alarm, options = {})`, and `closeEventGroupForAlarm(alarmId, action, options = {})`.
- Snapshot produces `events: AggregateEvent[]`.
- Existing `createAlarm`, `ingestMetadata`, and `reviewAlarm` invoke aggregation/closure without changing their public return compatibility.

- [ ] **Step 1: Add failing store/API contract tests**

Assert the schema contains `rw_event_group` and `rw_event_group_alarm`, snapshot includes `events`, same-key alarms merge once, redelivery is idempotent, different keys split, closure is idempotent, and later alarms create a new event.

- [ ] **Step 2: Run backend tests and confirm RED**

Run: `npm test -- --test-name-pattern="event group|aggregate event"`

Expected: failures for missing event store methods and snapshot field.

- [ ] **Step 3: Add additive schema and pure in-memory implementation**

Create both tables during normal initialization and mirror the same lifecycle in the memory store so API tests run without MySQL.

- [ ] **Step 4: Add MySQL transactional implementation**

Persist the raw alarm first, insert the event/alarm relation with `INSERT IGNORE`, and increment only when the relation insert affected one row. Lock the open event by dedupe key, preserve first occurrence, and update latest occurrence monotonically.

- [ ] **Step 5: Add idempotent active-alarm backfill**

Backfill `待研判`, `已确认`, and `已派单` alarms only when no relation exists. Use stored `created_at` as the final timestamp fallback and do not reopen archived alarms.

- [ ] **Step 6: Close aggregate events from the existing review path**

When action is `忽略` or `已处理`, close the event for that alarm in the same review operation and reuse the existing closed work-order creation logic.

- [ ] **Step 7: Run complete backend tests**

Run: `npm test`

Expected: all backend tests pass with no unhandled rejection or schema-contract regression.

### Task 3: Event API And Frontend Data Contract

**Files:**
- Modify: `codex-handoff/backend/src/server.mjs`
- Modify: `codex-handoff/frontend/src/types.ts`
- Modify: `codex-handoff/frontend/src/api/platformApi.ts`
- Modify: `codex-handoff/frontend/src/stores/platform.ts`
- Modify: `codex-handoff/frontend/src/__tests__/platformApi.test.ts`
- Create: `codex-handoff/frontend/src/__tests__/eventAggregationStore.test.ts`

**Interfaces:**
- Backend adds `GET /api/events` and `GET /api/v1/events`.
- Frontend adds `AggregateEvent` and `PlatformSnapshot.events`.
- Store state adds `events`, refreshed from the platform snapshot.

- [ ] **Step 1: Write failing API and store tests**

Verify event routes filter open/history records, preserve descending latest timestamps, and that snapshot hydration stores events without altering alarm/nav state.

- [ ] **Step 2: Run focused tests and confirm RED**

Run backend: `node --test test/api.test.mjs --test-name-pattern="event route"`

Run frontend: `npx vitest run src/__tests__/platformApi.test.ts src/__tests__/eventAggregationStore.test.ts`

Expected: missing route/type/state failures.

- [ ] **Step 3: Implement event routes and typed snapshot hydration**

Keep `/api/platform/snapshot` as the primary UI refresh. Route aliases return the same normalized records; the v1 alias wraps pagination consistently with existing v1 resources.

- [ ] **Step 4: Run focused tests and confirm GREEN**

Run the same backend and frontend commands.

Expected: all focused tests pass.

### Task 4: Event Queue Table And Review Selection

**Files:**
- Modify: `codex-handoff/frontend/src/views/pages/EventsPage.vue`
- Modify: `codex-handoff/frontend/src/composables/useWorkspace.ts`
- Modify: `codex-handoff/frontend/src/styles.css`
- Create: `codex-handoff/frontend/src/services/eventGroups.ts`
- Create: `codex-handoff/frontend/src/__tests__/eventSituationQueue.test.ts`
- Modify: `codex-handoff/frontend/src/__tests__/alarmReviewDialog.test.ts`
- Modify: `codex-handoff/frontend/src/__tests__/navRoutes.test.ts`

**Interfaces:**
- Produces `formatEventDateTime`, `formatEventDuration`, and `eventQueueRows(events, workOrders)`.
- Event review action opens `latestAlarmId`.

- [ ] **Step 1: Write failing UI behavior tests**

Assert first/latest full date strings, latest-descending order, dedupe KPI calculation, duration, latest-alarm review selection, fixed ten-column headings, single-line CSS, sticky first/action columns, table minimum width, and all existing navigation routes.

- [ ] **Step 2: Run focused UI tests and confirm RED**

Run: `npx vitest run src/__tests__/eventSituationQueue.test.ts src/__tests__/alarmReviewDialog.test.ts src/__tests__/navRoutes.test.ts`

Expected: failures because the page still consumes `dedupedAlarms` and lacks the new columns.

- [ ] **Step 3: Implement typed event row helpers**

Use locale-independent `YYYY-MM-DD HH:mm:ss`, tabular numerals, stable duration formatting, and latest timestamp numeric sorting.

- [ ] **Step 4: Replace transient event projection and update review action**

Render `platform.events`; open `latestAlarmId`; calculate KPIs from event counts; do not modify Alarm Center rows or navigation definitions.

- [ ] **Step 5: Apply constrained operational table styles**

Set explicit column widths, `min-width: 1500px`, horizontal overflow, single-line ellipsis with titles, stable row heights, sticky Event and Action columns, and no nested cards.

- [ ] **Step 6: Run focused UI tests and confirm GREEN**

Run the same Vitest command.

Expected: all focused tests pass.

- [ ] **Step 7: Run complete frontend unit tests and build**

Run: `npm test`

Run: `npm run build`

Expected: all tests pass and Vite emits production assets without type errors.

### Task 5: Incremental Deployment Package

**Files:**
- Create: `codex-handoff/packages/river-watch-event-situation-persistent-aggregation-increment-20260717/README.md`
- Create: `codex-handoff/packages/river-watch-event-situation-persistent-aggregation-increment-20260717/SHA256SUMS`
- Create: `codex-handoff/packages/river-watch-event-situation-persistent-aggregation-increment-20260717/scripts/apply-event-situation-persistent-aggregation-20260717.sh`
- Create: `codex-handoff/packages/river-watch-event-situation-persistent-aggregation-increment-20260717/scripts/verify-event-situation-persistent-aggregation-20260717.sh`
- Create: `codex-handoff/packages/river-watch-event-situation-persistent-aggregation-increment-20260717/scripts/rollback-event-situation-persistent-aggregation-20260717.sh`
- Create: `codex-handoff/packages/river-watch-event-situation-persistent-aggregation-increment-20260717/db/backfill-event-groups.sql`
- Copy changed source and `frontend/dist` output into the package.

**Interfaces:**
- Apply script accepts `APP_DIR`, `BACKEND_CONTAINER`, `FRONTEND_CONTAINER`, and `MYSQL_CONTAINER`.
- Verify script exits nonzero on hash mismatch, unhealthy containers, missing tables, missing route, missing frontend marker, or navigation smoke failure.

- [ ] **Step 1: Write package verification tests**

Create a package test that checks required files, executable syntax, checksum coverage, baseline hash constants, rollback trap, readiness loops, database checks, route checks, and compact source-only payload.

- [ ] **Step 2: Run package test and confirm RED**

Run: `python tests/test_package.py`

Expected: failure until scripts and payload are present.

- [ ] **Step 3: Implement apply, verify, and rollback scripts**

Back up only changed files and running container assets, verify production baseline hashes, install source, restart backend, wait for health, run idempotent backfill, replace prebuilt frontend assets, wait for frontend health, and run verification. Trap any failure and restore files/assets and prior service state.

- [ ] **Step 4: Build ZIP and external checksum**

Create `river-watch-event-situation-persistent-aggregation-increment-20260717.zip` and `.zip.sha256` at the workspace root. Normalize archive paths to forward slashes.

- [ ] **Step 5: Verify package locally**

Run package tests, `sha256sum -c SHA256SUMS`, archive listing checks, shell syntax checks, backend tests, frontend tests, and frontend build again from a clean extraction.

Expected: every command exits zero.

### Task 6: GitHub Handoff

**Files:**
- Create: `codex-handoff/docs/handoff/2026-07-17-event-situation-persistent-aggregation.md`
- Publish package ZIP, checksum, spec, plan, and handoff receipt to `heqweasdzxc-maker/--20260517`.

**Interfaces:**
- Handoff records local test evidence, expected production hashes, deployment commands, verification commands, rollback command, and server deployment status as pending until the user returns the receipt.

- [ ] **Step 1: Write the handoff receipt**

Include exact artifact SHA-256, changed-file inventory, schema additions, data backfill behavior, deployment command, verification command, and rollback directory rules.

- [ ] **Step 2: Re-run final verification**

Run the complete backend test suite, complete frontend unit suite, frontend production build, package test, checksum checks, and clean-extraction checks.

Expected: zero failures.

- [ ] **Step 3: Publish one intentional GitHub commit**

Commit only the spec, plan, handoff, package, and checksum. Do not publish database exports, evidence images, secrets, node_modules, or temporary build directories.

- [ ] **Step 4: Confirm GitHub commit and artifact hashes**

Read the new commit tree and compare GitHub blob paths plus the published external checksum with the local package hash.

Expected: repository main points to the new commit and all handoff artifacts are present.

## Self-Review

- Spec coverage: all nine acceptance criteria map to Tasks 1 through 5; GitHub update is Task 6.
- Placeholder scan: no `TBD`, deferred implementation, or unspecified error-handling step remains.
- Type consistency: backend and frontend use `AggregateEvent`, `latestAlarmId`, `firstOccurredAt`, `latestOccurredAt`, and `occurrenceCount` consistently.
- Risk control: schema is additive, raw alarms are preserved, review compatibility is retained, frontend assets are prebuilt, and rollback leaves additive tables intact.
