const severityRank = Object.freeze({ 提示: 1, 一般: 2, 严重: 3, 紧急: 4 });
const closingActions = new Set(['忽略', '已处理']);

export function normalizeEventDedupeKey(alarm = {}) {
  const cameraId = String(alarm.cameraId || alarm.camera_id || '').trim().toUpperCase();
  const type = String(alarm.type || '').replace(/\s+/g, '').trim();
  if (!cameraId || !type) throw new Error('事件归集缺少设备或异常类型');
  return `${cameraId}:${type}`;
}

export function eventOccurredAt(alarm = {}, fallback = '') {
  const candidates = [alarm.createdAt, alarm.occurredAt, alarm.updatedAt, fallback];
  for (const value of candidates) {
    const text = String(value || '').trim();
    if (text && Number.isFinite(Date.parse(text))) return new Date(text).toISOString();
  }
  throw new Error('事件归集缺少完整发生时间');
}

export function createAggregateEvent(alarm, options = {}) {
  const occurredAt = eventOccurredAt(alarm, options.occurredAt);
  const confidence = numericConfidence(alarm.confidence);
  const id = String(options.id || '').trim();
  if (!id) throw new Error('事件归集缺少事件编号');

  return {
    id,
    dedupeKey: normalizeEventDedupeKey(alarm),
    cameraId: String(alarm.cameraId || alarm.camera_id || '').trim().toUpperCase(),
    cameraName: String(alarm.cameraName || '').trim(),
    type: String(alarm.type || '').replace(/\s+/g, '').trim(),
    severity: normalizeSeverity(alarm.severity),
    status: '待研判',
    firstAlarmId: String(alarm.id || '').trim(),
    latestAlarmId: String(alarm.id || '').trim(),
    firstOccurredAt: occurredAt,
    latestOccurredAt: occurredAt,
    occurrenceCount: 1,
    firstConfidence: confidence,
    latestConfidence: confidence,
    maxConfidence: confidence,
    reviewAction: '',
    closedAt: '',
    workOrderId: '',
    createdAt: occurredAt,
    updatedAt: occurredAt,
  };
}

export function mergeAggregateEvent(event, alarm, options = {}) {
  if (event.status !== '待研判') throw new Error(`事件 ${event.id} 已关闭`);
  if (options.relationInserted === false) return { ...event };

  const occurredAt = eventOccurredAt(alarm, options.occurredAt);
  const confidence = numericConfidence(alarm.confidence);
  const incomingSeverity = normalizeSeverity(alarm.severity);
  const latestIsIncoming = Date.parse(occurredAt) >= Date.parse(event.latestOccurredAt);
  const occurrenceIncrement = Math.max(1, Number(options.occurrenceIncrement || 1));

  return {
    ...event,
    cameraName: String(alarm.cameraName || event.cameraName || '').trim(),
    severity: severityRank[incomingSeverity] > severityRank[event.severity] ? incomingSeverity : event.severity,
    latestAlarmId: latestIsIncoming ? String(alarm.id || '').trim() : event.latestAlarmId,
    latestOccurredAt: latestIsIncoming ? occurredAt : event.latestOccurredAt,
    latestConfidence: latestIsIncoming ? confidence : event.latestConfidence,
    maxConfidence: Math.max(numericConfidence(event.maxConfidence), confidence),
    occurrenceCount: Math.max(1, Number(event.occurrenceCount || 1)) + occurrenceIncrement,
    updatedAt: latestIsIncoming ? occurredAt : event.updatedAt,
  };
}

export function closeAggregateEvent(event, action, options = {}) {
  if (!closingActions.has(action)) throw new Error('事件只允许忽略或已处理后关闭');
  if (event.status !== '待研判') {
    if (event.reviewAction === action) return { ...event };
    throw new Error(`事件 ${event.id} 已关闭`);
  }

  const closedAt = eventOccurredAt({}, options.closedAt || new Date().toISOString());
  return {
    ...event,
    status: action === '忽略' ? '已忽略' : '已处理',
    reviewAction: action,
    closedAt,
    workOrderId: String(options.workOrderId || event.workOrderId || '').trim(),
    updatedAt: closedAt,
  };
}

function normalizeSeverity(value) {
  return severityRank[value] ? value : '提示';
}

function numericConfidence(value) {
  const number = Number(value || 0);
  return Number.isFinite(number) ? Math.max(0, number) : 0;
}
