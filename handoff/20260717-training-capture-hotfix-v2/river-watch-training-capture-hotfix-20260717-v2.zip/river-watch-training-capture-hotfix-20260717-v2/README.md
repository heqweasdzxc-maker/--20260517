# River Watch 高清训练图片采集增量工具

该工具独立于 River Watch 业务程序运行。它从 CH01 至 CH10 的摄像机主码流中每小时顺序抓取一张 JPEG，连续运行 72 小时。它不会修改或重启现有前端、后端、数据库、流媒体或 AI 推理服务。

## 关键行为

- 安装后立即抓取第一批，之后每小时一批，共最多 72 批。
- 优先使用 `TRAINING_CAPTURE_URL` 或 `HIGHRES_RTSP_URL`；海康 `Channels/102` 自动切到主码流 `Channels/101`。
- 保持源分辨率，JPEG 质量参数为 `2`，低于 `1280x720` 的图片保留并标记 `LOW_RESOLUTION`。
- 10 路顺序抓取，使用低 CPU/I/O 优先级，不占用 GPU。
- CH10 等单路断流只记录失败，不影响其他通道。
- 达到 72 小时、5 GiB 目录上限或磁盘剩余不足 5 GiB时自动停止。
- 停止、卸载和回滚均保留图片。

## 部署

```bash
cd /home/ai-river/river-watch-training-capture-increment-20260717
sha256sum -c SHA256SUMS
chmod +x scripts/*.sh
sudo -v
sudo env APP_DIR=/home/ai-river/river-watch \
  bash scripts/apply-training-capture-increment-20260717.sh
```

安装命令异步启动第一批抓图，不会长时间占用 SSH 终端。

## 第一批质量检查

等待约 3 至 5 分钟后执行：

```bash
sudo bash scripts/verify-training-capture-20260717.sh
sudo find /home/ai-river/training-captures -type f -name '*.jpg' -printf '%p %k KB\n' | head -20
```

验收时必须确认大部分在线通道为 `SUCCESS`，分辨率至少 `1280x720`。如出现 `LOW_RESOLUTION`，应为对应通道显式配置 `TRAINING_CAPTURE_URL`，不要等待三天后再发现素材不合格。

## 进度查询

```bash
sudo bash scripts/verify-training-capture-20260717.sh
sudo journalctl -u river-training-capture.service --since '24 hours ago' --no-pager
```

## 提前停止

```bash
sudo bash scripts/stop-training-capture-20260717.sh
```

## 打包导出

```bash
sudo bash scripts/package-training-captures-20260717.sh
```

默认生成 `/home/ai-river/<run-id>.tar.gz` 和对应 `.sha256`。

## 卸载工具

```bash
sudo bash scripts/uninstall-training-capture-20260717.sh
```

## 回滚

```bash
sudo bash scripts/rollback-training-capture-increment-20260717.sh
```

## 输出目录

```text
/home/ai-river/training-captures/<run-id>/
  manifest.tsv
  run.conf
  CH01/*.jpg
  ...
  CH10/*.jpg
```

`manifest.tsv` 不保存 RTSP 地址、用户名、密码或令牌。
