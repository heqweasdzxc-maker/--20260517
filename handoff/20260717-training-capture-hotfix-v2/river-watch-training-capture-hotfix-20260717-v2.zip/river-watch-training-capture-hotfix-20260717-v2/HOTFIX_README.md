# River Watch training capture hotfix v2

This package repairs the first deployment after all CH01-CH09 captures returned
`ffmpeg_exit_8` and CH10 timed out. It changes only the standalone training
capture tool.

## Behavior

- Removes duplicate `nice` and `ionice` wrappers. The systemd unit retains low
  CPU and I/O priority.
- Writes a short credential-redacted FFmpeg error into `manifest.tsv`.
- Tries the Hikvision main stream first, then the configured original stream
  and inference stream.
- Retries the current slot only when that slot has zero usable images.
- Leaves River Watch, group inference, databases, models and camera
  configuration unchanged.

## Apply and verify

```bash
sudo env APP_DIR=/home/ai-river/river-watch \
  bash scripts/apply-training-capture-hotfix-20260717-v2.sh

sudo bash scripts/verify-training-capture-hotfix-20260717-v2.sh
```

## Cleanup

The cleanup script protects `/home/ai-river/river-watch`, `training-captures`
and `db-backups`. Review the dry run before applying the exact allowlist:

```bash
sudo bash scripts/cleanup-server-home-20260717.sh
sudo env APPLY=1 bash scripts/cleanup-server-home-20260717.sh
```

ZIP packages, checksums, model imports, database backups and the active group
session-pool package are retained.

## Rollback

```bash
sudo env APP_DIR=/home/ai-river/river-watch \
  bash scripts/rollback-training-capture-hotfix-20260717-v2.sh
```

