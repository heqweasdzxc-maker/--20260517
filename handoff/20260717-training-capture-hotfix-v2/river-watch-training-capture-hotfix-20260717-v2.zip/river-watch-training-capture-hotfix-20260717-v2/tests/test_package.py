import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCRIPT_NAMES = (
    "apply-training-capture-hotfix-20260717-v2.sh",
    "verify-training-capture-hotfix-20260717-v2.sh",
    "rollback-training-capture-hotfix-20260717-v2.sh",
    "cleanup-server-home-20260717.sh",
    "apply-training-capture-increment-20260717.sh",
    "verify-training-capture-20260717.sh",
    "stop-training-capture-20260717.sh",
    "package-training-captures-20260717.sh",
    "uninstall-training-capture-20260717.sh",
    "rollback-training-capture-increment-20260717.sh",
)


class PackageTests(unittest.TestCase):
    def test_required_package_files_exist(self):
        required = [
            ROOT / "training_capture" / "training_capture.py",
            ROOT / "systemd" / "river-training-capture.service",
            ROOT / "systemd" / "river-training-capture.timer",
            ROOT / "README.md",
            ROOT / "HOTFIX_README.md",
            *[ROOT / "scripts" / name for name in SCRIPT_NAMES],
        ]
        self.assertEqual([str(path.relative_to(ROOT)) for path in required if not path.is_file()], [])

    def test_scripts_use_bash_strict_mode(self):
        for name in SCRIPT_NAMES:
            text = (ROOT / "scripts" / name).read_text(encoding="utf-8")
            self.assertTrue(text.startswith("#!/usr/bin/env bash\n"), name)
            self.assertIn("set -Eeuo pipefail", text, name)

    def test_systemd_service_is_isolated_oneshot(self):
        text = (ROOT / "systemd" / "river-training-capture.service").read_text(encoding="utf-8")
        self.assertIn("Type=oneshot", text)
        self.assertIn("training_capture.py --config", text)
        self.assertNotRegex(text, r"river-ai-(?:group|batch)")

    def test_timer_is_hourly_and_persistent(self):
        text = (ROOT / "systemd" / "river-training-capture.timer").read_text(encoding="utf-8")
        self.assertIn("OnUnitActiveSec=1h", text)
        self.assertIn("Persistent=true", text)
        self.assertIn("river-training-capture.service", text)

    def test_scripts_do_not_control_application_or_ai_services(self):
        forbidden = re.compile(r"(?:river-ai-(?:group|batch)|deploy-(?:backend|frontend|mysql|zlmediakit))")
        for name in SCRIPT_NAMES:
            text = (ROOT / "scripts" / name).read_text(encoding="utf-8")
            self.assertIsNone(forbidden.search(text), name)

    def test_cleanup_scripts_never_delete_capture_root(self):
        for name in (
            "stop-training-capture-20260717.sh",
            "uninstall-training-capture-20260717.sh",
            "rollback-training-capture-increment-20260717.sh",
        ):
            text = (ROOT / "scripts" / name).read_text(encoding="utf-8")
            self.assertNotRegex(text, r"rm\s+-rf[^\n]*(?:training-captures|RUN_DIR|OUTPUT_ROOT)", name)

    def test_server_cleanup_has_protected_runtime_roots_and_dry_run_default(self):
        text = (ROOT / "scripts" / "cleanup-server-home-20260717.sh").read_text(encoding="utf-8")
        self.assertIn('APPLY="${APPLY:-0}"', text)
        self.assertIn('$HOME_DIR/river-watch', text)
        self.assertIn('$HOME_DIR/training-captures', text)
        self.assertIn('$HOME_DIR/db-backups', text)

    def test_production_files_have_no_embedded_rtsp_credentials(self):
        candidates = [
            ROOT / "training_capture" / "training_capture.py",
            *(ROOT / "scripts").glob("*.sh"),
            *(ROOT / "systemd").glob("*"),
        ]
        credential_url = re.compile(r"rtsp://[^\s/'\"]+@", re.IGNORECASE)
        for path in candidates:
            self.assertIsNone(credential_url.search(path.read_text(encoding="utf-8")), str(path))


if __name__ == "__main__":
    unittest.main()
