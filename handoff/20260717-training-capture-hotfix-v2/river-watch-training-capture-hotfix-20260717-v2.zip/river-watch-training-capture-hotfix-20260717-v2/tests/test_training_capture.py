import sys
import subprocess
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE_ROOT / "training_capture"))

from training_capture import (
    capture_camera,
    CaptureResult,
    load_run_config,
    parse_env_file,
    run_capture,
    safe_error,
    select_stream_url,
    stream_candidates,
    slot_for,
)


class ConfigurationTests(unittest.TestCase):
    def test_parse_env_file_handles_quotes_comments_and_invalid_lines(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "camera.env"
            path.write_text(
                "# camera settings\n"
                "CAMERA_ID=CH01\n"
                "TRAINING_CAPTURE_URL='rtsp://camera/high'\n"
                'RTSP_URL="rtsp://camera/Streaming/Channels/102"\n'
                "INVALID\n",
                encoding="utf-8",
            )

            values = parse_env_file(path)

        self.assertEqual(values["CAMERA_ID"], "CH01")
        self.assertEqual(values["TRAINING_CAPTURE_URL"], "rtsp://camera/high")
        self.assertEqual(values["RTSP_URL"], "rtsp://camera/Streaming/Channels/102")
        self.assertNotIn("INVALID", values)

    def test_selects_explicit_training_url_before_other_streams(self):
        values = {
            "TRAINING_CAPTURE_URL": "rtsp://camera/training",
            "HIGHRES_RTSP_URL": "rtsp://camera/high",
            "RTSP_URL": "rtsp://camera/Streaming/Channels/102",
        }
        self.assertEqual(select_stream_url(values), "rtsp://camera/training")

    def test_rewrites_hikvision_substream_to_main_stream(self):
        value = "rtsp://user:secret@host/Streaming/Channels/102"
        expected = "rtsp://user:secret@host/Streaming/Channels/101"
        self.assertEqual(select_stream_url({"RTSP_URL": value}), expected)

    def test_does_not_guess_non_hikvision_stream_rewrite(self):
        value = "rtsp://user:secret@host/live/substream"
        self.assertEqual(select_stream_url({"RTSP_URL": value}), value)

    def test_falls_back_to_inference_stream(self):
        self.assertEqual(
            select_stream_url({"INFERENCE_STREAM_URL": "rtsp://camera/inference"}),
            "rtsp://camera/inference",
        )

    def test_stream_candidates_keep_main_stream_first_and_original_as_fallback(self):
        values = {
            "RTSP_URL": "rtsp://user:secret@camera/Streaming/Channels/102",
            "INFERENCE_STREAM_URL": "rtsp://relay/live/CH01",
        }
        self.assertEqual(
            stream_candidates(values),
            [
                "rtsp://user:secret@camera/Streaming/Channels/101",
                "rtsp://user:secret@camera/Streaming/Channels/102",
                "rtsp://relay/live/CH01",
            ],
        )

    def test_slot_boundary(self):
        self.assertEqual(slot_for(1000, 1000), 0)
        self.assertEqual(slot_for(1000, 4599), 0)
        self.assertEqual(slot_for(1000, 4600), 1)

    def test_slot_rejects_time_before_start(self):
        with self.assertRaises(ValueError):
            slot_for(1000, 999)

    def test_safe_error_removes_credentials_and_control_characters(self):
        value = safe_error("open rtsp://user:secret@host failed\nnext")
        self.assertNotIn("secret", value)
        self.assertNotIn("user", value)
        self.assertNotIn("\n", value)
        self.assertIn("rtsp://***@host", value)


class FakeCommandRunner:
    def __init__(self, *, image=b"\xff\xd8frame\xff\xd9", resolution="1920x1080", ffmpeg_rc=0):
        self.image = image
        self.resolution = resolution
        self.ffmpeg_rc = ffmpeg_rc
        self.calls = []

    def __call__(self, command, **kwargs):
        self.calls.append((list(command), dict(kwargs)))
        if "ffprobe" in " ".join(command):
            return subprocess.CompletedProcess(command, 0, stdout=self.resolution + "\n", stderr="")
        if self.ffmpeg_rc == 0:
            Path(command[-1]).write_bytes(self.image)
        return subprocess.CompletedProcess(command, self.ffmpeg_rc, stdout="", stderr="sensitive rtsp failure")


class CaptureCameraTests(unittest.TestCase):
    def test_captures_valid_high_resolution_jpeg_atomically(self):
        runner = FakeCommandRunner(resolution="2560x1440")
        with tempfile.TemporaryDirectory() as temp_dir:
            result = capture_camera(
                "CH01",
                "rtsp://user:secret@camera/Streaming/Channels/101",
                Path(temp_dir),
                "20260717_130000",
                command_runner=runner,
            )
            final_path = Path(temp_dir) / result.relative_path

            self.assertEqual(result.status, "SUCCESS")
            self.assertEqual((result.width, result.height), (2560, 1440))
            self.assertTrue(final_path.is_file())
            self.assertEqual(final_path.read_bytes(), b"\xff\xd8frame\xff\xd9")
            self.assertFalse(final_path.with_suffix(final_path.suffix + ".part").exists())

        ffmpeg_command = runner.calls[0][0]
        self.assertEqual(ffmpeg_command[0], "ffmpeg")
        self.assertNotIn("/usr/bin/nice", ffmpeg_command)
        self.assertNotIn("/usr/bin/ionice", ffmpeg_command)
        self.assertIn("-rtsp_transport", ffmpeg_command)
        self.assertIn("tcp", ffmpeg_command)
        self.assertIn("-frames:v", ffmpeg_command)
        self.assertIn("-q:v", ffmpeg_command)
        self.assertNotIn("secret", result.reason)

    def test_marks_below_720p_without_deleting_image(self):
        runner = FakeCommandRunner(resolution="640x360")
        with tempfile.TemporaryDirectory() as temp_dir:
            result = capture_camera(
                "CH02", "rtsp://camera/main", Path(temp_dir), "20260717_130000", command_runner=runner
            )
            self.assertEqual(result.status, "LOW_RESOLUTION")
            self.assertTrue((Path(temp_dir) / result.relative_path).is_file())

    def test_ffmpeg_failure_returns_generic_error_and_no_file(self):
        runner = FakeCommandRunner(ffmpeg_rc=1)
        with tempfile.TemporaryDirectory() as temp_dir:
            result = capture_camera(
                "CH03",
                "rtsp://user:secret@camera/main",
                Path(temp_dir),
                "20260717_130000",
                command_runner=runner,
            )
            self.assertEqual(result.status, "FAILED")
            self.assertEqual(result.reason, "ffmpeg_exit_1:sensitive rtsp failure")
            self.assertEqual(list(Path(temp_dir).rglob("*.jpg*")), [])

    def test_failure_reason_redacts_credentials_from_ffmpeg_stderr(self):
        class CredentialFailureRunner(FakeCommandRunner):
            def __call__(self, command, **kwargs):
                self.calls.append((list(command), dict(kwargs)))
                return subprocess.CompletedProcess(
                    command,
                    8,
                    stdout="",
                    stderr="open rtsp://admin:topsecret@camera/main failed",
                )

        with tempfile.TemporaryDirectory() as temp_dir:
            result = capture_camera(
                "CH03",
                "rtsp://admin:topsecret@camera/main",
                Path(temp_dir),
                "20260717_130000",
                command_runner=CredentialFailureRunner(),
            )

        self.assertEqual(result.status, "FAILED")
        self.assertIn("ffmpeg_exit_8", result.reason)
        self.assertIn("rtsp://***@camera", result.reason)
        self.assertNotIn("topsecret", result.reason)

    def test_invalid_jpeg_is_removed(self):
        runner = FakeCommandRunner(image=b"not-a-jpeg")
        with tempfile.TemporaryDirectory() as temp_dir:
            result = capture_camera(
                "CH04", "rtsp://camera/main", Path(temp_dir), "20260717_130000", command_runner=runner
            )
            self.assertEqual(result.status, "INVALID_IMAGE")
            self.assertEqual(list(Path(temp_dir).rglob("*.jpg*")), [])


class CaptureRunTests(unittest.TestCase):
    def make_run(self, temp_dir, *, start=1000, max_bytes=5 * 1024**3, min_free=5 * 1024**3):
        root = Path(temp_dir)
        env_dir = root / "env"
        output_root = root / "captures"
        run_dir = output_root / "run-test"
        env_dir.mkdir()
        config_path = root / "training-capture.conf"
        config_path.write_text(
            "\n".join(
                [
                    "RUN_ID=run-test",
                    f"START_EPOCH={start}",
                    f"END_EPOCH={start + 72 * 3600}",
                    f"OUTPUT_ROOT={output_root}",
                    f"RUN_DIR={run_dir}",
                    f"ENV_DIR={env_dir}",
                    "MAX_SLOTS=72",
                    "INTERVAL_SEC=3600",
                    f"MAX_BYTES={max_bytes}",
                    f"MIN_FREE_BYTES={min_free}",
                    "OWNER=",
                    "GROUP=",
                ]
            )
            + "\n",
            encoding="utf-8",
        )
        return config_path, env_dir, run_dir

    @staticmethod
    def successful_capture(camera_id, _url, output_dir, timestamp, **_kwargs):
        relative = f"{camera_id}/{camera_id}_{timestamp}.jpg"
        path = Path(output_dir) / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"\xff\xd8frame\xff\xd9")
        return CaptureResult("SUCCESS", 1920, 1080, path.stat().st_size, relative, "")

    @staticmethod
    def ample_disk(_path):
        return SimpleNamespace(total=100 * 1024**3, used=10 * 1024**3, free=90 * 1024**3)

    def test_load_run_config_has_typed_values(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path, _env_dir, run_dir = self.make_run(temp_dir)
            config = load_run_config(config_path)
        self.assertEqual(config.max_slots, 72)
        self.assertEqual(config.interval_sec, 3600)
        self.assertEqual(config.run_dir, run_dir)

    def test_runs_existing_cameras_in_order_and_writes_manifest(self):
        calls = []

        def capture(camera_id, url, output_dir, timestamp, **kwargs):
            calls.append((camera_id, url))
            return self.successful_capture(camera_id, url, output_dir, timestamp, **kwargs)

        with tempfile.TemporaryDirectory() as temp_dir:
            config_path, env_dir, run_dir = self.make_run(temp_dir)
            (env_dir / "ai-worker-CH02.env").write_text("RTSP_URL=rtsp://camera2/Streaming/Channels/102\n")
            (env_dir / "ai-worker-CH01.env").write_text("RTSP_URL=rtsp://camera1/Streaming/Channels/102\n")

            rc = run_capture(
                config_path,
                now_epoch=1000,
                capture_fn=capture,
                disk_usage_fn=self.ample_disk,
                systemctl_runner=lambda *args, **kwargs: None,
            )
            manifest = (run_dir / "manifest.tsv").read_text(encoding="utf-8")

        self.assertEqual(rc, 0)
        self.assertEqual([item[0] for item in calls], ["CH01", "CH02"])
        self.assertTrue(all(url.endswith("/Channels/101") for _, url in calls))
        self.assertIn("CH01", manifest)
        self.assertIn("CH02", manifest)
        self.assertEqual(manifest.count("SUCCESS"), 2)

    def test_same_slot_is_not_captured_twice_but_next_slot_runs(self):
        calls = []

        def capture(camera_id, url, output_dir, timestamp, **kwargs):
            calls.append(camera_id)
            return self.successful_capture(camera_id, url, output_dir, timestamp, **kwargs)

        with tempfile.TemporaryDirectory() as temp_dir:
            config_path, env_dir, _run_dir = self.make_run(temp_dir)
            (env_dir / "ai-worker-CH01.env").write_text("RTSP_URL=rtsp://camera/main\n")
            options = dict(
                capture_fn=capture,
                disk_usage_fn=self.ample_disk,
                systemctl_runner=lambda *args, **kwargs: None,
            )
            run_capture(config_path, now_epoch=1000, **options)
            run_capture(config_path, now_epoch=4599, **options)
            run_capture(config_path, now_epoch=4600, **options)

        self.assertEqual(calls, ["CH01", "CH01"])

    def test_missing_url_and_failed_camera_do_not_block_later_camera(self):
        calls = []

        def capture(camera_id, url, output_dir, timestamp, **kwargs):
            calls.append(camera_id)
            if camera_id == "CH02":
                return CaptureResult("FAILED", reason="ffmpeg_exit_1")
            return self.successful_capture(camera_id, url, output_dir, timestamp, **kwargs)

        with tempfile.TemporaryDirectory() as temp_dir:
            config_path, env_dir, run_dir = self.make_run(temp_dir)
            (env_dir / "ai-worker-CH01.env").write_text("CAMERA_ID=CH01\n")
            (env_dir / "ai-worker-CH02.env").write_text("RTSP_URL=rtsp://camera2/main\n")
            (env_dir / "ai-worker-CH03.env").write_text("RTSP_URL=rtsp://camera3/main\n")
            run_capture(
                config_path,
                now_epoch=1000,
                capture_fn=capture,
                disk_usage_fn=self.ample_disk,
                systemctl_runner=lambda *args, **kwargs: None,
            )
            manifest = (run_dir / "manifest.tsv").read_text(encoding="utf-8")

        self.assertEqual(calls, ["CH02", "CH03"])
        self.assertIn("NO_STREAM_URL", manifest)
        self.assertIn("FAILED", manifest)
        self.assertIn("SUCCESS", manifest)

    def test_failed_main_stream_falls_back_to_original_substream(self):
        calls = []

        def capture(camera_id, url, output_dir, timestamp, **kwargs):
            calls.append(url)
            if url.endswith("/Channels/101"):
                return CaptureResult("FAILED", reason="ffmpeg_exit_8:main unavailable")
            return self.successful_capture(camera_id, url, output_dir, timestamp, **kwargs)

        with tempfile.TemporaryDirectory() as temp_dir:
            config_path, env_dir, run_dir = self.make_run(temp_dir)
            (env_dir / "ai-worker-CH01.env").write_text(
                "RTSP_URL=rtsp://camera/Streaming/Channels/102\n",
                encoding="utf-8",
            )
            run_capture(
                config_path,
                now_epoch=1000,
                capture_fn=capture,
                disk_usage_fn=self.ample_disk,
                systemctl_runner=lambda *args, **kwargs: None,
            )
            manifest = (run_dir / "manifest.tsv").read_text(encoding="utf-8")

        self.assertEqual(
            calls,
            [
                "rtsp://camera/Streaming/Channels/101",
                "rtsp://camera/Streaming/Channels/102",
            ],
        )
        self.assertIn("SUCCESS", manifest)

    def test_slot_72_marks_complete_and_disables_timer(self):
        systemctl_calls = []
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path, _env_dir, run_dir = self.make_run(temp_dir)
            rc = run_capture(
                config_path,
                now_epoch=1000 + 72 * 3600,
                capture_fn=self.successful_capture,
                disk_usage_fn=self.ample_disk,
                systemctl_runner=lambda command, **kwargs: systemctl_calls.append(command),
            )
            self.assertTrue((run_dir / "COMPLETE.txt").is_file())
        self.assertEqual(rc, 0)
        self.assertTrue(any("river-training-capture.timer" in command for command in systemctl_calls))

    def test_low_disk_marks_storage_stop_without_capture(self):
        calls = []
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path, env_dir, run_dir = self.make_run(temp_dir)
            (env_dir / "ai-worker-CH01.env").write_text("RTSP_URL=rtsp://camera/main\n")
            run_capture(
                config_path,
                now_epoch=1000,
                capture_fn=lambda *args, **kwargs: calls.append(args),
                disk_usage_fn=lambda _path: SimpleNamespace(total=10, used=9, free=1),
                systemctl_runner=lambda *args, **kwargs: None,
            )
            self.assertTrue((run_dir / "STOPPED_STORAGE.txt").is_file())
        self.assertEqual(calls, [])

    def test_manifest_does_not_contain_stream_credentials(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path, env_dir, run_dir = self.make_run(temp_dir)
            (env_dir / "ai-worker-CH01.env").write_text(
                "RTSP_URL=rtsp://admin:topsecret@camera/Streaming/Channels/102\n"
            )
            run_capture(
                config_path,
                now_epoch=1000,
                capture_fn=self.successful_capture,
                disk_usage_fn=self.ample_disk,
                systemctl_runner=lambda *args, **kwargs: None,
            )
            manifest = (run_dir / "manifest.tsv").read_text(encoding="utf-8")
        self.assertNotIn("topsecret", manifest)
        self.assertNotIn("rtsp://", manifest)


if __name__ == "__main__":
    unittest.main()
