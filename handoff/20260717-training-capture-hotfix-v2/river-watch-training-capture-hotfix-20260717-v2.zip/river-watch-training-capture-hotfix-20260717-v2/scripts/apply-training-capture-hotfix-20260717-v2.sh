#!/usr/bin/env bash
set -Eeuo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_DIR="${APP_DIR:-/home/ai-river/river-watch}"
INSTALL_DIR="${INSTALL_DIR:-/opt/river-watch/training-capture}"
CONFIG_FILE="${CONFIG_FILE:-/etc/river-watch/training-capture.conf}"
TS="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$APP_DIR/backups/training-capture-hotfix-20260717-v2-$TS"

[[ "$(id -u)" -eq 0 ]] || { echo "ERROR: run with sudo" >&2; exit 1; }
[[ -f "$CONFIG_FILE" ]] || { echo "ERROR: missing $CONFIG_FILE" >&2; exit 1; }
[[ -f "$INSTALL_DIR/training_capture.py" ]] || { echo "ERROR: training capture is not installed" >&2; exit 1; }

echo "== 1. Verify hotfix package =="
(cd "$PACKAGE_DIR" && sha256sum -c SHA256SUMS)

echo "== 2. Backup the installed capture tool =="
install -d -m 0755 "$BACKUP_DIR/install" "$BACKUP_DIR/etc"
cp -a "$INSTALL_DIR/training_capture.py" "$BACKUP_DIR/install/training_capture.py"
cp -a "$CONFIG_FILE" "$BACKUP_DIR/etc/training-capture.conf"

echo "== 3. Install the capture-only hotfix =="
systemctl stop river-training-capture.service || true
install -m 0755 "$PACKAGE_DIR/training_capture/training_capture.py" "$INSTALL_DIR/training_capture.py"
PYTHONDONTWRITEBYTECODE=1 python3 -m py_compile "$INSTALL_DIR/training_capture.py"

run_dir="$(awk -F= '$1 == "RUN_DIR" {sub(/^[^=]*=/, ""); print; exit}' "$CONFIG_FILE")"
[[ -n "$run_dir" && "$run_dir" == /home/ai-river/training-captures/* ]] || {
  echo "ERROR: unsafe or missing RUN_DIR in $CONFIG_FILE" >&2
  exit 1
}

echo "== 4. Retry the current slot only when it has zero usable images =="
last_slot_file="$run_dir/.last-slot"
manifest="$run_dir/manifest.tsv"
retry=0
if [[ -f "$last_slot_file" && -f "$manifest" ]]; then
  last_slot="$(tr -dc '0-9' < "$last_slot_file")"
  if [[ -n "$last_slot" ]]; then
    usable="$(awk -F '\t' -v slot="$last_slot" 'NR > 1 && $1 == slot && ($4 == "SUCCESS" || $4 == "LOW_RESOLUTION") {count++} END {print count+0}' "$manifest")"
    if [[ "$usable" -eq 0 ]]; then
      cp -a "$last_slot_file" "$BACKUP_DIR/last-slot"
      rm -f -- "$last_slot_file"
      retry=1
    fi
  fi
fi

systemctl enable --now river-training-capture.timer
if [[ "$retry" -eq 1 ]]; then
  systemctl start --no-block river-training-capture.service
  echo "current failed slot queued for immediate retry"
else
  echo "current slot already has usable images; next timer run remains scheduled"
fi

echo "DONE"
echo "backup=$BACKUP_DIR"
echo "run_dir=$run_dir"

