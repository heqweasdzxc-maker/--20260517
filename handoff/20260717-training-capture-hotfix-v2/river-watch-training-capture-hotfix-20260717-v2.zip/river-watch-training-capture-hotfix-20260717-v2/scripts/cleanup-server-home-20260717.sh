#!/usr/bin/env bash
set -Eeuo pipefail

HOME_DIR="${HOME_DIR:-/home/ai-river}"
APPLY="${APPLY:-0}"
TS="$(date +%Y%m%d-%H%M%S)"
MANIFEST="$HOME_DIR/cleanup-manifest-$TS.txt"

[[ "$HOME_DIR" == "/home/ai-river" ]] || { echo "ERROR: unexpected HOME_DIR" >&2; exit 1; }

declare -a candidates=(
  "$HOME_DIR/ch09-evidence-20260717-111419"
  "$HOME_DIR/ch09-evidence-20260717-111419.tar.gz"
  "$HOME_DIR/ch09-evidence-20260717-111419.tar.gz.sha256"
  "$HOME_DIR/river-training-20260717-150033.tar.gz"
  "$HOME_DIR/river-training-20260717-150033.tar.gz.sha256"
  "$HOME_DIR/river-watch-ai-runtime-topology-increment-20260714"
  "$HOME_DIR/river-watch-ai-runtime-topology-increment-20260715-v2"
  "$HOME_DIR/river-watch-ai-runtime-topology-increment-20260715-v3"
  "$HOME_DIR/river-watch-alarm-evidence-annotations-layout-increment-20260715"
  "$HOME_DIR/river-watch-alarm-evidence-annotations-layout-increment-20260715-v2"
  "$HOME_DIR/river-watch-alarm-evidence-rebase-baseline-20260715-202205"
  "$HOME_DIR/river-watch-alarm-evidence-snapshot-increment-20260712"
  "$HOME_DIR/river-watch-alarm-evidence-snapshot-increment-20260713-v2"
  "$HOME_DIR/river-watch-alarm-evidence-snapshot-increment-20260713-v3"
  "$HOME_DIR/river-watch-alarm-list-full-datetime-increment-20260714"
  "$HOME_DIR/river-watch-alarm-list-full-datetime-increment-20260714-v2"
  "$HOME_DIR/river-watch-header-time-weather-increment-20260713"
  "$HOME_DIR/river-watch-model-deploy-waitfix-20260714"
  "$HOME_DIR/river-watch-river-anomaly-model-increment-20260714"
  "$HOME_DIR/river-watch-river-anomaly-model-increment-20260714-v2"
  "$HOME_DIR/river-watch-training-capture-increment-20260717"
)

while IFS= read -r -d '' item; do
  candidates+=("$item")
done < <(find "$HOME_DIR" -maxdepth 1 -type f -name '*.log' -mtime +1 -print0)

{
  echo "cleanup_created_at=$TS"
  echo "mode=$([[ "$APPLY" == "1" ]] && echo APPLY || echo DRY_RUN)"
  for item in "${candidates[@]}"; do
    [[ -e "$item" || -L "$item" ]] || continue
    resolved="$(readlink -f -- "$item")"
    [[ "$resolved" == "$HOME_DIR"/* ]] || { echo "SKIP_UNSAFE $item"; continue; }
    case "$resolved" in
      "$HOME_DIR/river-watch"|"$HOME_DIR/training-captures"|"$HOME_DIR/db-backups")
        echo "SKIP_PROTECTED $resolved"
        continue
        ;;
    esac
    size="$(du -sh -- "$resolved" 2>/dev/null | awk '{print $1}')"
    echo "DELETE $size $resolved"
  done
} | tee "$MANIFEST"

if [[ "$APPLY" != "1" ]]; then
  echo "DRY RUN ONLY. Review $MANIFEST, then rerun with APPLY=1."
  exit 0
fi

while read -r action _size path; do
  [[ "$action" == "DELETE" ]] || continue
  [[ "$path" == "$HOME_DIR"/* ]] || { echo "ERROR: unsafe cleanup target $path" >&2; exit 1; }
  rm -rf --one-file-system -- "$path"
done < "$MANIFEST"

echo "cleanup complete"
df -h "$HOME_DIR"
