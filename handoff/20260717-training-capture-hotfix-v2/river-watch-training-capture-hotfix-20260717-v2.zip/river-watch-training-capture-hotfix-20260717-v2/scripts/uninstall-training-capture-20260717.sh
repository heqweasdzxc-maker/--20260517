#!/usr/bin/env bash
set -Eeuo pipefail

INSTALL_DIR="${INSTALL_DIR:-/opt/river-watch/training-capture}"
CONFIG_FILE="${CONFIG_FILE:-/etc/river-watch/training-capture.conf}"
if [[ "$(id -u)" -ne 0 ]]; then
  echo "ERROR: run with sudo" >&2
  exit 1
fi

systemctl disable --now river-training-capture.timer || true
systemctl stop river-training-capture.service || true
rm -f /etc/systemd/system/river-training-capture.timer
rm -f /etc/systemd/system/river-training-capture.service
rm -f "$CONFIG_FILE"
if [[ "$INSTALL_DIR" == "/opt/river-watch/training-capture" && -d "$INSTALL_DIR" ]]; then
  find "$INSTALL_DIR" -mindepth 1 -maxdepth 1 -type f -delete
  find "$INSTALL_DIR" -mindepth 1 -maxdepth 1 -type d -empty -delete
  rmdir "$INSTALL_DIR" 2>/dev/null || true
fi
systemctl daemon-reload
echo "Tool removed. Captured images were preserved."

