#!/usr/bin/env bash
set -Eeuo pipefail

CONFIG_FILE="${CONFIG_FILE:-/etc/river-watch/training-capture.conf}"
if [[ "$(id -u)" -ne 0 ]]; then
  echo "ERROR: run with sudo" >&2
  exit 1
fi

systemctl disable --now river-training-capture.timer || true
systemctl stop river-training-capture.service || true

if [[ -r "$CONFIG_FILE" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "$CONFIG_FILE"
  set +a
  if [[ -n "${RUN_DIR:-}" && -d "$RUN_DIR" ]]; then
    printf 'stopped_at=%s\nreason=manual_stop\n' "$(date --iso-8601=seconds)" > "$RUN_DIR/STOPPED_MANUAL.txt"
    chown "${OWNER:-ai-river}:${GROUP:-ai-river}" "$RUN_DIR/STOPPED_MANUAL.txt" 2>/dev/null || true
    echo "Captured images preserved at: $RUN_DIR"
  fi
fi
echo "DONE"

