#!/usr/bin/env bash
set -Eeuo pipefail

CONFIG_FILE="${CONFIG_FILE:-/etc/river-watch/training-capture.conf}"
run_dir="$(awk -F= '$1 == "RUN_DIR" {sub(/^[^=]*=/, ""); print; exit}' "$CONFIG_FILE")"

echo "== services =="
systemctl is-active river-training-capture.timer
systemctl is-enabled river-training-capture.timer
systemctl status river-training-capture.service river-training-capture.timer --no-pager -l || true

echo "== latest manifest =="
tail -30 "$run_dir/manifest.tsv"

echo "== captured JPEG files =="
find "$run_dir" -maxdepth 2 -type f -name '*.jpg' -printf '%P\t%s bytes\n' | sort

echo "== recent capture journal =="
journalctl -u river-training-capture.service --since "30 minutes ago" --no-pager -n 120 || true

