#!/usr/bin/env bash
set -Eeuo pipefail

CONFIG_FILE="${CONFIG_FILE:-/etc/river-watch/training-capture.conf}"
if [[ ! -r "$CONFIG_FILE" ]]; then
  echo "ERROR: cannot read $CONFIG_FILE; run with sudo" >&2
  exit 1
fi

set -a
# shellcheck disable=SC1090
source "$CONFIG_FILE"
set +a

now="$(date +%s)"
elapsed="$((now - START_EPOCH))"
(( elapsed < 0 )) && elapsed=0
remaining="$((END_EPOCH - now))"
(( remaining < 0 )) && remaining=0
slot="$((elapsed / INTERVAL_SEC))"
manifest="$RUN_DIR/manifest.tsv"

echo "== Training capture status =="
echo "run_id=$RUN_ID"
echo "run_dir=$RUN_DIR"
echo "slot=$slot/$MAX_SLOTS"
echo "elapsed_hours=$((elapsed / 3600))"
echo "remaining_hours=$((remaining / 3600))"
echo "directory_size=$(du -sh "$RUN_DIR" 2>/dev/null | awk '{print $1}')"
echo "timer_active=$(systemctl is-active river-training-capture.timer 2>/dev/null || true)"
echo "service_active=$(systemctl is-active river-training-capture.service 2>/dev/null || true)"

if [[ -f "$RUN_DIR/COMPLETE.txt" ]]; then
  echo "state=COMPLETE"
elif [[ -f "$RUN_DIR/STOPPED_STORAGE.txt" ]]; then
  echo "state=STOPPED_STORAGE"
elif [[ -f "$RUN_DIR/STOPPED_MANUAL.txt" ]]; then
  echo "state=STOPPED_MANUAL"
else
  echo "state=RUNNING"
fi

if [[ ! -f "$manifest" ]]; then
  echo "manifest=waiting_for_first_capture"
  exit 0
fi

echo "== Result counts =="
awk -F '\t' 'NR>1 {count[$4]++} END {for (key in count) print key "=" count[key]}' "$manifest" | sort

echo "== Per-camera saved images =="
awk -F '\t' 'NR>1 && ($4=="SUCCESS" || $4=="LOW_RESOLUTION") {count[$2]++} END {for (key in count) print key "=" count[key]}' "$manifest" | sort

echo "== Resolution distribution =="
awk -F '\t' 'NR>1 && $5!="" && $6!="" {count[$5 "x" $6]++} END {for (key in count) print key "=" count[key]}' "$manifest" | sort

echo "== Recent failures =="
awk -F '\t' 'NR>1 && $4!="SUCCESS" && $4!="LOW_RESOLUTION" {print $1, $2, $3, $4, $9}' "$manifest" | tail -20 || true

