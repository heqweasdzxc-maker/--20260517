#!/usr/bin/env bash
set -Eeuo pipefail

STATE_DIR="${STATE_DIR:-/var/lib/river-watch-training-capture}"
INSTALL_DIR="${INSTALL_DIR:-/opt/river-watch/training-capture}"
CONFIG_FILE="${CONFIG_FILE:-/etc/river-watch/training-capture.conf}"
UNIT_DIR="/etc/systemd/system"
if [[ "$(id -u)" -ne 0 ]]; then
  echo "ERROR: run with sudo" >&2
  exit 1
fi

BACKUP_DIR="${BACKUP_DIR:-}"
if [[ -z "$BACKUP_DIR" && -r "$STATE_DIR/latest-backup" ]]; then
  BACKUP_DIR="$(cat "$STATE_DIR/latest-backup")"
fi
if [[ -z "$BACKUP_DIR" || ! -d "$BACKUP_DIR" ]]; then
  echo "ERROR: rollback backup not found" >&2
  exit 1
fi

systemctl disable --now river-training-capture.timer || true
systemctl stop river-training-capture.service || true
rm -f "$UNIT_DIR/river-training-capture.service" "$UNIT_DIR/river-training-capture.timer" "$CONFIG_FILE"
if [[ "$INSTALL_DIR" == "/opt/river-watch/training-capture" && -d "$INSTALL_DIR" ]]; then
  find "$INSTALL_DIR" -mindepth 1 -maxdepth 1 -type f -delete
  find "$INSTALL_DIR" -mindepth 1 -maxdepth 1 -type d -empty -delete
  rmdir "$INSTALL_DIR" 2>/dev/null || true
fi

if [[ -d "$BACKUP_DIR/install/training-capture" ]]; then
  cp -a "$BACKUP_DIR/install/training-capture" "$INSTALL_DIR"
fi
if [[ -f "$BACKUP_DIR/etc/training-capture.conf" ]]; then
  cp -a "$BACKUP_DIR/etc/training-capture.conf" "$CONFIG_FILE"
fi
for unit_name in river-training-capture.service river-training-capture.timer; do
  if [[ -f "$BACKUP_DIR/systemd/$unit_name" ]]; then
    cp -a "$BACKUP_DIR/systemd/$unit_name" "$UNIT_DIR/$unit_name"
  fi
done
systemctl daemon-reload

if grep -q '^timer_enabled=enabled$' "$BACKUP_DIR/service-state.env" 2>/dev/null; then
  systemctl enable river-training-capture.timer
fi
if grep -q '^timer_active=active$' "$BACKUP_DIR/service-state.env" 2>/dev/null; then
  systemctl start river-training-capture.timer
fi
echo "ROLLBACK DONE"
echo "Captured images were preserved."

