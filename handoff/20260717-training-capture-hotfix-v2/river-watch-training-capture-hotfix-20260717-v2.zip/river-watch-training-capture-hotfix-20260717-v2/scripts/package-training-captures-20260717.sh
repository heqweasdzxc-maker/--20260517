#!/usr/bin/env bash
set -Eeuo pipefail

CONFIG_FILE="${CONFIG_FILE:-/etc/river-watch/training-capture.conf}"
if [[ ! -r "$CONFIG_FILE" ]]; then
  echo "ERROR: cannot read $CONFIG_FILE; run with sudo" >&2
  exit 1
fi

set -a
# shellcheck disable=SC1090
source "$CONFIG_FILE"
set +a

if [[ ! -d "$RUN_DIR" ]]; then
  echo "ERROR: run directory does not exist" >&2
  exit 1
fi

ARCHIVE="${ARCHIVE:-/home/ai-river/${RUN_ID}.tar.gz}"
tar -C "$(dirname "$RUN_DIR")" -czf "$ARCHIVE" "$(basename "$RUN_DIR")"
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"
chown "${OWNER:-ai-river}:${GROUP:-ai-river}" "$ARCHIVE" "$ARCHIVE.sha256" 2>/dev/null || true
echo "archive=$ARCHIVE"
echo "checksum=$ARCHIVE.sha256"
sha256sum "$ARCHIVE"

