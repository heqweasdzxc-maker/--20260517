#!/usr/bin/env bash
set -Eeuo pipefail

PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_DIR="${APP_DIR:-/home/ai-river/river-watch}"
INSTALL_DIR="${INSTALL_DIR:-/opt/river-watch/training-capture}"
CONFIG_FILE="${CONFIG_FILE:-/etc/river-watch/training-capture.conf}"
OUTPUT_ROOT="${OUTPUT_ROOT:-/home/ai-river/training-captures}"
ENV_DIR="${ENV_DIR:-/etc/river-watch}"
OWNER="${OWNER:-ai-river}"
GROUP="${GROUP:-ai-river}"
MAX_BYTES="${MAX_BYTES:-5368709120}"
MIN_FREE_BYTES="${MIN_FREE_BYTES:-5368709120}"
FORCE_NEW_RUN="${FORCE_NEW_RUN:-0}"
UNIT_DIR="/etc/systemd/system"
STATE_DIR="/var/lib/river-watch-training-capture"
TS="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$APP_DIR/backups/training-capture-increment-20260717-$TS"

require_root() {
  if [[ "$(id -u)" -ne 0 ]]; then
    echo "ERROR: run with sudo" >&2
    exit 1
  fi
}

require_command() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "ERROR: required command not found: $1" >&2
    exit 1
  }
}

echo "== River Watch training image capture increment =="
require_root
for command_name in python3 ffmpeg ffprobe systemctl sha256sum; do
  require_command "$command_name"
done

if systemctl is-active --quiet river-training-capture.timer; then
  if [[ "$FORCE_NEW_RUN" != "1" ]]; then
    echo "ERROR: a training capture run is already active; use FORCE_NEW_RUN=1 to start a separate run" >&2
    exit 1
  fi
  systemctl disable --now river-training-capture.timer
  systemctl stop river-training-capture.service || true
fi

mkdir -p "$BACKUP_DIR/install" "$BACKUP_DIR/etc" "$BACKUP_DIR/systemd" "$STATE_DIR"
if [[ -d "$INSTALL_DIR" ]]; then
  cp -a "$INSTALL_DIR" "$BACKUP_DIR/install/training-capture"
fi
if [[ -f "$CONFIG_FILE" ]]; then
  cp -a "$CONFIG_FILE" "$BACKUP_DIR/etc/training-capture.conf"
fi
for unit_name in river-training-capture.service river-training-capture.timer; do
  if [[ -f "$UNIT_DIR/$unit_name" ]]; then
    cp -a "$UNIT_DIR/$unit_name" "$BACKUP_DIR/systemd/$unit_name"
  fi
done
{
  printf 'timer_enabled=%s\n' "$(systemctl is-enabled river-training-capture.timer 2>/dev/null || true)"
  printf 'timer_active=%s\n' "$(systemctl is-active river-training-capture.timer 2>/dev/null || true)"
} > "$BACKUP_DIR/service-state.env"
printf '%s\n' "$BACKUP_DIR" > "$STATE_DIR/latest-backup"

install -d -m 0755 "$INSTALL_DIR" "$OUTPUT_ROOT" "$(dirname "$CONFIG_FILE")"
install -m 0755 "$PACKAGE_DIR/training_capture/training_capture.py" "$INSTALL_DIR/training_capture.py"
install -m 0644 "$PACKAGE_DIR/systemd/river-training-capture.service" "$UNIT_DIR/river-training-capture.service"
install -m 0644 "$PACKAGE_DIR/systemd/river-training-capture.timer" "$UNIT_DIR/river-training-capture.timer"

available_bytes="$(df -PB1 "$OUTPUT_ROOT" | awk 'NR==2 {print $4}')"
if [[ -z "$available_bytes" || "$available_bytes" -lt "$MIN_FREE_BYTES" ]]; then
  echo "ERROR: less than the configured minimum free space is available" >&2
  exit 1
fi

start_epoch="$(date +%s)"
end_epoch="$((start_epoch + 72 * 3600))"
run_id="river-training-$TS"
run_dir="$OUTPUT_ROOT/$run_id"
install -d -m 0755 "$run_dir"

cat > "$CONFIG_FILE" <<EOF
RUN_ID=$run_id
START_EPOCH=$start_epoch
END_EPOCH=$end_epoch
OUTPUT_ROOT=$OUTPUT_ROOT
RUN_DIR=$run_dir
ENV_DIR=$ENV_DIR
MAX_SLOTS=72
INTERVAL_SEC=3600
MAX_BYTES=$MAX_BYTES
MIN_FREE_BYTES=$MIN_FREE_BYTES
OWNER=$OWNER
GROUP=$GROUP
EOF
chmod 0640 "$CONFIG_FILE"
chown "$OWNER:$GROUP" "$OUTPUT_ROOT" "$run_dir" 2>/dev/null || true

python3 -m py_compile "$INSTALL_DIR/training_capture.py"
systemctl daemon-reload
systemctl enable --now river-training-capture.timer
systemctl start --no-block river-training-capture.service

echo "DONE"
echo "run_id=$run_id"
echo "run_dir=$run_dir"
echo "backup=$BACKUP_DIR"
echo "The first capture is running asynchronously. Use the verify script to inspect it."

